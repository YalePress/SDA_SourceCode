#!/bin/sh

my_dir=$(dirname $0)

. $my_dir/pathfix.sh

REINDEX_LOG_FILE=reindex.log

now () {
    echo $(date +"%D %T")
}

reindex () {
    local CONF=$1
    local INDEX=$2
    local last_index_logfile=$my_dir/reindex_$INDEX.log

    echo "$(now)" > $last_index_logfile
#    TODO: reomove VVV
#    echo "indexer=$(which indexer)" >> $last_index_logfile
#    echo "$(set)" >> $last_index_logfile

    indexer -c $CONF --rotate $INDEX 2>&1 | \
        tee -a $last_index_logfile | \
        grep -i "error"
}
