#!/bin/sh

LOCAL_SPHINX=sphinx/bin

# add local sphinx installation to PATH
PATH=$HOME/$LOCAL_SPHINX:$PATH

if [ ! -z $USER ];
then
    PATH=/home/$USER/$LOCAL_SPHINX:$PATH
fi
