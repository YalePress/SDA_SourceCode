#!/bin/sh

### BEGIN INIT INFO
# Provides:          searchd
# Required-Start:    $local_fs $remote_fs $network $syslog
# Required-Stop:     $local_fs $remote_fs $network $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: sphinx searchd init.d script
# Description:       sphinx searchd init.d script
### END INIT INFO

#
# this is sphinx searchd service script
# by xonix
#

USER=@username@

BASE_PATH=@indexpath@

RETVAL=0

do_start() {
	sudo -u $USER sh $BASE_PATH/start.sh
	RETVAL=$?
	return $RETVAL
}

do_stop() {
	sudo -u $USER sh $BASE_PATH/stop.sh
	RETVAL=$?
	return $RETVAL
}

do_status() {
	sudo -u $USER sh $BASE_PATH/status.sh
	RETVAL=$?
	return $RETVAL
}

case $* in
start)
	do_start
	;;

stop)
	do_stop
	;;

restart)
	do_stop
	do_start
	;;

status)
	do_status
	;;

*)
	echo "usage: $0 {start|stop|restart|status}" >&2

	exit 1
	;;
esac

exit $RETVAL


