#!/bin/sh

my_dir=$(dirname $0)

. $my_dir/pathfix.sh

echo "Stopping $(which searchd)..."

searchd -c $(dirname $0)/sphinx.conf --stopwait

echo "Done."
