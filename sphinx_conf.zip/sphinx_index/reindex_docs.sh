#!/bin/sh

my_dir=$(dirname $0)

. $my_dir/reindex_cfg.sh

(
echo "$(now) - Reindexing archive docs"
reindex $my_dir/sphinx.conf @sitename@
) >> $my_dir/$REINDEX_LOG_FILE
