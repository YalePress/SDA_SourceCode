#!/bin/sh

res=$(ps -ef | grep searchd | grep -v grep | tail -n1)

if [ -z "$res" ];
then
    echo "searchd not started"
else
    echo $res
fi


