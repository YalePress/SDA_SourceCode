<?php
$this->SET = array(
'last_action' => '1',
'last_db_backup' => 'stalin',
'tables' => '',
'comp_method' => '1',
'comp_level' => '7',
'last_db_restore' => 'stalin',
'tables_exclude' => '0',
)
?>