var MANTIS_BASE = '/backend';
var MANTIS_LOGIN_URL = MANTIS_BASE + '/login.php';
var MANTIS_LOGOUT_URL = MANTIS_BASE + '/logout_page.php';

$(document).ready(function() {
    $('input[id^="edit-submit"][value="Log in"]').click(function() {
       // if (nameField().val() == 'admin@localhost'){perform_drupal_login(); }
       // else   {alert ('Not correct username or password!'); return false;} 
        if (nameField().val() != 'admin@localhost') { // we don't need login drupal root to mantis
            setTimeout('perform_mantis_login_and_then_submit_frm()', 1); // hmmm...
            return false;
        } else {
            return true;
        } 
    });

    logoutLnk().click(function () {
        console.log()
        setTimeout('perform_mantis_logout_and_then_drupal_logout()', 1);
        return false;
    });
});

function select_first() {
    for (var i = 0; i < arguments.length; i++) {
        var o = $(arguments[i]);
        if (o.length) {
            return o;
        }
    }

    return $(); // empty jquery
}

function nameField() {
    return $('input[id^="edit-name"]'); // see http://api.jquery.com/category/selectors/
}

function passField() {
    return $('input[id^="edit-pass"]');
}

function logoutLnk() {
    //return select_first('a[text="Log out"]', 'a:contains("Log out")');
    return jQuery('a[text="Log out"]', 'a:contains("Log out")').eq(0);
}

function perform_drupal_login() {
    // Now perform Drupal login
    select_first('form#user-login', 'form#user-login-form').submit();
}

function perform_mantis_login_and_then_submit_frm() {
    $.ajax({
        url: MANTIS_LOGIN_URL,
        type: 'POST',
        data: {
            username:    nameField().val(),
            password:    passField().val(),

            perm_login:    'on',
            'return':    'index.php',
            secure_session:    'on'
        },
        success: function (data, textStatus) {
            if (data.indexOf("username/password you entered is incorrect") >= 0) {
               alert('Not correct Mantis username or password!');
                perform_drupal_login(); // login to drupal anyways
            } else {
               // alert ('Not correct username or password!');
                perform_drupal_login();
            }
        },
        error: function() {
           alert('Error while login to Mantis!');
          //alert ('Not correct username or password!');
            perform_drupal_login(); // login to drupal anyways
        }
    });
}

function perform_drupal_logout() {
    location.href = logoutLnk().get(0).href; // Now perform Drupal logout
}

function perform_mantis_logout_and_then_drupal_logout() {
    $.ajax({
        url: MANTIS_LOGOUT_URL,
        type: 'GET',
        success: function (data, textStatus) {
            perform_drupal_logout();
        },
        error: function() {
            alert('Error while logout from Mantis!');
            perform_drupal_logout(); // logout anyways
        }
    });
}
