<?php
  drupal_add_css('sites/all/themes/stalin/profile_form.css');
  drupal_add_css('sites/all/themes/stalin/style/user-login-block.css');

  $errors = form_get_errors();
  unset($form['name']['#title']);// = t('Username');
  $form['name']['#required'] = false;
  //$form['name']['#help_description'] = '(Email address)';
  $output='';
  $output .= '<div class="login_item">'
              .'<div class="login_item_header" id="name_item_header">'
                .'Username: '.'<span style="color:gray;font-style:italic">(email address)</span>'
              .'</div>'
              .drupal_render($form['name'])
            .'</div>';
  unset($form['pass']['#title']);// = t('Username');
  $form['pass']['#required'] = false;
  $output .= '<div class="login_item">'
              .'<div class="login_item_header" id="pass_item_header">'
                .'Password:'.'<div class="right_div"><span><a href="user/password">Forgot password?</a></span></div>'
              .'</div>'
              .drupal_render($form['pass'])
            .'</div>';

  $login_button = '';
  $login_button.= '<div class="gray_button" id="login_button">';
  $login_button.= '<a href="javascript:submit_login_form();">';
  $login_button.=       '<div class="gray_button_left">
                          <div class="gray_button_middle">
                            <b>Log In</b>
                          </div>
                          <div class="gray_button_right">
                          </div>
                        </div>
                        </a>
                      </div><input id="login_submit" type="submit" hidefocus="true" class="hidden"><div class="clear"></div>';
  $output.= $login_button;

  if (isset($errors['name'])) {
  	$output.= stalin_form_error_block($errors['name']);//'Invalid Username or password.');
  } else if (isset($errors['pass'])) {
  	$output.= stalin_form_error_block($errors['pass']);
  }
  if (isIpAuthorized()) {
    $items = array();
    if (variable_get('user_register', 1)) {
      $items[] = l(t('Register for a personal SDA account'), 'user/register', array('attributes' => array('title' => t('Register for a personal SDA account'))));
    }
    $form['links'] = array('#value' => theme('item_list', $items));
    $output.= '<div class="login_item">'
                .'<div class="login_item_link" id="block_login_links">'
                  .drupal_render($form['links'])
                .'</div>'
              .'</div>';
  } else {
    $items_current_subscribers = array();
    if (variable_get('user_register', 1)) {
      $items_current_subscribers[] = l(t('Purchase a subscription'), 'user/register', array('attributes' => array('title' => t('Register for a personal SDA account'))));
    }
    $subscription_link = getBlockContentByName("subscription_site_link");
    $items_current_subscribers[]= l(t('Renew your subscription'), $subscription_link, array('attributes' => array('title' => t('Renew your subscription'))));
    $form['current_subscribers_links'] = array('#value' => theme('item_list', $items_current_subscribers));
    /*$output .= '<div class="login_item">'
                .'<div class="login_item_header current_subscribers">'
                  .'Current Subscribers:'
                .'</div>'
              .'</div>';*/
    $output.= '<div class="login_item">'
                .'<div class="login_item_link" id="block_login_links">'
                  .drupal_render($form['current_subscribers_links'])
                .'</div>'
              .'</div>';
  }
  $items_help = array();
  $items_help[]= l(t('Need help? Contact us'), 'node/16', array('attributes' => array('title' => t('Need help? Contact us'))));
  $form['help_links'] = array('#value' => theme('item_list', $items_help));
  $output.= '<div class="login_item">'
              .'<div class="login_item_link_question" id="block_question_links">'
                .drupal_render($form['help_links'])
              .'</div>'
            .'</div>';

  $output.=drupal_render($form['form_build_id']);
  $output.=drupal_render($form['form_token']);
  $output.=drupal_render($form['form_id']);

  echo $output;
  //print_r($errors);
  //print_r($form);
 ?>