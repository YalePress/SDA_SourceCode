<?php
    global $user;
    $errors = form_get_errors();
    $errors_html = '';
    //global $messages;
    $errors_html .= '<div class="form_error_section">';
    foreach ($errors as $error)
    {
			$errors_html .='<div class="form_error_item">'
												.$error
											.'</div>';
    }
    $errors_html .= '</div>';

    drupal_add_js('sites/all/themes/stalin/profile_form.js');
    drupal_add_css('sites/all/themes/stalin/profile_form.css');
    drupal_add_css('sites/all/themes/stalin/user-register.css');

    $about_category = 'Account';

		$output='';
		$output .= '
			<div class="profile_header">
				Step 1: Create a New Profile
			</div>';

    $output .= '
			<div class="user_register_required">
				<span class="form-required" title="This field is required.">*</span> Required field
			</div>';
			if ($errors != null) $output .=$errors_html;

    $output.='<div class="profile_category_section">'
        .create_profile_category_header('My Information', false)
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_first_name'])
                .'</div>'
            .'</div>'
            .'<input type=hidden name="edit_form_picker" value="1">'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_last_name'])
                .'</div>'
            .'</div>';
                		unset($form['account']['mail']['#description']);
    $output.='<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['account']['mail'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_institution'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_adress_1'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_adress_2'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_city'])
                .'</div>'
            .'</div>'
            .'<div id="state_wrapper" class="profile_item_wrapper">'
                .'<div class="profile_item select_item">'
                    .drupal_render($form['Account']['profile_state'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_zip'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item select_item">'
                    .drupal_render($form['Account']['profile_country'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_position'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_department'])
                .'</div>'
            .'</div>'

            .'<div class="hidden profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_name_permission'])
                .'</div>'
            .'</div>'
            .'<div class="hidden profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_email_permission'])
                .'</div>'
            .'</div>'
            .'<div class="hidden profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_ardess_permission'])
                .'</div>'
            .'</div>'
            .'<div class="hidden profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_institution_permission'])
                .'</div>'
            .'</div>'
            .'<div class="hidden profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_picture_permission'])
                .'</div>'
            .'</div>'
            .'<div class="hidden profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_my_bio_permission'])
                .'</div>'
            .'</div>';
					$output.=drupal_render($form['form_build_id']);
					$output.=drupal_render($form['form_token']);
					$output.=drupal_render($form['form_id']);

					$submit_button = '';
					$submit_button .= '<div class="black_button">
																<a href="javascript:submit_reg_form();">
																<div class="black_button_left">
																		<div class="black_button_middle">
																		Save and Continue
																		</div>
																	<div class="black_button_right">
																	</div>
																</div>
																</a>
															</div>';
					$output.= '<div class="profile_category_header">'
											.$submit_button
										.'</div>';

 print_r($output);
 ?>