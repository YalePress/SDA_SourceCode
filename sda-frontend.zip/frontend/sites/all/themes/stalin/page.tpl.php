<?php
// $Id: page.tpl.php,v 1.28.2.1 2009/04/30 00:13:31 goba Exp $
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="<?php print $language->language ?>"
      xml:lang="<?php print $language->language ?>" dir="<?php print $language->dir ?>">
<head>
    <title>Stalin Digital Archive</title>
    <? print $head; ?>
    <? // see function sda_library_init() ?>
    <?= $styles ?>
    <script type="text/javascript">var debug_mode = <?= is_localhost() || isset($_GET['debug_mode']) ? '1' : '0'; ?>;</script>
    <?= js_fix_jquery_version($scripts); ?>
</head>
<body class="<?= arg(0) ?>">
<div style="position: relative;" id="page_root">
    <div>
        <? echo stalin_page_header($secondary_links, $primary_links); ?>

        <?php if ($title!='Confirmation page') echo $messages; ?><!--errors list-->

        <!-- <div class="page_scroller"> -->
        <table cellpadding="0" cellspacing="0" border="0" width="100%" class="content_table">
            <tr>
                <?//if ((arg(0)=='node')&&(arg(1)!=60)&&(arg(1)!=61)){?>
                <? if (arg(0)!='sda_viewer') { ?>
                <td valign="top" class="left_column_td">
                    <div class="left_column">
                        <? print $left; ?>
                    </div>
                </td>
                <? } ?>
                <td valign="top" width="100%" class="center">
                    <? if (arg(0) == 'admin'): ?>
                    <? if (!empty($breadcrumb)): ?>
                        <div id="breadcrumb"><?php print $breadcrumb; ?></div><? endif; ?>
                    <? if (!empty($mission)): ?>
                        <div id="mission"><?php print $mission; ?></div><? endif; ?>
                    <? if (!empty($title)): ?><h1 class="title" id="page-title"><?php print $title; ?></h1><? endif; ?>
                    <? endif; ?>

                    <div class="tabs"><? if (is_admin()) {
                        print $tabs;
                    } ?></div>

                    <div class="center_column">
                        <?php print $content; ?>
                    </div>
                </td>
                <? if (arg(0)!='sda_viewer') { ?>
                <td id="sidebar-right" valign="top">
                    <div class="right_column">
                        <?php print $right ?>
                    </div>
                </td>
                <? } ?>
            </tr>
        </table>
    </div>
</div>
<div id="footer">
    <? require "GA.php" ?>
    <?php print $footer_message ?>
    <?php print $footer ?>
    <?php print $closure; ?>
</div>
</body>
</html>
