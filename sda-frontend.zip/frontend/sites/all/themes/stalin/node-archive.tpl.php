<?php

// TODO: make this more optimal
header('Location: ' . base_path() . 'sda_viewer?n=' . $nid);
flush();
exit(0);