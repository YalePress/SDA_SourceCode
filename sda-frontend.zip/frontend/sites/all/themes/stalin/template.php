<?php

function top_menu($links, $attributes = array('class' => 'main-menu clearfix'))
{
    $output = '';
    //echo krumo($links);

    if (count($links) > 0) {
        $output = '<div class="top_menu">';

        $num_links = count($links);
        $i = 1;

        foreach ($links as $key => $link) {
            $class = $key;

            if ($i == 1) {
                $class .= ' first';
            }
            if ($i == $num_links) {
                $class .= ' last';
                //$class .= ' subscribe';
            }

            if ($i == $num_links - 1) {
                //$class .= ' login';
            }

            if (isset($link['href'])) {

                $output .= "<a href='" . url($link['href']) . "' class='" . $class . "'>" . $link['title'] . "</a>";

            }

            $i++;
        }
        $output .= '</div>';
    }
    return $output;
}

function stalin_theme()
{
    return array(
        'user_profile_form' => array(
            'arguments' => array('form' => NULL),
            'template' => 'user-profile',
        ),
        'user_register' => array(
          'arguments' => array('form' => NULL),
          'template' => 'user-register',
        ),
        'register_complete' => array(
          'arguments' => array('form' => NULL),
          'template' => 'user-register-complete',
        ),
        'user_login_block' => array(
          'arguments' => array('form' => NULL),
          'template' => 'user-login-block',
        ),
        'site_management_subscription_verification' => array(
          'arguments' => array('form' => NULL),
          'template' => 'subscription-verification',
        ),
        'contact_mail_user' => array(
          'arguments' => array('form' => NULL),
          'template' => 'contact-mail-user',
        ),
        'site_management_user_pass_reset' => array(
          'arguments' => array('form' => NULL),
          'template' => 'user-pass-reset',
        ),
    );
}

// TODO: rfct this
  function stalin_user_profile_form($form) {
    global $user;

    drupal_add_js('sites/all/themes/stalin/profile_form.js');
    drupal_add_css('sites/all/themes/stalin/profile_form.css');

    $output='';
    //var_dump($form);
    //$my=array();
    //$my['name']=$form['account']['name'];
    //$output .= drupal_render($my);

//    $about_category = 'About';
    $about_category = 'Account';

    $output .= '<div class="profile_header">'
        .$form['Account']['profile_first_name']['#default_value']
        .' '
        .$form['Account']['profile_last_name']['#default_value']
    .'</div>';

    foreach (drupal_get_messages() as $type => $messages) {
        $output .= "<div class=\"profile_messages_$type\">\n";
        if (count($messages) > 1) {
          $output .= " <ul>\n";
          foreach ($messages as $message) {
            $output .= '  <li>'. $message ."</li>\n";
          }
          $output .= " </ul>\n";
        }
        else {
          $output .= $messages[0];
        }
        $output .= "</div>\n";
    }

    // Don't show username field, but submit it, as otherwise we'll get error
    $form['account']['name']['#type'] = 'hidden';
    $output .= drupal_render($form['account']['name']);

    $output.='<div class="profile_category_section">'
        .create_profile_category_header('Password', true, 'return check_password_fields();')
        .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['account']['pass']['pass1']['#title'];
                    unset($form['account']['pass']['pass1']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['account']['pass']['pass1'])
                .'</div>'
            .'</div>'
        .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['account']['pass']['pass2']['#title'];
                    unset($form['account']['pass']['pass2']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['account']['pass']['pass2'])
                .'</div>'
            .'</div>'
        .'</div>'
            ;
    $output.='<div class="profile_category_section">'
        .create_profile_category_header('My Profile')
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_first_name']['#title'];
                    unset($form['Account']['profile_first_name']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_first_name'])
                .'</div>'
            .'</div>'
            .'<input type=hidden name="edit_form_picker" value="1">'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_last_name']['#title'];
                    unset($form['Account']['profile_last_name']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_last_name'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_my_bio']['#title'];
                    unset($form['Account']['profile_my_bio']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_my_bio'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['account']['mail']['#title'];
                    unset($form['account']['mail']['#title']);
                    unset($form['account']['mail']['#description']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['account']['mail'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_adress_1']['#title'];
                    unset($form['Account']['profile_adress_1']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_adress_1'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_adress_2']['#title'];
                    unset($form['Account']['profile_adress_2']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_adress_2'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_city']['#title'];
                    unset($form['Account']['profile_city']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_city'])
                .'</div>'
            .'</div>'
            .'<div id="state_wrapper" class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_state']['#title'];
                    unset($form['Account']['profile_state']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_state'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_zip']['#title'];
                    unset($form['Account']['profile_zip']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_zip'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_country']['#title'];
                    unset($form['Account']['profile_country']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_country'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_institution']['#title'];
                    unset($form['Account']['profile_institution']['#title']);
                    $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_institution'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form[$about_category]['profile_position']['#title'];
                    unset($form[$about_category]['profile_position']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_position'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form[$about_category]['profile_title']['#title'];
                    unset($form[$about_category]['profile_title']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_title'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form[$about_category]['profile_department']['#title'];
                    unset($form[$about_category]['profile_department']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_department'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form[$about_category]['profile_about_me']['#title'];
                    unset($form[$about_category]['profile_about_me']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_about_me'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form[$about_category]['profile_www']['#title'];
                    unset($form[$about_category]['profile_www']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_www'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form[$about_category]['profile_affiliations']['#title'];
                    unset($form[$about_category]['profile_affiliations']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_affiliations'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form[$about_category]['profile_optout']['#title'];
                    unset($form[$about_category]['profile_optout']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_optout'])
                .'</div>'
            .'</div>'

            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                         ."Research Interests";
                $output.='</div>'
                .'<div class="profile_item" style="position:relative; float: left;margin-top:10px">'
                .'<a class="active" onclick="show_select_research_interests(this);return false;" href="#">' . t('select from list:') . '</a>'
                .'<div class="hidden" id="view_options" style="width: 20em;">'
                      .drupal_get_form('select_research_interests_form')
                .'</div>'
                .'</div>'
            .'</div>'

        .'</div>';
    $output.='<div class="profile_category_section">'
        .create_profile_category_header('My picture')
            .'<div class="profile_item_wrapper  picture">'
                    .'<div class="profile_item_title">'
                        .$form['Account']['picture']['#title'];
                         unset($form['Account']['picture']['#title']);
                    $output.='</div>'
                    .'<div class="profile_item picture">'
                        .drupal_render($form['picture'])
                    .'</div>'
            .'</div>'
            .'</div>';
    $output.='<div class="profile_category_section">'
        .create_profile_category_header('My Profile Settings')

        .'<div class="profile_item_wrapper">'
            .'<div class="profile_item_title">'
                .$form['locale']['#title'];
                unset($form['locale']['#title']);
                unset($form['locale']['#description']);
            $output.='</div>'
            .'<div class="profile_item">'
                .drupal_render($form['locale'])
            .'</div>'
        .'</div>'
        .'<div class="profile_item_wrapper">'
            .'<div class="profile_item_title">'
//                .$form['timezone']['#title'];
                    . 'Time zone settings'; // TODO
                unset($form['timezone']['#title']);
                unset($form['timezone']['timezone']['#description']);
            $output.='</div>'
            .'<div class="profile_item">'
                .drupal_render($form['timezone'])
            .'</div>'
        .'</div>'

        .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_name_permission']['#title'];
                    unset($form['Account']['profile_name_permission']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_name_permission'])
                .'</div>'
            .'</div>'
        .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_email_permission']['#title'];
                    unset($form['Account']['profile_email_permission']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_email_permission'])
                .'</div>'
            .'</div>'
        .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_ardess_permission']['#title'];
                    unset($form['Account']['profile_ardess_permission']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_ardess_permission'])
                .'</div>'
            .'</div>'
        .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_institution_permission']['#title'];
                    unset($form['Account']['profile_institution_permission']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_institution_permission'])
                .'</div>'
            .'</div>'
        .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_picture_permission']['#title'];
                    unset($form['Account']['profile_picture_permission']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_picture_permission'])
                .'</div>'
            .'</div>'
        .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_my_bio_permission']['#title'];
                    unset($form['Account']['profile_my_bio_permission']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_my_bio_permission'])
                .'</div>'
            .'</div>'
    .'</div>';

    if($user->uid==1){ // TODO: change to is_admin() ?
    $output.='<div class="profile_category_section">'
        .create_profile_category_header('My Account')
        .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['Account']['profile_account_type']['#title'];
                    unset($form['Account']['profile_account_type']['#title']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_account_type'])
                .'</div>'
        .'</div>'
    .'</div>';

        $output.='<div class="profile_category_section">'
        .create_profile_category_header('Admin\'s settings')
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['account']['status']['#title'];
                    unset($form['account']['status']['#title']);
                    unset($form['account']['status']['#description']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['account']['status'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item_title">'
                    .$form['account']['roles']['#title'];
                    unset($form['account']['roles']['#title']);
                    unset($form['account']['roles']['#description']);
                $output.='</div>'
                .'<div class="profile_item">'
                    .drupal_render($form['account']['roles'])
                .'</div>'
            .'</div>';

        $output.='</div>';
     }
            ////// hidden form elements
// todo: make this through loop
         $output.=drupal_render($form['form_build_id']);

           $output.=drupal_render($form['form_token']);

           $output.=drupal_render($form['form_id']);
//***            $output.=drupal_render($form['locale']);
            ////////

        $output.='<div class="hidden">'
            .drupal_render($form['[#submit]'])
        .'</div>';
    return $output;
  }

function create_profile_category_header($section_name,$button_need=true,$onclick=NULL){
    $out='';
    $out.='<div class="profile_category_header">'
        .'<h1>'.$section_name.'</h1>';
        if($button_need)
            $out.='<input type="submit" value=" Apply " class="apply_button"'.($onclick ? " onclick='$onclick'" : '').'>';
        $out.='</div>';
    return $out;
}

function stalin_page_header($secondary_links,$primary_links, $node=null){
    return tpl(null, path_to_theme() . '/stalin_page_header.tpl.php',
               array(
                   'primary_links' => $primary_links,
                   'secondary_links' => $secondary_links,
                   'node' => $node,
               ));
}

function right_about_menu()
{
    global $base_url;
    $out .= '<div class="toggle slide" ><a href="' . $base_url . '/node/5" onclick="return false;">About SDA</a></div>
                <div class="slide_toggle" style="display: none;">';
    $menus = menu_tree_page_data('menu-aboutsda');
    global $base_url;
    foreach ($menus as $menu_item) {
        $out .= '<div class="toggle more"><a id="' . create_id($menu_item["link"]["href"]) . '" href="' . $base_url . '/' . $menu_item["link"]["href"] . '">' . $menu_item["link"]["link_title"] . '</a></div>';

    }

    $out .= '</div>';
    return $out;
}

/**
 * Outputs a context submenu appropriate for selected page
 *
 * You should place next snippet in left_menu_block:
 * <code>
 * <?
 * if (function_exists("left_menu_block")) {
 *  left_menu_block(array('About SDA', 'Resources')); // context submenu at left side
 * }
 * ?></code>
 * @param array $allowed_parents - list of parent menus for which submenu generation is allowed
 * @return void
 */
function left_menu_block($allowed_parents = array())
{
    //    echo menu_tree('primary-links');

    // this is a bit hack =(

    $q = $_GET['q'];

    $query = "SELECT mlp.mlid, mlp.link_title FROM {menu_links} mlp
    JOIN {menu_links} mlc ON mlp.mlid = mlc.plid
    WHERE mlc.link_path='%s'
    ";

    $parent_menu = db_fetch_array(db_query($query, $q));

    if ($parent_menu != false
        && (in_array($parent_menu['mlid'], $allowed_parents)
            || in_array($parent_menu['link_title'], $allowed_parents))) {

        $query = "SELECT link_path, link_title FROM {menu_links} ml
        WHERE ml.plid = %d AND ml.hidden = 0
        ORDER BY weight
        ";

        $child_links = db_get_list(db_query($query, $parent_menu['mlid']));

        ?>

    <div class="toggle slide unactive"><a href="#" id="5" onclick="return false;"><?= $parent_menu['link_title'] ?></a>
    </div>
    <div class="slide_toggle">
        <?

        foreach ($child_links as $lnk) {
            echo '<div class="toggle more"><a class="left_menu_link" id="' .
                 create_id($lnk["link_path"]) . '" href="' . base_path() . $lnk["link_path"] . '">' .
                 $lnk["link_title"] . '</a></div>';
        }

        ?>
    </div>
    <?
    }
}

function select_research_interests_form(){
    global $user;

    $query = "SELECT * FROM research_interests";
    $results = db_query($query);
    $res_int = array();
    while ($row = db_fetch_array($results)){
        $res_int[$row['id']]= $row['name'];
    }
    $options  = db_get_list ("select research_interest_id from research_interests_users where user_id={$user->uid}","research_interest_id");

    $form['profile_research_interest'] = array(
        '#type' => 'checkboxes',
        '#options' => $res_int,
        '#default_value' => $options,
        '#prefix' => '<div id="select_fields_to_view">',
        '#suffix' => '</div>'
    );

    return $form;
}

function stalin_form_element($element, $value) {
    $elements_array = array('edit-profile-first-name','edit-profile-last-name','edit-pass-pass1','edit-pass-pass2','edit-mail','edit-profile-institution-select','edit-profile-institution-other',
                            'edit-profile-adress-1','edit-profile-adress-2','edit-profile-city','edit-profile-state','edit-profile-zip',
                            'edit-profile-country','edit-profile-position','edit-profile-department','edit-profile-about-me','edit-profile-www',
                            'edit-profile-affiliations','edit-profile-facebook','edit-profile-twitter','edit-profile-otherprofiles',
                            'edit-picture-upload','edit-timezone-name','edit-profile-email-permission','edit-profile-email-preferences-1',
                            'edit-profile-email-preferences-2','edit-profile-name-permission');
    if (!in_array($element['#id'],$elements_array)) {
        return theme_form_element($element, $value);
    } else {
        // This is also used in the installer, pre-database setup.
        $t = get_t();

        $output = '<div class="form-item-title"';
        if (!empty($element['#id'])) {
        $output .= ' id="'. $element['#id'] .'-wrapper"';
        }
        $output .= ">\n";
        $required = !empty($element['#required']) ? '<span class="form-required" title="'. $t('This field is required.') .'">*</span>' : '';

        if (!empty($element['#title'])) {
        $title = $element['#title'];
        if (!empty($element['#id'])) {
          $output .= ' <label for="'. $element['#id'] .'">'. $t('!required !title:', array('!title' => filter_xss_admin($title), '!required' => $required)) ."</label>\n";
        }
        else {
          $output .= ' <label>'. $t('!required !title', array('!title' => filter_xss_admin($title), '!required' => $required)) ."</label>\n";
        }
        }
        $output .= "</div>\n";

        $output .= '<div class="form-item"';
        if (!empty($element['#id'])) {
        $output .= ' id="'. $element['#id'] .'-wrapper"';
        }
        $output .= ">\n";

        if (!empty($element['#extra_button'])) $value .= $element['#extra_button'];
        if (!empty($element['#help_description']) OR !empty($element['#help_example'])) {
        $output .= ' <div class="form-item-extended">';
          if (!empty($element['#help_description'])) {
            $output .= ' <div class="help_description">'. $element['#help_description'] ."</div>\n";
          }
          if (!empty($element['#help_example'])) {
            $output .= ' <div class="help_example">'. $element['#help_example'] ."</div>\n";
          }
          $output .= " $value\n</div>";
        } else $output .= " $value\n";

        if (!empty($element['#description'])) {
        $output .= ' <div class="description">'. $element['#description'] ."</div>\n";
        }

        $output .= "</div>\n";

        return $output;
    }
}

function stalin_form_render_disabled($title, $value, $description/*&$elements*/) {
  $content .= '<div class="form-item-title"><label>'.$title.':</label></div>';
  $content .= '<div class="form-item"><span style="line-height:1.5">'.$value.'</span></div>';
  $content .= '<div class="form-item-description"><span style="line-height:1.5">'.$description.'</span></div>';
  /*$content .= '<div class="form-item-title"><label>'.$elements['#title'].':</label></div>';
  $content .= '<div class="form-item"><span style="line-height:1.5">'.$elements['#value'].'</span></div>';*/
	return $content;
}

function stalin_form_render_profile_auth_codes($profile_individual_codes)
{
    $content = '';
    $codes = unserialize($profile_individual_codes);
    $content .= '<div class="profile_individual_codes">';
    if (is_array($codes)) {
        foreach ($codes as $code) {
            $content .= '<div class="form-item-code-title"><label>Verification code:</label></div>';
            $content .= '<div class="form-code-value">' . $code['#code'] . '</div>';
            $content .= '<div class="form-item-expiration-title"><label>Valid from:</label></div>';
            $content .= '<div class="form-expiration-value"><b>' . $code['#from_date'] . '</b> to <b>' . $code['#to_date'] . '</b></div>';
        }
    }
    $renew_button = '<div class="gray_button" id="renew_button">
                     <a target="_blank" href="'. getBlockContentByName('subscription_site_link') .'">
                       <div class="gray_button_left">
                         <div class="gray_button_middle">
                         Renew Subscription
                         </div>
                         <div class="gray_button_right">
                         </div>
                       </div>
                      </a>
                   </div>';
    $content .= $renew_button . '</div>';
    return $content;
}

function stalin_form_error_block($msg) {
	$content = '';
	$content .= '<div class="verify_error">'
	              .'<table>'
	                .'<tr>'
	                  .'<td><div class="verify_error_image"></div></td>'
	                  .'<td style="color:red">'.$msg.'</td>'
	                .'</tr>'
	              .'</table>'
              .'</div>';
	return $content;
}

function stalin_form_subscr_verification_ok($msg) {
	$content = '';
	$content .= '<div class="verify_success">'
	              .'<table>'
	                .'<tr>'
	                  .'<td><div class="verify_success_image"></div></td>'
	                  .'<td style="color:gray">'.$msg.'</td>'
	                .'</tr>'
	              .'</table>'
              .'</div>';
	return $content;
}

function stalin_preprocess_page(&$vars, $hook) {
  //<meta http-equiv="X-UA-Compatible" content="IE=8" />
}