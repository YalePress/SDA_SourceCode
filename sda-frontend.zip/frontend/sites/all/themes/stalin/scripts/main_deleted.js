
// TODO: DELME

        /*
         if (jQuery("#search_result_wrap").width()<900){
         jQuery("#snippet").width("180px");
         }     */


        if (jQuery('#block-block-8').length) {
            var loc = location.href;
            locs = loc.split('/');
            var i = 0;
            var j = 0;
            var new_loc = locs[0];
            for (var segm in locs) {
                i++;
            }
            selector = locs[i - 1];
            //console.log(selector);
            //console.log(jQuery('#'+selector));
            if (selector != 5) {
                jQuery('#5').addClass('active');
                jQuery('.slide_toggle').show();
                // console.log(jQuery('#'+selector));
                jQuery('#' + selector).addClass('active');
            }
            jQuery('li.menu-249').find('a').addClass('active');
            jQuery('li.menu-249').addClass('active active-trail active');

            jQuery('.left_menu_link').click(function() {
                //console.log(this);
                block_id = jQuery(this).attr('id');
                jQuery.post('post_echo_block', {block_id:block_id}, function(data) {
                    jQuery('.center_column').html(data);
                });

            });

            /* jQuery('#6').click(function(){
             block_id=15;
             jQuery.post('post_echo_block',{block_id:block_id},function(data){
             jQuery('.center_column').html(data);
             });

             }) ;
             jQuery('#8').click(function(){
             block_id=14;
             jQuery.post('post_echo_block',{block_id:block_id},function(data){
             jQuery('.center_column').html(data);
             });

             }) ;
             jQuery('#9').click(function(){
             block_id=13;
             jQuery.post('post_echo_block',{block_id:block_id},function(data){
             jQuery('.center_column').html(data);
             });

             }) ; */

            jQuery('#5').click(function() {
                //jQuery('#5').addClass('pushed active');
                //console.log(jQuery('#5'));
                //jQuery('.slide_toggle').show();
                jQuery('#9').click();
            });
        }


        if (jQuery('#block-block-10').length) {
            var loc = location.href;
            locs = loc.split('/');
            var i = 0;
            var j = 0;
            var new_loc = locs[0];
            for (var segm in locs) {
                i++;
            }
            selector = locs[i - 1];
            //console.log(selector);
            //console.log(jQuery('#'+selector));
            if (selector != 4) {
                jQuery('#4').addClass('active');
                jQuery('.slide_toggle').show();
                //console.log(jQuery('#'+selector));
                jQuery('#' + selector).addClass('active');
            }
            jQuery('li.menu-248').find('a').addClass('active');
            jQuery('li.menu-248').addClass('active-trail active');

            jQuery('.left_menu_link').click(function() {
                //console.log(this);
                block_id = jQuery(this).attr('id');
                jQuery.post('post_echo_block', {block_id:block_id}, function(data) {
                    jQuery('.center_column').html(data);
                });

            });
            /* jQuery('#10').click(function(){
             block_id=16;
             jQuery.post('post_echo_block',{block_id:block_id},function(data){
             jQuery('.center_column').html(data);
             });

             }) ;

             jQuery('#11').click(function(){
             block_id=18;
             jQuery.post('post_echo_block',{block_id:block_id},function(data){
             jQuery('.center_column').html(data);
             });

             }) ;
             jQuery('#12').click(function(){
             block_id=17;
             jQuery.post('post_echo_block',{block_id:block_id},function(data){
             jQuery('.center_column').html(data);
             });

             }) ;        */
            jQuery('#4').click(function() {
                jQuery('#11').click();
            });

        }

// ==========================

        /*  jQuery('.toggle a').click(function(){
         if (jQuery(this).hasClass('active'))
         {
         jQuery(this).removeClass('active');
         jQuery(this).parent().next().slideToggle(200);
         }
         else
         {
         jQuery(this).addClass('active');
         jQuery(this).parent().next().slideToggle(200);
         }
         });          */

            /*
             jQuery('.toggle.slide a.active').removeClass('active');




             if (jQuery(this).hasClass('active'))
             {
             jQuery(this).removeClass('active');
             //jQuery(this).parent().next().slideToggle(200);
             }
             else
             {
             jQuery(this).addClass('active');
             //jQuery(this).parent().next().slideToggle(200);
             jQuery(this).parent().next().slideDown(200);
             }
             */

        /*if (jQuery('#edit-list-or-snippets-list').checked==true){
         alert('11111');
         }                        */
