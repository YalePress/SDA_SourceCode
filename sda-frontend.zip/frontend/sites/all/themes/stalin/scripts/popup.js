jQuery.fn.alignCenter = function() {
    var object = jQuery(this);
    var marginLeft = - object.width() / 2 + 'px';
    var marginTop = - object.height() / 2 + 'px';
    object.css({'margin-left':marginLeft, 'margin-top':marginTop});
    return object;
};

jQuery.fn.popup_form_callback = function() {
    var popup = jQuery(this);
    popup.find('.popup_radio').click(function() {
        jQuery(this).addClass('active').siblings().removeClass('active')
    });
    popup.find('form').submit(function() {
        if (popup.find('.popup_submit_button').length)
            popup.find('.popup_submit_button').click()
        else return false;
    });
    popup.find('.select_value').click(function() {
        if (jQuery(this).hasClass('active'))
            jQuery(this).next().slideUp(200);
        else
            jQuery(this).next().slideDown(200);
        jQuery(this).toggleClass('active')
    });
    popup.find('.select_item').click(function() {
        jQuery(this).parent().slideUp(200).prev().html(jQuery(this).html()).removeClass('active')
    });
    popup.find('.popup_header img').click(function() {
        closePopup();
    });
    popup.find('.popup_close_button').click(function() {
        closePopup();
        return false;
    });
    return popup;
};

jQuery.fn.popup_content_editor = function() {
    var object = jQuery(this);
    object.find('a.save_doc').removeClass('hidden');
    object.find('a.show_pop_up_preview').addClass('hidden');
    object.find('a.close_popup').removeClass('hidden');
    object.find('#preview_doc_information').append(object.find('div.doc_prev_control'));
    if
        (jQuery('table.viewer_wrapper').length) {
        var node_id = jQuery('#current_node_id').html()
        object.find('#edit-new-discussion-document,#edit-new-tag-document').attr('value', node_id)
        object.find('#edit-new-discussion-document-wrapper,#edit-new-tag-document-wrapper').hide();
    }
    return object;
}

jQuery.fn.popup_new_tag_callback = function() {
    var object = jQuery(this);

    object.find('a.popup_submit_button').click(function() {
        var tags_string = object.find('#edit-new-tag-names').attr('value')
        var tags_document = object.find('#edit-new-tag-document').attr('value')
        url = this_base_url + "/node/create_new_tag";
        if (tags_string)
            jQuery.post(url, {tags_string:tags_string,tags_document:tags_document}, function(data) {
                jQuery('#my_tags_list').html(data);
                closePopup();
            });
        else alert('Enter tag name');
        return false;
    })
    return object;
}

jQuery(document).ready(function() {

    jQuery.fn.prepare_popup_for_more_info = function() {
        var image = jQuery('#popup .prew_doc_img img');
        if ((image.height() / image.width()) > (image.parent().height() / image.parent().width())) {
            image.height('100%')
        } else {
            image.width('100%')
        }
    };

    jQuery.fn.prepare_popup_for_login_page = function() {
        // jQuery(this).onClose(function(){
        jQuery(this).find("#user-login-form:first").find("input.error").removeClass('error');
        //})

    };

    jQuery.fn.prepare_popup_for_rate_form = function() {
        var object = jQuery(this);
        object.find('input:checked').parent().parent().addClass('selected')
        object.find('.form-item').click(function() {
            var new_rating = jQuery(this).find('input').attr('value')
            object.find('input').removeAttr('checked').parent().parent().removeClass('selected')
            for (i = 1; i <= new_rating; i++) {
                object.find('input[value=' + i + ']').attr('checked', 'checked').parent().parent().addClass('selected')
            }
        })

        object.find('.popup_submit_button').click(function() {
            var rating = object.find('input:checked:last').attr('value');
            var node_id = working_document
            if (!node_id) {
                closePopup();
                return false;
            }
            var url = this_base_url + '/node/rate_doc';
            jQuery.post(url, {rating:rating,node_id:node_id}, function(data) {

                jQuery('#popup_rate_form').html(data)
                closePopup();
            });
        })
        return object;
    }

    jQuery.fn.prepare_popup_for_save_doc_to_my_library = function() {
        var popup = jQuery(this);
        popup.find('#edit-add-document-tags-wrapper').hide();

        popup.find('.popup_submit_button').click(function() {

            var selected_folder = popup.find('#edit-select-folder').attr('value');
            var new_folder_name = popup.find('#edit-new-folder-name').attr('value');
            var document_tags = popup.find('#edit-add-document-tags').attr('value');
            if (selected_folder != 'new' || new_folder_name) {
                var url = this_base_url + '/node/save_docs_to_my_library';
                //var checked_documents=new Array();
                //checked_documents.push(jQuery('#current_node_id').html())
                var node_id = working_document;
                if (!node_id) {
                    closePopup();
                    return false;
                }
                var checked_documents = [node_id];
                jQuery.post(url, {
                    selected_folder:selected_folder,
                    new_folder_name:new_folder_name,
                    document_tags:document_tags,
                    'checked_documents[]':checked_documents
                }, function(data) {
                    console.log(data)
                    if (data.new_folder) {
                        jQuery('#popup_save_doc_to_my_library')
                            .find('#edit-select-folder')
                            .append('<option value="' + data.new_folder.id + '">' + data.new_folder.name + '</option>')
                    }
                    if (data.not_saved) {
                        var alert_text = 'Some documents were not saved:\n';
                        jQuery.each(data.not_saved, function(index, element) {
                            alert_text += element.reason + '\n'
                        })
                        alert(alert_text);
                    }
                    closePopup();
                    return false;
                }, 'json');
            }
            else if (selected_folder == 'new')
                alert('Enter folder name or choose existing folder');
            return false;
        });

    }

    jQuery.fn.prepare_popup_for_open_new_document = function() {
        var object = jQuery(this);
        object.find('#edit-open-doc-name-folder-wrapper').hide()

        object.find('#edit-select-folder').change(function() {
            var folder = jQuery(this).attr('value')
            if (folder == 'all_docs') {
                object.find('#edit-open-doc-name-folder-wrapper').hide()
                object.find('#edit-open-doc-name-all-wrapper').show()
            }
            else {
                var url = this_base_url + '/node/get_titles_by_folder';
                jQuery.post(url, {folder:folder}, function(data) {
                    object.find('#edit-open-doc-name-folder').html(data)
                    object.find('#edit-open-doc-name-folder-wrapper').show()
                    object.find('#edit-open-doc-name-all-wrapper').hide()
                });
            }
        })
        object.find('.popup_submit_button').click(function() {
            if (object.find('#edit-select-folder').attr('value') == 'all_docs')
                var select_field = object.find('#edit-open-doc-name-all')
            else var select_field = object.find('#edit-open-doc-name-folder')
            var node_id = select_field.attr('value')
            if (!jQuery('.pictogram.close_doc[name=' + node_id + ']').length && jQuery('iframe').length < 4) {
                var iframe = '<iframe onload="calculate_iframes_position()" name="node_wrapper_' + node_id + '" id="node_wrapper_' + node_id + '" src="' + this_base_url + '/node/node_iframe?node_id=' + node_id + '" scrolling=\'no\' frameBorder=\'0\' display="none"></iframe>';
                /*if(jQuery('iframe').length)
                 jQuery('iframe:last').after(iframe)
                 else
                 jQuery('.node').append(iframe)*/
                if (jQuery('.left_viewer_column iframe').length < 2) {
                    jQuery('.left_viewer_column').append(iframe)
                } else {
                    jQuery('.right_viewer_column').append(iframe)
                }
            }

            closePopup();
        });
        return object;
    }

    jQuery.fn.prepare_popup_for_new_bookmark_form = function() {
        var object = jQuery(this);
        object.find('#edit-new-bookmark-name').width('280px')
        object.find('.popup_submit_button').click(function() {
            var b_name = object.find('#edit-new-bookmark-name').attr('value')
            if (b_name) {
                closePopup();
                jQuery('.selected_text').wrapSelection().find('span.flags')
                    .after('<span class="bookmark_name">' + b_name + '</span>').parents('.text_wrapper').save_marks();
            }
            else alert('Enter Bookmark name')
        })
        return object;
    }

    jQuery.fn.prepare_popup_for_add_comment_form = function() {
        var object = jQuery(this);
        if (!object.find('#select_comment_visible').length) {
            object.find('#edit-new-comment-set-as-private-wrapper').addClass('unactive').click(function() {
                return false;
            })
        }
        object.find('input[name=new_comment_set_as]').change(function() {
            object.find('#select_comment_visible').toggleClass('hidden')
        })
        object.find('input[name=new_comment_visible]').change(function() {
            object.find('#select_groups').toggleClass('hidden')
        })
        object.find('.popup_submit_button').click(function() {
            var make_vis_to = object.find('#edit-new-comment-visible-all').attr('checked')
            if (make_vis_to == 'checked')
                make_vis_to = 'all'
            else make_vis_to = 'my_groups'

            var set_as = object.find('#edit-new-comment-set-as-private').attr('checked')
            if (set_as == 'checked')
                set_as = 'private'
            else set_as = 'public'

            var comment_text = object.find('#edit-new-comment-text').attr('value')
            if (comment_text) {
                url = this_base_url + "/node/add_comment";
                var node_id = jQuery('#current_node_id').html()
                var checked_groups = new Array();
                object.find('#select_groups input:checked').each(function() {
                    checked_groups.push(jQuery(this).attr('value'));
                });
                jQuery.post(url, {
                    comment_text:comment_text,
                    node_id:node_id,set_as:set_as,
                    make_vis_to:make_vis_to,
                    'checked_groups[]':checked_groups
                }, function(data) {
                    jQuery('.comments_text_area').html(data)
                    closePopup();
                });
            }

            else alert('Enter comment text');
        })

        return object;
    }

    jQuery.fn.prepare_popup_for_assign_new_tag_form = function() {
        var object = jQuery(this);
        object.find('#edit-new-tag-document-wrapper').hide()
        object.find('a.popup_submit_button').click(function() {
            var tags_string = object.find('#edit-new-tag-names').attr('value')
            var tags_document = jQuery('#current_node_id').html()
            url = this_base_url + "/node/assign_new_tag";
            if (tags_string)
                jQuery.post(url, {tags_string:tags_string,tags_document:tags_document}, function(data) {
                    jQuery('#document_tags_list').html(data);
                    closePopup();
                });
            else alert('Enter tag name');
            return false;
        })
        return object;
    }

    jQuery.fn.prepare_popup_for_start_new_discussion = function() {

        var popup = jQuery(this)
        popup.width('370px')
        popup.find('#edit-new-discussion-message-wrapper').width('349px')
        popup.find('#edit-new-discussion-document').width('332px')
        popup.find('#edit-new-discussion-document').change(function() {
            var doc_id = popup.find('#edit-new-discussion-document').attr('value');
            console.log(doc_id);
            if (doc_id != 'null') {
                jQuery('#docs_id').append(doc_id + ',');
                if (jQuery('#docs_title').html() == 'Discussion without document')
                    jQuery('#docs_title').html(popup.find('option[value="' + doc_id + '"]').html() + '<br>');
                else
                    jQuery('#docs_title').append(popup.find('option[value="' + doc_id + '"]').html() + '<br>');
            }
            else {
                jQuery('#docs_title').html('Discussion without document');
                jQuery('#docs_id').html('');
            }
        });
        popup.find('#edit-open-new-discussion-to').change(function() {
            if (jQuery(this).attr('value') == 'my_groups_selected') {
                jQuery('#select_groups').removeClass('hidden');
            }
            else
                jQuery('#select_groups').addClass('hidden');
        });
        popup.find('.popup_submit_button').click(function() {
            var new_discussion_name = popup.find('#edit-new-discussion-title').attr('value');
            var new_discussion_message = popup.find('#edit-new-discussion-message').attr('value');
            if (new_discussion_name && new_discussion_message) {
                var open_to = popup.find('#edit-open-new-discussion-to').attr('value')
                var doc_id = jQuery('#docs_id').html();
                var checked_groups = new Array();
                popup.find('#select_groups input:checked').each(function() {
                    checked_groups.push(jQuery(this).attr('value'));
                });

                var url = this_base_url + '/node/create_new_discussion';
                jQuery.post(url, {
                    new_discussion_name:new_discussion_name,
                    new_discussion_message:new_discussion_message,
                    open_to:open_to,
                    'checked_groups[]':checked_groups,
                    doc_id:doc_id
                }, function(data) {
                    alert(data)
                    closePopup();
                    if (jQuery('#my_sda_docs div.discussion_list_style').length) {
                        var discussion_list_style = jQuery('#my_sda_docs div.discussion_list_style').html();
                    }
                    else discussion_list_style = 'all_discussions'
                    show_discussion_list(discussion_list_style)
                });
            }
            else if (!new_discussion_name)
                alert('Enter discussion name');
            else
                alert('Cannot create discussion without Message');
            return false;
        });
        return popup;
    }

    jQuery.fn.select_name_variant_callback = function() {
        var object = jQuery(this)
        var popup = jQuery('#popup')
        popup.find('.name_variant').click(function() {
            popup.find('#edit-new-member-name').attr('value', jQuery(this).html());
            popup.find('#select_name_variant .name_variant').addClass('hidden');
        })
        return object;
    }


    jQuery.fn.prepare_popup_for_invite_new_member = function() {
        var popup = jQuery(this)
        var select_name_div = popup.find('#select_name_variant')
        ///????????? textfield
        popup.find('#edit-new-member-name').attr('autocomplete', 'off').focus();

        popup.find('#edit-new-member-name').keypress(function(eventObject) {
            var keycode = eventObject.which;
            if (keycode == 13) {
                if (select_name_div.find(':not(.hidden)').length) {
                    popup.find('#edit-new-member-name')
                        .attr('value', select_name_div.find('div.name_variant_selected').html());
                    select_name_div.find('.name_variant').addClass('hidden')
                }
                else {
                    popup.find('.popup_submit_button').click();
                }

                return false;
            }

        });

        popup.find('#edit-new-member-name').keyup(function(eventObject) {
            var keycode = eventObject.which;
            switch (keycode) {
                case 27:
                    closePopup();
                    return false;
                    break;
                case 40:
                    if (!select_name_div.find('div.name_variant_selected').length) {
                        popup.find('div.name_variant:first')
                            .addClass('name_variant_selected');
                    }
                    else if (select_name_div.find('div.name_variant_selected').next(':not(.hidden)').length) {
                        popup.find('div.name_variant_selected')
                            .removeClass('name_variant_selected')
                            .next().addClass('name_variant_selected');
                    }
                    select_name_div.select_name_variant_callback();
                    break;

                case 38:
                    if (!select_name_div.find('div.name_variant_selected').length) {
                        popup.find('div.name_variant:last')
                            .addClass('name_variant_selected');
                    }
                    else if (select_name_div.find('div.name_variant_selected').prev().length) {
                        popup.find('div.name_variant_selected')
                            .removeClass('name_variant_selected')
                            .prev().addClass('name_variant_selected');
                    }
                    select_name_div.select_name_variant_callback();
                    break;
                case 13:
                    break;
                default:
                    var name_to_search = popup.find('#edit-new-member-name').attr('value')
                    if (name_to_search) {
                        popup.find('.name_variant').removeClass('name_variant_selected').addClass('hidden').parent().find('.name_variant[name ^="' + name_to_search.toUpperCase() + '"]').each(function(index, element) {
                            if (index < 15) jQuery(this).removeClass('hidden')
                            jQuery(this).prependTo(jQuery(this).parent())
                        })
                        select_name_div.select_name_variant_callback();
                    }
                    else {
                        popup.find('.name_variant').removeClass('name_variant_selected').addClass('hidden')
                    }
            }
            return false;
        });

        popup.find('.popup_submit_button').click(function() {
            var new_member_name = popup.find('#edit-new-member-name').attr('value');
            if (new_member_name) {
                var s = false;
                //s=true -> user-real
                popup.find('.name_variant').each(function(index, element) {
                    if (jQuery(element).html() == new_member_name) {
                        s = true;
                        new_member_id = jQuery(element).attr('index');
                    }
                });
                if (s == true) {
                    jQuery('#popup_invite_new_member .name_variant').each(function(index, element) {
                        if (jQuery(element).html() == new_member_name) {
                            jQuery(element).remove();
                        }
                    });
                    var group_id = jQuery('#my_sda_docs').find('#group_discussions_link a').attr('href');
                    var url = this_base_url + '/node/invite_new_group_member';
                    jQuery.post(url, {
                        new_member_name:new_member_name,
                        new_member_id:new_member_id,
                        group_id:group_id
                    }, function(data) {
                        //alert(data)
                        //console.log(jQuery('#result_invite'));
                        jQuery('#result_invite').html(data);
                        show_popup("result_invite_new_member");
                        //closePopup();
                    });
                }
                else
                    alert('Enter real member name');
            }
            else
                alert('Enter new member name');
            return false;
        });
        return popup;
    }

    jQuery.fn.prepare_popup_for_delete_inst_account = function() {
        var popup = jQuery(this);
        $('#popup #sel_users_div').html(get_selected_site_users());
        popup.find('.popup_submit_button').click(function() {
            if (true) {
                var url = this_base_url + '/admin/user/delete_inst_accounts_act';
                var checked_documents = new Array();
                $('table.my_sda_result tbody input:checked').each(function () {
                    checked_documents.push($(this).val());
                });
                //alert("qwe:"+checked_documents);
                jQuery.post(url, {
                    'checked_documents[]':checked_documents
                }, function(data) {
                    closePopup();
                    search_institutional_accounts(null, null);
                    return false;
                }, 'json');
            }
            return false;
        });
    };

    jQuery.fn.prepare_popup_for_block_inst_account = function() {
        var popup = jQuery(this);
        $('#popup #sel_users_div').html(get_selected_site_users());
        popup.find('.popup_submit_button').click(function() {
            if (true) {
                var url = this_base_url + '/admin/user/block_inst_accounts_act';
                var checked_documents = new Array();
                $('table.my_sda_result tbody input:checked').each(function () {
                    checked_documents.push($(this).val());
                });
                //alert("qwe:"+checked_documents);
                jQuery.post(url, {
                    'checked_documents[]':checked_documents
                }, function(data) {
                    closePopup();
                    search_institutional_accounts(null, null);
                    return false;
                }, 'json');
            }
            return false;
        });
    };

    jQuery.fn.prepare_popup_for_unblock_inst_account = function() {
        var popup = jQuery(this);
        $('#popup #sel_users_div').html(get_selected_site_users());
        popup.find('.popup_submit_button').click(function() {
            if (true) {
                var url = this_base_url + '/admin/user/unblock_inst_accounts_act';
                var checked_documents = new Array();
                $('table.my_sda_result tbody input:checked').each(function () {
                    checked_documents.push($(this).val());
                });
                //alert("qwe:"+checked_documents);
                jQuery.post(url, {
                    'checked_documents[]':checked_documents
                }, function(data) {
                    closePopup();
                    search_institutional_accounts(null, null);
                    return false;
                }, 'json');
            }
            return false;
        });
    };
    jQuery.fn.prepare_popup_for_save_checked_to_my_library = function() {
        var popup = jQuery(this);
        popup.find('.popup_submit_button').click(function() {
            var selected_folder = popup.find('#edit-select-folder').attr('value');
            var new_folder_name = popup.find('#edit-new-folder-name').attr('value');
            var document_tags = popup.find('#edit-add-document-tags').attr('value');
            if ((selected_folder != 'new' && selected_folder != 'clear') || new_folder_name) {
                var url = this_base_url + '/node/save_docs_to_my_library';
                var checked_documents = new Array();
                if (save_type == 'checked') {
                    checked_documents = get_checked_documents_ids()
                }
                else {
                    checked_documents.push(
                        popup.find('.node_id_to_save').html())
                }
                jQuery.post(url, {
                    selected_folder:selected_folder,
                    new_folder_name:new_folder_name,
                    document_tags:document_tags,
                    'checked_documents[]':checked_documents
                }, function(data) {
                    console.log(data)
                    if (data.new_folder) {
                        jQuery('#popup_save_checked_to_my_library')
                            .find('#edit-select-folder')
                            .append('<option value="' + data.new_folder.id + '">' + data.new_folder.name + '</option>')
                    }
                    if (data.not_saved) {
                        var alert_text = 'Some documents were not saved:\n';
                        jQuery.each(data.not_saved, function(index, element) {
                            alert_text += element.reason + '\n'
                        })
                        alert(alert_text);
                    }
                    closePopup();
                    return false;
                }, 'json');

            }
            else if (selected_folder == 'new' || selected_folder == 'clear')
                alert('Enter folder name or choose existing folder');
            return false;
        });
        popup.find("#edit-save-doc-to-my-library-cancel").click(function() {
            closePopup();
            return false;
        });
        return popup;
    }

    $.fn.prepare_popup_for_create_export_form = function () {
        var popup = $(this);

        popup.find('#export_btn').click(function () {
//            alert('Export');
            var checked_documents = get_checked_documents_ids();

            // Do nothing if nothing is selected.
            //if (checked_documents.length == 0) return false;

            var dest = popup.find('select[name=export_destination]').val();
            var type = popup.find('select[name=export_type]').val();
            var node_id = popup.find('input[name=node_id]').val();
            var is_login = popup.find('#is_login').html();
//            alert(dest + ' : ' + type);
            var size = checked_documents.length;
            if (size == 0) {
                checked_documents = [node_id];
            }

            var post_cfg = {
                'ids[]': checked_documents,
                citation_type: type,
                citation_dest: dest,
                node_id: node_id
            };

            var ids = '';
            if (size > 1) {
                $.each(checked_documents, function(i, value) {
                    ids += " " + value;
                });
            }
            else {
                ids = checked_documents;
            }
            ids = jQuery.trim(ids);

            if (dest == 'My SDA') {
                if (is_login == '1') {
                    $.post(this_base_url + '/node/save_citation_to_my_sda', post_cfg, function (result) {
                        closePopup();
//                    alert(result);
                    });
                }
                else show_popup('login_page');
            }
            else if (dest == 'RIS') {
                window.open(this_base_url + "/node/get_RIS?ids=" + ids, '_blank');
                closePopup();
            }
            else if (dest == 'TXT') {
                window.open(this_base_url + "/node/save_to_txt?ids=" + ids + "&citation_type=" + type, '_blank');
                closePopup();
            }

            else {
                $.post(this_base_url + '/node/get_citation_string', post_cfg, function (citation_str) {
                    closePopup();

                    if (dest == 'Print to screen') {
                        show_popup('create_show_citation_form');
                        get_popup().find('#citation_text').val(citation_str)
                    }
                    else {
                        // TODO
                        show_popup('create_show_citation_form');
                        get_popup().find('#citation_text').val(
                            'Sorry, exporting to ' + dest + ' not yet implemented.\n\n' + citation_str);
                    }
                });
            }

            return false;
        });
    };
    
    $.fn.prepare_popup_for_export_annotation_form = function () {
        var popup = $(this);
        
        popup.find('#export_ann_btn').click(function() {
//          alert('click');

          var dest = popup.find('select[name=export_destination]').val();
          var type = popup.find('select[name=export_type]').val();
          var node_id = popup.find('input[name=node_id]').val();
          var is_login = popup.find('#is_login').html();
          
          export_checked_annotations(dest, type, node_id);
          closePopup();
          
          return false;
        });
    }
});

function get_checked_documents_ids() {
    var checked_documents = [];

    // Correctly get document ids on My SDA folders and documents pages.
    var location = window.location.href;
    if (location.indexOf("node/13#page=folders") != -1) {
        var checked_folders = value_list(".check_one:checked");
        if (checked_folders.length == 0) {
            alert("Please select one or more folders");
            return checked_documents;
        }
        for (var i = 0; i < checked_folders.length; i++) {
            var docs_str = $("#docs_" + checked_folders[i]).html();
            var docs = docs_str.split(",");
            for (var j = 0; j < docs.length; j++) {
                checked_documents.push(docs[j]);
            }
        }
        return checked_documents;
    } else if (location.indexOf("node/13#page=folder") != -1) {
        checked_documents = value_list(".check_one:checked");
        if (checked_documents.length == 0) {
            alert("Please select one or more documents.");
        }
        return checked_documents;
    } else if (location.indexOf("node/13#page=docs_by_tags") != -1) {
        if ($('#search_results_snippets').hasClass('hidden')) {
            checked_documents = value_list("td.checkbox_cell input:checked");
        } else {
            checked_documents = value_list("div.save_checkbox input:checked");
        }
        return checked_documents;
    }

    var view_type;
    if ($('#view_options_button_list').hasClass('active')) {
        view_type = 'list';
    } else if ($('#view_options_button_details').hasClass('active')){
        view_type = 'details'
    } else {
        view_type = 'thumbnails';
    }

    switch (view_type) {
        case 'list':
            jQuery("#search_results_list").find("tbody input:checked").each(function(id) {
                checked_documents.push(jQuery(this).attr('value'));
            });
            jQuery("#sda_tags").find("tbody input:checked").each(function(id) {
                checked_documents.push(jQuery(this).attr('value'));
            });
            break;
        case 'details':
            jQuery("#search_results_details").find("tbody input:checked").each(function(id) {
                checked_documents.push(jQuery(this).attr('value'));
            });
            jQuery("#sda_tags").find("tbody input:checked").each(function(id) {
                checked_documents.push(jQuery(this).attr('value'));
            });
            break;
        case 'thumbnails':
            jQuery("#search_results_snippets").find(".save_checkbox input:checked").each(function(id) {
                checked_documents.push(jQuery(this).attr('value'));
            });
            break;
    }
    return checked_documents;
}

function perform_export() {
    var node_id = null;

    if (($('#search_results').length) || ($('#sda_tags').length)) {
        // search screen
        var checked_documents_ids = get_checked_documents_ids();
        if (checked_documents_ids.length == 0) {
            alert('Please select one or more documents.');
            return;
        } else {
//            alert(checked_documents_ids);
            node_id = checked_documents_ids[0]; // for now first only, TODO
        }
    } else {
        // node screen
//        alert('node screen');
    }

    show_popup('create_export_form');

    if (node_id != null) {
        get_popup().find('input[name=node_id]').val(node_id);
    }
}

function get_popup() {
    var popup = $('#popup');

    if (popup.length) {
        return popup;
    } else {
        return $('#popup', parent.document);
    }
}

//close pop-up box
function closePopup() {
    if (!jQuery('#dark_background').lenght) {
        var background = jQuery('#dark_background', window.parent.document)
        var popup = jQuery('#popup', window.parent.document)
    }
    else {
        var background = jQuery('#dark_background')
        var popup = jQuery('#popup')
    }
    background.addClass('hidden').removeAttr('style');
    popup.addClass('hidden');
    return false;
}

function show_popup(popup_id) {
    //when IE - fade immediately
    if (!$('#popup_' + popup_id).length) {
        return false;
    }

    if (!$('#dark_background').length) {
        var background = jQuery('#dark_background', window.parent.document);
        var popup = jQuery('#popup', window.parent.document);
        var height = $(window.parent.document).height();
    } else {
        background = jQuery('#dark_background');
        popup = jQuery('#popup');
        height = $(document).height();
    }

    if ($.browser.msie) {
        background.height(height).
            removeClass('hidden').fadeTo('slow', 0.7).click(function() {
                closePopup();
            });
//        background.height(height)
//            .removeClass('hidden').click(function() {
//                closePopup();
//            });
    }
    else
    //in all the rest browsers - fade slowly
    {
        background.height(height).
            removeClass('hidden').fadeTo('slow', 0.7).click(function() {
                closePopup();
            });
    }

    var text_to_copy = $('#popup_' + popup_id).children().clone();

    popup.html('')
        .append(text_to_copy)
        .removeClass('hidden')
        .alignCenter();

    popup.popup_form_callback(); // general popup configuration (close/cancel buttons handler, etc.)

    var prepare_function_name = 'prepare_popup_for_' + popup_id;

    if (prepare_function_name in popup) { // find custom configurator function
        popup[prepare_function_name]();
    } else { // Legacy: apply general configuration
        popup
            .popup_content_editor()
            .popup_new_tag_callback()
    }
    return false;
}

function perform_export_annotation() {
    var node_id = null;

    if (($('#search_results').length) || ($('#sda_tags').length)) {
        // search screen
        var checked_documents_ids = get_checked_documents_ids();
        if (checked_documents_ids.length == 0) {
            alert('Please select one or more documents.');
            return;
        } else {
//            alert(checked_documents_ids);
            node_id = checked_documents_ids[0]; // for now first only, TODO
        }
    } else {
        // node screen
//        alert('node screen');
    }

    show_popup('export_annotation_form');

    if (node_id != null) {
        get_popup().find('input[name=node_id]').val(node_id);
    }
}

function export_checked_annotations(dest, type, doc_id) {
    var checked_documents= [];
    var ann_checked_type = 'ann';
    var cur_doc = null;
    if (typeof(doc_id) != 'undefined') {
        cur_doc = doc_id;
    }
    if (window.location.href.indexOf("node/13#page=annotations") != -1) {
        checked_documents = value_list(".check_one:checked");
        /*$(".check_one:checked").each( function() {
         var ann_href = $(this).parent().next().children().attr('href');
         var start_index = $(this).parent().next().children().attr('href').indexOf('sda_viewer?n=')+13;
         var end_index = $(this).parent().next().children().attr('href').indexOf('&');
         var doc_num = ann_href.substr(start_index, end_index - start_index);
         checked_documents.push(doc_num);
         });*/
    } else {
        var ann_checked_type = 'doc';
        checked_documents = get_checked_documents_ids();
        if (checked_documents.length ==0 && cur_doc) {
            checked_documents = [cur_doc];
        }
    }
    var ids = checked_documents.join(',');
    if (dest=='TXT') {
        window.open(this_base_url + "/node/ann_save_to_txt?ids=" + ids + "&ann_type="+ann_checked_type+"&citation_type=" + type, '_blank');
    } else if (dest=='Print to screen') {
        window.open(this_base_url + "/node/get_annotation_string?ids=" + ids + "&ann_type="+ann_checked_type+"&citation_type=" + type, '_blank');
    } else {
        var post_cfg = {
            'ids': ids,
            ann_type: ann_checked_type,
            citation_type: type,
            ann_dest: dest,
        };
        $.post(this_base_url + '/node/get_annotation_string', post_cfg, function (ann_str) {
            closePopup();

            if (dest == 'Print to screen') {
                show_popup('create_show_ann_form');
                get_popup().find('#ann_text').val(ann_str)
            }
            else {
                // TODO
                show_popup('create_show_ann_form');
                get_popup().find('#ann_text').val(
                    'Sorry, exporting to ' + dest + ' not yet implemented.\n\n' + ann_str);
            }
        });
    }
}
