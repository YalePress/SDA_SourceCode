/*jQuery(document).ready(function(){

    var loc=location.href;
    locs=loc.split('/');
    var i=0;
    var j=0;
    var new_loc=locs[0];
    for (var segm in locs){
        i++;
    }           
    selector=locs[i-1];
    
    for (j=1;j<i-1;j++){
        new_loc=new_loc+"/"+locs[j];    
    }
    
    if (selector=='news'){
        console.log(jQuery('#news'));
        console.log(new_loc);
       // window.location=new_loc;
        jQuery('#news').click();
    }
    
    
    
    jQuery('#news').click(function() {
   // if (jQuery('#news').class()=="active"){
        url="news_updates_page";
         jQuery.post(url,{},function(data)
                    {
                        jQuery('.content').html(data);
                        //jQuery('.toggle more').removeClass('active');
                        
                    });
    });
    
   jQuery('#partners').click(function() {
  // if (jQuery('#partners').class()=="active"){
        url="partners_page";
         jQuery.post(url,{},function(data)
                    {
                        jQuery('.content').html(data);
                        //jQuery('.toggle more').removeClass('active');
                        
                    });
    });
    
    jQuery('#editors').click(function() {
    //if (jQuery('#editors').class()=="active"){ 
        url="editors_page";
         jQuery.post(url,{},function(data)
                    {
                        jQuery('.content').html(data);
                        //jQuery('.toggle more').removeClass('active');
                        
                    });
    });
    
   jQuery('#overview').click(function() {
       //if (jQuery('#overview').class()=="active"){
        url="owerwiew_page";
         jQuery.post(url,{},function(data)
                    {
                        jQuery('.content').html(data);
                        //jQuery('.toggle more').removeClass('active');
                        
                    });
    });
    
});     */

function delete_news(news,news_id){
    jQuery.post("delete_news",{news_id:news_id},function(data)
        {
          //console.log(jQuery(news).parent().parent());  
          jQuery(news).parent().parent().addClass("hidden");  
          //jQuery(news).parent().parent().style.display='none'; 
            //jQuery(news).style.display='none';
        }
    
    )
}

function add_news(){
    var news_text=jQuery('textarea#news_text').attr("value");
    //console.log(jQuery('textarea#news_text'));
    //alert (news_text);
    jQuery.post("add_news",{news_text:news_text},function(data)
        {
          //console.log(jQuery(news).parent().parent());  
          jQuery('#news_page').append(data);  
          //jQuery(news).parent().parent().style.display='none'; 
            //jQuery(news).style.display='none';
            jQuery('textarea#news_text').attr("value","");
        }
    )
}