var this_base_url = window.this_base_url || ''; // to make IDE happy - defined in page template
var is_login_user = window.is_login_user || ''; // -//-

jQuery(document).ready(function() {
    var win_height = (jQuery(window).height());
    var new_height = win_height - 34 - 122 - 69 - 8 - 5;

    // Adjust height in viewer because there is no footer there.
    // Fixed to remove white space in the right column.
    if (window.location.href.indexOf('sda_viewer') > 0) {
        new_height = new_height - 139;
    }
    jQuery('.content_table').height(new_height + 'px');

    jQuery('a.menu-268').addClass('blue_link');
    jQuery('a.menu-4').addClass('blue_link');
    jQuery('a.menu-1849').addClass('blue_link');//.addClass('unactive').attr('href','#').attr('title','Beta testing in progress, Log in disabled, registration is not part of Phase I testing')
    //if(jQuery('a.menu-21').length)
    //jQuery('a.menu-21').attr('href',this_base_url+'/user/'+current_user_id+'/edit')
    processTableSearchHeight();
    jQuery(window).resize(function() {
        processTableSearchHeight();
        var win_height = (jQuery(window).height());
        var new_height = win_height - 34 - 122 - 69 - 8 - 5;

        // Adjust height in viewer because there is no footer there.
        // Fixed to remove white space in the right column.
        if (window.location.href.indexOf('sda_viewer') > 0) {
            new_height = new_height - 139;
        }
        jQuery('.content_table').height(new_height + 'px');

    });

    jQuery('.toggle:not(.slide) a').click(function() {
        jQuery('.toggle a').removeClass('pushed');
        jQuery(this).addClass('pushed');
        //jQuery('.toggle a').removeClass('active');
        //jQuery(this).addClass('active');
    });

    jQuery('.toggle.more a').click(function() {
        if (jQuery(this).hasClass('active')) {
            jQuery(this).removeClass('active');
            jQuery(this).parent().parent().find('.slide_toggle:not(.no_slide)').slideUp(200);
        } else {
            //console.log(jQuery(this));
            jQuery(this).parent().parent().find('.slide_toggle:not(.no_slide)').slideUp(200);
            jQuery(this).parent().parent().find('.toggle a:not(.no_slide).active').removeClass('active');
            jQuery(this).addClass('active')
        }
    });

    jQuery('.toggle.slide.unactive a').click(function() {
        return false;
    });

    jQuery('.toggle.slide:not(.unactive) a').click(function() {
        if (jQuery(this).hasClass('active')) {
            jQuery(this).removeClass('active');
            jQuery(this).parent().next().slideUp(200);
            jQuery(this).parent().parent().find('.slide_toggle:not(.no_slide)').slideUp(200);
        } else {
            //console.log(jQuery(this));
            jQuery(this).parent().parent().find('.slide_toggle:not(.no_slide)').slideUp(200);
            jQuery(this).parent().parent().find('.toggle a:not(.no_slide).active').removeClass('active');
            jQuery(this).addClass('active').parent().next().slideDown(200);
        }
        return;
        // <removed>
    });

    if (!(jQuery('.menu-266').length)) {
        jQuery('.search_site').width('473');
    }
    else {
        jQuery('.search_site').width('355');
    }

    jQuery('.slide_toggle a').click(function() {
        //jQuery('.slide_toggle a').removeClass('active');
        //jQuery(this).addClass('active');
    });

    if (jQuery('table.search_result').length) {
        jQuery('table.search_result tr').hover(function() {
            jQuery(this).addClass('active');
        });
        jQuery('table.search_result tr').mouseleave(function() {
            jQuery(this).removeClass('active');
        });
    }

    /*
     $(".chronologically a").tooltip({
     track: true,
     delay: 0,
     showURL: false ,
     showBody: " - ",
     extraClass: "pretty"
     });*/
    if (jQuery('#frontend_items_cycle').length) {
        $('#frontend_items_cycle').cycle({
            fx:    'scrollHorz',
            speed:  800,
            delay: 0,
            timeout: 10000,
            next:   '.next_cycle',
            prev:   '.prev_cycle' ,
            pager: '.frontend_items_points'
        });
        jQuery('.frontend_items_points a').html('')
    }

    if (jQuery("#sda_updates").length) {
        jQuery("#sda_updates").jCarouselLite({
            btnNext: ".sda_updates .scroll_down",
            btnPrev: ".sda_updates .scroll_up",
            vertical: true,
            circular: false,
            visible: 4,
            speed: 400,
            start: 0
        });
    }
    if (jQuery("#around_web ul li").length) {
        //if (jQuery('#around_web').find)
        jQuery("#around_web").jCarouselLite({
            btnNext: ".around_web .scroll_down",
            btnPrev: ".around_web .scroll_up",
            vertical: true,
            circular: false,
            visible: 6,
            speed: 400,
            start: 0
        });
    }

    if (jQuery("#chronologically_browse").length) {
        jQuery("#chronologically_browse").jCarouselLite({
            btnNext: "#chronologically_browse_next",
            btnPrev: "#chronologically_browse_prev",
            vertical: false,
            circular: false,
            visible: 4,
            speed: 400,
            start: 0
        });
    }

    jQuery('#search').keypress(function(eventObject) {
        //console.log('111');
        var keycode = eventObject.which;
        if (keycode == 13) {
            //console.log('2222');
            global_search();

            return false;
        }

    });

    if (getUrlVars()['renew'] == '1') {
        $('div#back_gray').removeClass('hidden');
        $('div#subscription_renew_popup').removeClass('hidden');
    }

    subscription_checkbox_change();
    $("form#verify-subscription-form input[type='radio']").click( subscription_checkbox_change );

});

function processTableSearchHeight() {
    var win_height = (jQuery(window).height());
    win_height += 31;

    var right_content_height = win_height - 229;

    // search + browse
    jQuery(".right_content").height(right_content_height);
    // search only
    jQuery(".left_content").height(right_content_height + 57);// little higher as left search form has no title div as right

    jQuery(".page_scroller").height((win_height - 187) + "px");

    jQuery("#block-browse_archives-0 .content").height((win_height - 189) + "px");
    //jQuery("#block-my_sda-0 .content").height((win_height-189)+"px");
    jQuery("#block-my_sda-0 .content,#my_sda_docs").css('overflow', 'auto');

    var delta = 77;
    /*if(jQuery('.tabs').html()!='')
     delta=delta+21;*/
    if (jQuery('#pager').length) {
//        delta = delta;
    }
    jQuery(".search_result_wrap").height(right_content_height - delta);
}

function global_search() {
    //var url=this_url+"/node/global_search_result";
    var value = jQuery("input[name=search]").attr("value");
    //jQuery.post(url,{value:value},function(data)
    //  {
    //   alert (value);
    // window.location=this_url+"/node/global_search";
    var now_location = location.href;
    var now_loc = now_location.split('#');
    //console.log(now_loc[0]);
    if ((this_base_url + "/node/2") != now_loc[0]) {
        window.location = this_base_url + "/node/2#G#" + value;
    }
    else {
        //console.log(value);
        jQuery('#edit-keyword').attr("value", value);
        jQuery('#edit-search-submit').click();
        jQuery('#search').attr("value", "");
    }

    // alert(data);
    //jQuery("#global_search_result").html(data);
    //   });
}

function add_editors_pick(document_id) {
    jQuery.post('add_editors_pick', {document_id:document_id}, function(data) {
        jQuery('#add_editors_pick').hide();
        jQuery('#delete_editors_pick').show();
    });
}

function delete_editors_pick(document_id) {
    jQuery.post('delete_editors_pick', {document_id:document_id}, function(data) {
        jQuery('#delete_editors_pick').hide();
        jQuery('#add_editors_pick').show();
    });
}

function get_from_class(obj, key) {
    var attr = obj.attr('class');
    if (!attr) {
        return null;
    }
    var classes = attr.split(' ');
    for (var i = 0; i < classes.length; i++) {
        var c = classes[i];
        if (c.indexOf(key) == 0) {
            return c.substr(key.length).replace(/^_/, '');
        }
    }
    return null;
}

function make_resizable(resize_selector, minwidth, dependent_selector, on_stop) {
    minwidth = minwidth || 80;
    $(resize_selector).resizable({
        minWidth: minwidth,
        resize: function (event, ui) {
            var res = $(ui.element[0]);
            res.parent().innerWidth(res.innerWidth());
            if (dependent_selector) {
                var new_width = res.innerWidth();
                if (jQuery.browser.safari) new_width = new_width + 12;
                var index = jQuery(resize_selector).parent().index(res.parent());
                jQuery(dependent_selector).eq(index).innerWidth(new_width);
                jQuery(dependent_selector).each(function(i, element) {
                    if (i > index) {
                        jQuery(element).css('width', '')
                    }
                });
                jQuery(resize_selector).parent().each(function(i, element) {
                    if (i > index) {
                        jQuery(element).css('width', '')
                    }
                })
            }
        },
        stop: function () {
            $(resize_selector).each(function() {
                $(this).width($(this).parent().width() - ($(this).innerWidth() - $(this).width()));
            });
            if (on_stop) {
                on_stop();
            }
        }
    });
}

function submit_login_form(){
  $('form#user-login-form').submit();
}

function submit_verify_form(){
	$('form#verify-subscription-form').submit();
}

function back_gray_click() {
  $('div#back_gray').addClass('hidden');
  $('div#login_popup').addClass('hidden');
  $('div#subscription_renew_popup').addClass('hidden');
}

function getUrlVars(){
  var vars = [], hash;
  var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
  for(var i = 0; i < hashes.length; i++) {
  	hash = hashes[i].split('=');
  	vars.push(hash[0]);
  	vars[hash[0]] = hash[1];
  }
  return vars;
}

function subscription_checkbox_change() {
	var radio_type = $("form#verify-subscription-form input[type='radio']").filter( ":checked" );
	if (radio_type.val()=='new') {
		$("form#verify-subscription-form input[id='edit-mail']").removeClass('error');
		$("form#verify-subscription-form div[id='edit-mail-wrapper']").next('.login_item_error').text('');
		$("form#verify-subscription-form input[id='edit-mail']").attr('disabled', true);
		$("form#verify-subscription-form a[id='verify_button_link']").attr('href', 'javascript:redirect_verify_form()');
	} else {
		$("form#verify-subscription-form input[id='edit-mail']").attr('disabled', false);
		$("form#verify-subscription-form a[id='verify_button_link']").attr('href', 'javascript:submit_verify_form()');
	}
}

function redirect_verify_form() {
  var code = $("form#verify-subscription-form input[name='code']").val();
  if (code.length == '0') {
    submit_verify_form();
  } else {
    submit_verify_form();
    //window.location.href = this_base_url+'/user/register?code='+code;
  }
}