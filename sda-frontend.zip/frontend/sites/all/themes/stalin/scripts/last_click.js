jQuery(document).ready(function(){ 
var locate=location.hash;
           var loc=locate.split('#');
           var search='#search_'+loc[2];
        if(loc[1]=='S'){ 
            jQuery('#a_saved_search').click();
            console.log(jQuery(search)) ;
            jQuery(search).click();
            //show_one_saved_search('<a href="'+loc[2]+'"></a>')
        }
        
/* $('.menu-249').hover(
        function() {
            //$(this).addClass("active");
            alert(1);
            $(this).find('ul').stop(true, true); // останавливаем всю текущую анимацию
            $('#slide_main_sda').removeClass('hidden');
        },
        function() {
            $(this).removeClass("active");
            $('#slide_main_sda').slideUp('fast');
        }
    );*/
});