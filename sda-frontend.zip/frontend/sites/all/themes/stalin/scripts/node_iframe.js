var position='top';
var x_splitted=false;
var y_splitted=false;
var one_frames_column=false;
jQuery(window).load(function () {
/*jQuery.fn.calc_iframe_size=function(obj){
        if(!one_frames_column||x_splitted) return false;
        var height = jQuery(document).height();
        if(height<800) height=800;
        jQuery('#node_wrapper_'+this_node_id, window.parent.document).height(height + 'px'); 
    }*/
        
//////////////////
        //flours()
        
        add_my_title_to_control_panel()
        jQuery.fn.save_marks=function(){
            var text=jQuery(this)
            if(!text.hasClass('text_wrapper')) return false;
            var url=this_base_url+'/save_marks';
            var field=text.parent().parent().parent().parent().attr('id')
            var node_id=jQuery('#current_node_id').html()
            jQuery.post(url,{node_id:node_id,field:field,text:text.html()},function(data)
            {
                jQuery('#document_menu').bookmarks_list_callback()
            });
        }
        jQuery.fn.bookmarks_list_callback=function(){
            var append_strins='';
            jQuery(this).find('span.flags').each(function(){
                var flag=jQuery(this)
                var name=flag.next().html()
                var field=flag.parents('.slide_container').parent().attr('id')
                append_strins=append_strins+"<div class='one_bookmark'><a class=one_bookmark_name' href='#"+flag.attr('id')+"/"+field+"'>"+name+"</a></div>"
            }).hover(function(){
                jQuery(this).next().show()
            }).mouseleave(function(){
                jQuery(this).next().hide()
            })
            .parents('#document_menu').find('#document_bookmarks .slide_container').html(append_strins)
            .find('a').click(function(){
                jQuery('#document_bookmarks').slideUp(200).prev().find('a').removeClass('active')
                loc=jQuery(this).attr('href').split('#')[1].split('/');
                var id=loc[0]
                jQuery('#'+loc[1]).prev().find('a').addClass('active')
                jQuery('#'+loc[1]).slideDown(200).find('.textarea_scroller').scrollTo(jQuery('#'+id))
                return false;
            })
        }
        jQuery('.text_wrapper').bookmarks_list_callback()
        
        jQuery('.pictogram.minus').click(function(){
            window.parent.minimize(this_node_id)
            
        })
        jQuery('.pictogram.plus').click(function(){
            window.parent.maximize(this_node_id)
            
        })
        jQuery('.pictogram.multiple').click(function(){
            window.parent.close_doc(this_node_id)
        })
        
        /*
        processTabsSize()
        jQuery(window.parent.window).resize(function(){
            processTabsSize()
        });*/
        
        
        /*jQuery(window).resize(function(){
            jQuery('#document_bookmarks').bookmarks_list_callback()
        });
        
        jQuery(window).resize(function(){
            jQuery('#document_bookmarks').bookmarks_list_callback()
            processTabsSize()
        });*/
        
    
        jQuery('input[name=comment_type]').change(function(){
            if(jQuery(this).attr('value')=='my'){
                jQuery('.comment:not(.my)').hide()
            }
            else{
                jQuery('.comment').show()
            }
        })
    
        function img_switch(step) {
        var current = Number($('#page_number').attr('value'));

        if (isNaN(current)) {
            current = 1;
        }

        var total = Number($('#files_count').html().trim());

        // ..-4-1-2-3-4-1-2-...
        current--;
        current += step;
        current += total;
        current %= total;
        current++;

        $('#page_number').attr('value', current);

        jQuery.fn.axZm.zoomSwitch(current);
    }

        
        //calc_iframe_size() 
        
        jQuery('.viewer_controls .up').click(function() {
        img_switch(1);
        });
        jQuery('.viewer_controls .down').click(function() {
            img_switch(-1);
        });   
        jQuery('.operations').click(function(){
             jQuery(this).find('.op_arrow').toggleClass('active')
             jQuery(this).next().toggleClass('hidden')
             return false;
        }); 
        
        var highlight_selection=false;
        jQuery('.make_highlight').click(function(){
            highlight_selection=true;
            jQuery(this).parent().next().find('.text_wrapper').addClass('highlight_selection')
            return false;
        })
        jQuery('.text_wrapper').mouseup(function(){
            if (!highlight_selection) {
                return false;
            }
            else {
                jQuery('.highlight_selection').removeClass('highlight_selection')
                highlight_selection=false;
            //var text=jQuery(this).parent().next().find('span.text_wrapper')
            var text=jQuery(this)
            text.wrapSelection({make_highlight:true})
            text.save_marks();}
        })
        jQuery(':not(.make_highlight)').click(function(){
            highlight_selection=false;
            jQuery('.highlight_selection').removeClass('highlight_selection')
        })
        
        
        
         jQuery('.op_item').click(function(){
             jQuery(this).parent().addClass('hidden').prev().find('.op_arrow').removeClass('active')
             var index=jQuery(this).attr('index')
             switch (index){        
                 case '1':
                    show_popup('add_comment_form')
                 break;
                 case '2':
                    var text=jQuery(this).parent().addClass('hidden').parent().next().find('.text_wrapper')
                    jQuery('.text_wrapper').removeClass('selected_text')
                    text.addClass('selected_text')
                    show_popup('new_bookmark_form');
                    break;
                 case '3':
                    show_popup('assign_new_tag_form');
                 break;
                 case '4':
                    show_popup('rate_form'); 
                 break;
             }
             return false;
        });    
        
        jQuery('.text_header').click(function(){
           var win_height=jQuery('#node_wrapper_'+this_node_id, window.parent.document).height()
            if(one_frames_column&&!x_splitted){
               win_height=740+114;
            }
            var new_height=win_height-114;
            var new_text_height;
            var new_image_height;
            if(y_splitted){
                     new_text_height=new_height;
                     new_image_height=new_height;
            }else{
                if(!one_frames_column){
                    if(jQuery('.viewer_header').find('.header_arrow').hasClass('active')){
                        new_text_height=240;
                    }else{
                        new_text_height=new_height;   
                    }
                    new_image_height=new_height-240;
                }else{
                    new_text_height=new_height;
                    new_image_height=new_height;
                }
            }
            //if(!one_frames_column||x_splitted){
                if(jQuery(this).find('.header_arrow').hasClass('active')){
                 /*if(!jQuery('#page_number').length) {
                    return false;
                 }*/
                 jQuery(this).next().css('height',new_text_height+'px').slideUp(300)
                    .find('.textarea_scroller').css('max-height',new_text_height-116+'px')
                 jQuery(this).find('.header_arrow').removeClass('active')
                 jQuery('.viewer_header').next().css('height',new_image_height+'px').slideDown(300)
                 jQuery('.viewer_header').find('.header_arrow').addClass('active')
             }
             else{
                jQuery(this).next().css('height',new_text_height+'px').slideDown(300)
                    .find('.textarea_scroller').css('max-height',new_text_height-116+'px')
                jQuery(this).find('.header_arrow').addClass('active')
                if(y_splitted||x_splitted){
                    jQuery('.viewer_header').next().slideUp(300)
                    jQuery('.viewer_header').find('.header_arrow').removeClass('active')
                }
             }
            /*}else{
                if(jQuery(this).find('.header_arrow').hasClass('active')){
                    jQuery(this).next().slideUp(300)
                }else{
                    jQuery(this).next().slideDown(300)
                }
                jQuery(this).find('.header_arrow').toggleClass('active')
            } */
            
        });
        
        jQuery('.viewer_header').click(function(){
            var win_height=jQuery('#node_wrapper_'+this_node_id, window.parent.document).height()
            if(one_frames_column&&!x_splitted){
               win_height=740+114;
            }
            var new_height=win_height-114;
            var new_text_height;
            var new_image_height;
            if(y_splitted){
                     new_text_height=new_height;
                     new_image_height=new_height;
            }else{
                if(!one_frames_column){
                    if(jQuery(this).find('.header_arrow').hasClass('active')){
                        new_text_height=new_height;
                    }else{
                        new_text_height=240;
                    }
                    new_image_height=new_height-new_text_height;
                }else{
                    new_text_height=new_height;
                    new_image_height=new_height;
                }
            }
             if(jQuery(this).find('.header_arrow').hasClass('active')){
                 jQuery(this).next().slideUp(300)
                 jQuery(this).find('.header_arrow').removeClass('active')
                 jQuery('.text_header').next().css('height',new_text_height+'px').slideDown(300)
                    .find('.textarea_scroller').css('max-height',new_text_height-116+'px')
                 jQuery('.text_header').find('.header_arrow').addClass('active')
                 if(one_frames_column&&!x_splitted){
                     set_position('bottom')
                 }
             }
             else{
                //if(!jQuery('#page_number').length) return false;
                jQuery(this).next().css('height',new_image_height+'px').slideDown(300) 
                jQuery(this).find('.header_arrow').addClass('active')
                jQuery('.text_header').next().css('height',new_text_height+'px')
                if(y_splitted||x_splitted){
                    jQuery('.text_header').next().slideUp(300)
                    jQuery('.text_header').find('.header_arrow').removeClass('active')
                }
                     set_position('top')  
             }
        });
        jQuery('#page_number').keypress(function(eventObject) {
        var keycode = eventObject.which;
        if (keycode == 13) {
            img_switch(0);
        }
        });
          
            calkWinSize();
        $("a#full_screen").fancybox(
        {
            'transitionIn'    : 'elastic',
            'transitionOut'   : 'elastic',
            'titlePosition'   : 'outside',
            'overlayColor'    : '#000',
            'overlayOpacity'  : 0.9,
            'width'           : '100%',
            'height'          : '100%',
            'autoScale'       : false,
            'type'            : 'iframe'
        }
    );
    
        $(function() {
        $(".slider").slider({
            value: 11,
            min: 7,
            max: 25,
            step: 1,
            slide: function(event,ui) {
                jQuery(this).parent().parent().next().find('.text_wrapper').css('font-size',ui.value+'px').find('p,span,div').css('font-size',ui.value+'px')
            }
            });
        });
    
        jQuery('.size_bigger').click(function(){
            var textarea=jQuery(this).parent().parent().next().find('.text_wrapper')
            var size=parseInt(textarea.css('font-size'))
            if(size<25){
                textarea.css('font-size',size+1+'px').parent().parent().prev().find('.slider').slider({value:size})
                textarea.find('p,span,div').css('font-size',size+1+'px')
                
            }
            
        });
        jQuery('.size_less').click(function(){
            var textarea=jQuery(this).parent().parent().next().find('.text_wrapper')
            var size=parseInt(textarea.css('font-size'))
            if(size>7){
                textarea.css('font-size',size-1+'px').parent().parent().prev().find('.slider').slider({value:size})
                textarea.find('p,span,div').css('font-size',size+1+'px')
            }
            
        });

    $('#zoomNaviTable').appendTo('#axzmControls');
        });

        
function maximize_this(){
    jQuery('table.viewer_wrapper').show()
}
function minimize_this(){
    jQuery('table.viewer_wrapper').hide()
}
        
function calkWinSize() {
    var winWidth = jQuery(window).width();
    var winHeight = jQuery(window).height();
    var link = $("a#full_screen");
    link.attr("href", link.attr('href') + "?width=" + winWidth + "&amp;height=" + winHeight);
}

  function change_position(){
        if(position=='top'){
            set_position('bottom')
        }
        else{
            set_position('top')
        }
        return false;
    }
    
    function set_position(new_pos){
        /*if(!jQuery('#page_number').length){
            new_pos='bottom';
        }*/
        if(new_pos=='top'){
            if(!one_frames_column||x_splitted){
                return false;
                jQuery('#node_wrapper_'+this_node_id, window.parent.document).height(800 + 'px'); 
            }else{
                //if (!jQuery('#page_number').length) return false;
                jQuery('#doc_info_td').appendTo('#top_tr')
                set_doc_tabs_position('layers')
            }
        }
        else{
            jQuery('#doc_info_td').appendTo('#bottom_tr')
            if(one_frames_column&&!x_splitted){
                set_doc_tabs_position('side')
                jQuery('#node_wrapper_'+this_node_id, window.parent.document).height(1600 + 'px'); 
            }else{
                set_doc_tabs_position('layers')
            }
        }
        position=new_pos;
        return false;
    }


 
function addCallbacksToAxzm () {
    if (jQuery.axZm != undefined)
    if (jQuery.axZm.userFunc != undefined) {
//        console.info('OK');
        clearInterval(checkAxzmInitialized);
        jQuery.axZm.userFunc.onImageChange = function (info) {
            var zoomID = info.zoomID;
//            console.info('ZoomId: ' + zoomID);
            $('#page_number').attr('value', zoomID);
        }
        } else {
//        console.info('Still undefined');
    }
}
//
var checkAxzmInitialized = setInterval("addCallbacksToAxzm()", 100);


function flours(){  
    if(!jQuery('#page_number').length){
        set_doc_tabs_position('side')
    }
}

function set_doc_tabs_position(new_pos){
    if(new_pos=='side'){
        jQuery('#document_menu,#document_menu .toggle.slide,#document_menu .slide_toggle').addClass('side')
    }
    else{
        jQuery('#document_menu,#document_menu .toggle.slide,#document_menu .slide_toggle').removeClass('side')
    }
}

function processTabsSize()
{
    var win_height = (jQuery(window.parent.window).height());
    //jQuery(".viewer_body,#document_menu").height((win_height-339)+"px");
    //jQuery("#zoomAll").height((win_height-382)+"px");

}

function add_my_title_to_control_panel(){
    if(!jQuery('.documents_control_panel span[name='+this_node_id+']', window.parent.document).length){
        var title_html='<span class="document_title">'+this_node_title+'<span onclick="close_doc('+this_node_id+')" name="'+this_node_id+'" class="pictogram close_doc"></span></span>';
    jQuery('.documents_control_panel .add_document', window.parent.document).before(title_html)
    }
}

function set_splitted(win_parent, x_status,y_status,one_column){
   //console.log('set_splitted '+this_node_id)
   //console.log('x:'+x_status+' y:'+y_status+' one_column:'+one_column)
   //console.log(win_parent)
    /*if(jQuery('#node_wrapper_'+this_node_id, window.parent.document).parent().hasClass('minimized_iframes')){
       return false;
    } */
    x_splitted=x_status;
    y_splitted=y_status;
    one_frames_column=one_column;
    //console.log(this_node_id+' '+x_splitted+' '+y_splitted+' '+one_column)
    if(x_splitted){
            //jQuery('#node_wrapper_'+this_node_id, window.parent.document).css('width','50%')
            set_position('bottom')
    }else{
        //jQuery('#node_wrapper_'+this_node_id, window.parent.document).css('width','100%')
        if(!one_column)
            set_position('bottom')
        else{
            set_position('top')
        }
    }
    if(one_column&&!x_splitted){
        if(jQuery('.change_pos_button').hasClass('hidden')){
          jQuery('.change_pos_button').removeClass('hidden')
        jQuery('.panel_controls').width(jQuery('.panel_controls').width()+140+'px')  
        }
        
    }else{
        if(!jQuery('.change_pos_button').hasClass('hidden')){
        jQuery('.change_pos_button').addClass('hidden')
        jQuery('.panel_controls').width(jQuery('.panel_controls').width()-140+'px')}
    }
    var win_height;
    if(win_parent)
       win_height=jQuery(win_parent.window).height();
    if(win_height<800) win_height=800;
    if(one_column){
        jQuery('.left_viewer_column', win_parent.document).height(win_height+'px')
        jQuery('.right_viewer_column', win_parent.document).height('0px').width('100%')
    }else{
        jQuery('.left_viewer_column,.right_viewer_column', win_parent.document)
            .height(win_height+'px')
    }
    
    if(y_splitted){
        win_height=win_height/2;
        var new_height=win_height-114
        if(jQuery('#page_number').length){
            jQuery('.text_header').next().hide().css('height',new_height+'px')
                .find('.textarea_scroller').css('max-height',new_height-116+'px')
            jQuery('.text_header').find('.header_arrow').removeClass('active')
            jQuery('.viewer_header').next().show().css('height',new_height+'px')
            jQuery('.viewer_header').find('.header_arrow').addClass('active')
        }else{
            jQuery('.viewer_header').next().hide().css('height',new_height+'px')
            jQuery('.viewer_header').find('.header_arrow').removeClass('active')
            jQuery('.text_header').next().show().css('height',new_height+'px')
                .find('.textarea_scroller').css('max-height',new_height-116+'px')
            jQuery('.text_header').find('.header_arrow').addClass('active')
        }
    }else
    {
        var new_image_height=win_height-114-240;
        if(jQuery('#page_number').length){
            var new_text_height=6*40;
        }else{
            var new_text_height=win_height-114;
        }
        if(!x_splitted){
            if(one_frames_column){
                new_text_height=win_height-80;
                new_image_height=win_height-80;
            }else{
                //new_text_height=240;
                new_image_height=win_height-80-new_text_height;
            }
        } 
        if(jQuery('#page_number').length){
            jQuery('.text_header').find('.header_arrow').addClass('active')
            jQuery('.viewer_header').next().show().height(new_image_height+'px')
            jQuery('.viewer_header').find('.header_arrow').addClass('active')
        }
        else{
            jQuery('.viewer_header').next().hide().css('height',new_image_height+'px')
            jQuery('.viewer_header').find('.header_arrow').removeClass('active')
                .css('max-height',new_text_height-116+'px')
            jQuery('.text_header').find('.header_arrow').addClass('active')
        }
        jQuery('.text_header').next().show().height(new_text_height+'px')
                .find('#document_transcription,#document_translation')
                .css('max-height',new_text_height-76+'px')
        jQuery('.text_header').next()
        .find('.textarea_scroller').css('max-height',new_text_height-116+'px')
    }   
    jQuery('#node_wrapper_'+this_node_id, win_parent.document).height(win_height+'px')
}

function hide_control_panel(){
    if(jQuery('.show_control_panel').hasClass('hidden')){
        jQuery('.show_control_panel').removeClass('hidden')
       
    
   // jQuery('.panel_controls').width(jQuery('.panel_controls').width()+100+'px')
    }
    
}

function show_control_panel(){
    if(!jQuery('.show_control_panel').hasClass('hidden')){
        jQuery('.show_control_panel').addClass('hidden')
 
        //jQuery('.show_control_panel').
  // jQuery('.panel_controls').width(jQuery('.panel_controls').width()-100+'px')
    }
    
}