if (window.debug_mode === undefined) {
    var debug_mode = 0;
}

if (debug_mode) {
    // make chrome happy http://stackoverflow.com/questions/7825448/webkit-issues-with-event-layerx-and-event-layery
    $.event.props = $.event.props.join('|').replace('layerX|layerY|', '').split('|');
}

function emptyFn() {
}

if (!window.console || !debug_mode) {
    console = {log:emptyFn, info:emptyFn, warn:emptyFn, error:emptyFn};
}

if (!debug_mode) {
// IE < 9
// TODO: move to conditionally-included js file?
    if (window.console && typeof(window.console.time) == "undefined") {
        console.time = function (name, reset) {
            if (!name) {
                return;
            }
            var time = new Date().getTime();
            if (!console.timeCounters) {
                console.timeCounters = {}
            }
            var key = "KEY" + name.toString();
            if (!reset && console.timeCounters[key]) {
                return;
            }
            console.timeCounters[key] = time;
        };

        console.timeEnd = function (name) {
            var time = new Date().getTime();
            if (!console.timeCounters) {
                return;
            }
            var key = "KEY" + name.toString();
            var timeCounter = console.timeCounters[key];
            if (timeCounter) {
                var diff = time - timeCounter;
                var label = name + ": " + diff + "ms";
                console.info(label);
                delete console.timeCounters[key];
            }
            return diff;
        };
    }
}

$.each("time timeEnd profile profileEnd".split(" "), function (i, f) {
    if (!console[f]) {
        console[f] = emptyFn;
    }
});

function console_function (fname) {
    return $.browser.webkit ? $.proxy(console, fname) : console[fname];
}

p = console_function('info');
err = console_function('error');

function time(code) {
    console.time(code);
    var res = eval(code);
    console.timeEnd(code);
    return res;
}

function wait_till(condition_fn, action_fn, wait_name) {
    var dbg = 0;

    function waiter() {
        if (condition_fn()) {
            if (dbg && wait_name) {
                console.info(wait_name + ": OK");
            }
            clearInterval(waiterInterval);
            action_fn();
        } else {
            if (dbg && wait_name) {
                console.info(wait_name + ': not yet...');
            }
        }
    }

    var waiterInterval = setInterval(waiter, 100);
}

function tt(obj, txt) {
    if (typeof obj == 'string') {
        obj = $(obj);
    }

    obj.attr('title', txt);
    obj.tooltip({
        showURL:false,
        top:5
    });
}

$.fn.tt = function (tt_text) {
    tt(this, tt_text);
};

$.fn.selfOrParents = function (selector) {
    return this.parents(selector).andSelf().filter(selector);
};

$.fn.havingClass = function (cls, having) {
    if (having == undefined) {
        having = true;
    }

    var res = $([]);
    var cls_re = new RegExp('\\b' + cls + '\\b');

    for (var i = 0; i < this.length; i++) {
        var elt = this[i];
        var same_class = cls_re.test(elt.className);
        if (same_class && having
            || !same_class && !having) {
            res.push(elt);
        }
    }

    return res;
};

$.fn.hide_disable = function () {
    var self = $(this);
    self.hide();
    self.find('input,select,textarea').attr('disabled', 'disabled');
};

$.fn.show_enable = function () {
    var self = $(this);
    self.show();
    self.find('input,select,textarea').removeAttr('disabled');
};

function update_textarea_with_ckeditor(obj, mode) {
    if (!CKEDITOR) return;

    if (typeof obj == 'string') {
        obj = $(obj);
    }

    if (!obj.is('textarea')) {
        obj = obj.find('textarea');
    }

    obj.each(function() {
        var editor = CKEDITOR.instances[$(this)[0].id];
        if (!mode && editor) return;
        if (mode && editor) {
            editor.destroy(true);
        }
        CKEDITOR.replace( $(this)[0].id )
    });
}


function is_inside(container, elt) {
//    return $.contains(text_elt[0], range.startContainer) /* inside doc text */

    if (!container) {
        return false;
    }

    if (container.length) {
        container = container[0];
    }

    return $(elt).parents().indexOf(container) >= 0; /* works in IE */
}

function Conveyor() {
    this.functions = [];
}

Conveyor.prototype = {
    /**
     * @param f function(callback)
     */
    submit:function (f) {
        if (f instanceof Conveyor) {
            (function (conv) {
                f = function (cb) {
                    conv.go(cb);
                }
            })(f);
        }
        this.functions.unshift(f);
    },

    submitAsync:function (f) {
        this.submit(function (cb) {
            setTimeout(function () {
                f();
                cb();
            }, 1);
        });
    },

    /**
     * @param lst list to process
     * @param f f(list) function processing input list by sublists of len step
     * @param step
     */
    submitAsyncList:function (lst, f, step) {
        do {
            var part = lst.slice(0, step);
            lst = lst.slice(step);
            this.submitAsync((function (_part) {
                return function () {
                    f(_part)
                }
            })(part));
        } while (lst.length);

    },

    go:function (cb) {
        var ff = cb || function () {
        };

        for (var i = 0; i < this.functions.length; i++) {
            (function (f) {
                (function (old_ff) {
                    ff = function () {
                        f(old_ff);
                    }
                })(ff);
            })(this.functions[i]);
        }

        ff();
    }
};