<?
  drupal_add_js('misc/ahah.js');
  drupal_add_js('sites/all/themes/stalin/profile_form.js');
  drupal_add_css('sites/all/themes/stalin/profile_form.css');
  drupal_add_css('sites/all/themes/stalin/style/user-login-block.css');

  $errors = form_get_errors();

  $form['code_type']['#required'] = false;
  $form['code']['#required'] = false;

  $output='';
  $output .='<div class="subscription_description">'
              .'<div class="subscription_description_header">'
                .'Subscription Verification:'
              .'</div>'
              .'<div class="subscription_description_text">'
               .'You must have a current and verified subscription in order to access the full features of the SDA.'
              .'</div>'
            .'</div>';

  unset($form['code_type']['#title']);
  //$form['code_type']['#default_value'] = 0;
  $form['code_type']['#attributes'] = array('onClick' => 'javascript:subscription_checkbox_change()');
  $output .= '<div class="login_item">'
              .'<div class="login_item_header">'
                .'I am verifying a:'
              .'</div>'
              .drupal_render($form['code_type'])
            .'</div>';

  unset($form['mail']['#title']);
  //$form['mail']['#prefix'] = 'description';
  $output .= '<div class="login_item left_shift">'
              .'<div class="login_item_mail_description">'
                .'Email address on your subscription account:'
              .'</div>'
              .drupal_render($form['mail'])
              .'<div class="login_item_error">'
                .$errors['mail']
              .'</div>'
            .'</div>';

  unset($form['code']['#title']);
  $output .= '<div class="login_item">'
              .'<div class="login_item_header">'
                .'Enter your 10-digit verification code:'
              .'</div>'
              .drupal_render($form['code'])
              .'<div class="login_item_error">'
                .$errors['code']
              .'</div>'
            .'</div>';

  $verify_button = '';
  $verify_button.= '<div class="gray_button" id="verify_button">
                        <a id="verify_button_link" href="javascript:submit_verify_form();">
                        <div class="gray_button_left">
                          <div class="gray_button_middle" id="verify_button_middle">
                            <b>Activate</b>
                          </div>
                          <div class="gray_button_right">
                          </div>
                        </div>
                        </a>
                      </div><input id="verify_submit" type="submit" hidefocus="true">';
  $verify_result = '<div class="clear"></div>';
  if (isset($errors['mail']) || isset($errors['code'])) {
  	if ($form['mail']['#value']=='' || $form['code']['#value']=='') {
  		$verify_result = stalin_form_error_block('Information missing. See details above.').'<div class="clear"></div>';
  	} else {
      $verify_result = stalin_form_error_block('Invalid information. See details above.').'<div class="clear"></div>';
    }
  } else {
  	$verify_result = drupal_render($form['mark']).'<div class="clear"></div>';
  }
  $output.= $verify_button.$verify_result;

  $items_help = array();
  $items_help[]= l(t('Need help? Contact us'), 'node/16', array('attributes' => array('title' => t('Need help? Contact us'))));
  $form['help_links'] = array('#value' => theme('item_list', $items_help));
  $output.= '<div class="login_item">'
              .'<div class="login_item_link_question">'
                .drupal_render($form['help_links'])
              .'</div>'
            .'</div>';

  $output.=drupal_render($form['form_build_id']);
  $output.=drupal_render($form['form_token']);
  $output.=drupal_render($form['form_id']);

  echo $output;
  //$msg = drupal_get_messages();

  //print_r($form);
?>