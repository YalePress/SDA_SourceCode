<!--<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <title>Global Search</title>
    <?php print $styles ?>
    <?php print $scripts ?>  
    <link rel="stylesheet" type="text/css" href="<?//=base_path() . path_to_theme()?>/style/jNice.css" />
    <link rel="stylesheet" type="text/css" href="<?//=base_path() . path_to_theme()?>/style/jquery.tooltip.css" />
    <link rel="stylesheet" type="text/css" href="<?//=base_path() . path_to_theme()?>/style/main.css" />
    <script type="text/javascript" src="<?//=base_path() . path_to_theme()?>/scripts/jquery-1.6.2.min.js"></script>
    <script type="text/javascript" src="<?//=base_path() . path_to_theme()?>/scripts/jquery.jNice.js"></script>
    <script type="text/javascript" src="<?//=base_path() . path_to_theme()?>/scripts/jquery.tooltip.js"></script>
    <script type="text/javascript" src="<?//=base_path() . path_to_theme()?>/scripts/jquery.cycle.js"></script>
    <script type="text/javascript" src="<?//=base_path() . path_to_theme()?>/scripts/jquery.jcarousellite.js"></script>
    <script type="text/javascript" src="<?//=base_path() . path_to_theme()?>/scripts/main.js"></script>
</head>
<body style="overflow: auto;">
   <?global $base_url;?>
     <? echo stalin_page_header($secondary_links,$primary_links); ?> 
    <div class="main">
        <div class="block_inner">                                     -->
            <table cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td class="left_main">
                        <div class="search_results">
                            <div class="search_results_title">Search Results</div>
                            <form action="">
                                <table class="search_form" cellpadding="0" cellspacing="0" width="100%">
                                    <tr>
                                        <td width="100%">
                                            <div class="search_word"><input type="text" name="search" /></div>
                                        </td>
                                        <td>
                                            <input type="image" alt="Search" src="images/search_submit.png" />
                                        </td>
                                    </tr>
                                </table>
                            </form>
                            <div class="search_results_count">1-10 of 4,215 results for <b>editorial team</b></div>
                            <div class="pagination top">
                                <ul>
                                    <li class="prev"><a href="#"></a></li>
                                    <li><a href="#">1</a></li>
                                    <li><span>2</span></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">6</a></li>
                                    <li><a href="#">...</a></li>
                                    <li><a href="#">21</a></li>
                                    <li><a href="#">22</a></li>
                                    <li class="next"><a href="#"></a></li>
                                </ul>
                            </div>
                            <ol class="search_items">
                                <li>
                                    <div class="search_title"><h3>Headline Goes Here</h3></div>
                                    <div class="search_text">Completely impact editorial team and wireless supply chains. Dynamically engage business meta-services for
market-driven data. Collaboratively restore cross-platform users before client-centered manufactured...</div>
                                    <a href="#">http://www.link.com</a>
                                </li>
                                <li>
                                    <div class="search_title"><h3>Headline Goes Here</h3></div>
                                    <div class="search_text">Completely impact editorial team and wireless supply chains. Dynamically engage business meta-services for
market-driven data. Collaboratively restore cross-platform users before client-centered manufactured...</div>
                                    <a href="#">http://www.link.com</a>
                                </li>
                                <li>
                                    <div class="search_title"><h3>Headline Goes Here</h3></div>
                                    <div class="search_text">Completely impact editorial team and wireless supply chains. Dynamically engage business meta-services for
market-driven data. Collaboratively restore cross-platform users before client-centered manufactured...</div>
                                    <a href="#">http://www.link.com</a>
                                </li>
                                <li>
                                    <div class="search_title"><h3>Headline Goes Here</h3></div>
                                    <div class="search_text">Completely impact editorial team and wireless supply chains. Dynamically engage business meta-services for
market-driven data. Collaboratively restore cross-platform users before client-centered manufactured...</div>
                                    <a href="#">http://www.link.com</a>
                                </li>
                                <li>
                                    <div class="search_title"><h3>Headline Goes Here</h3></div>
                                    <div class="search_text">Completely impact editorial team and wireless supply chains. Dynamically engage business meta-services for
market-driven data. Collaboratively restore cross-platform users before client-centered manufactured...</div>
                                    <a href="#">http://www.link.com</a>
                                </li>
                                <li>
                                    <div class="search_title"><h3>Headline Goes Here</h3></div>
                                    <div class="search_text">Completely impact editorial team and wireless supply chains. Dynamically engage business meta-services for
market-driven data. Collaboratively restore cross-platform users before client-centered manufactured...</div>
                                    <a href="#">http://www.link.com</a>
                                </li>
                                <li>
                                    <div class="search_title"><h3>Headline Goes Here</h3></div>
                                    <div class="search_text">Completely impact editorial team and wireless supply chains. Dynamically engage business meta-services for
market-driven data. Collaboratively restore cross-platform users before client-centered manufactured...</div>
                                    <a href="#">http://www.link.com</a>
                                </li>
                                <li>
                                    <div class="search_title"><h3>Headline Goes Here</h3></div>
                                    <div class="search_text">Completely impact editorial team and wireless supply chains. Dynamically engage business meta-services for
market-driven data. Collaboratively restore cross-platform users before client-centered manufactured...</div>
                                    <a href="#">http://www.link.com</a>
                                </li>
                            </ol>
                            <div class="pagination bottom">
                                <ul>
                                    <li class="prev"><a href="#"></a></li>
                                    <li><a href="#">1</a></li>
                                    <li><span>2</span></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">6</a></li>
                                    <li><a href="#">...</a></li>
                                    <li><a href="#">21</a></li>
                                    <li><a href="#">22</a></li>
                                    <li class="next"><a href="#"></a></li>
                                </ul>
                            </div>                            
                        </div>                    
                            
                    </td>
                    <td class="right_main">
                        <div class="right_title">Headlines &amp; Updates</div>
                        <div class="right_sub_title">around the web</div>
                        <div class="updates" id="around_web">
                            <ul class="update">
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_title"><a href="#">Blog Post Title Goes Here</a></div>
                                    <div class="update_desc">Suspendisse porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                    <div class="update_author">via <a href="№">Blog Name</a></div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_title"><a href="#">Blog Post Title Goes Here</a></div>
                                    <div class="update_desc">Suspendisse porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                    <div class="update_author">via <a href="№">Blog Name</a></div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_title"><a href="#">Blog Post Title Goes Here</a></div>
                                    <div class="update_desc">Suspendisse porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                    <div class="update_author">via <a href="№">Blog Name</a></div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_title"><a href="#">Blog Post Title Goes Here</a></div>
                                    <div class="update_desc">Suspendisse porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                    <div class="update_author">via <a href="№">Blog Name</a></div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_title"><a href="#">Blog Post Title Goes Here</a></div>
                                    <div class="update_desc">Suspendisse porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                    <div class="update_author">via <a href="№">Blog Name</a></div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_title"><a href="#">Blog Post Title Goes Here</a></div>
                                    <div class="update_desc">Suspendisse porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                    <div class="update_author">via <a href="№">Blog Name</a></div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_title"><a href="#">Blog Post Title Goes Here</a></div>
                                    <div class="update_desc">Suspendisse porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                    <div class="update_author">via <a href="№">Blog Name</a></div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_title"><a href="#">Blog Post Title Goes Here</a></div>
                                    <div class="update_desc">Suspendisse porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                    <div class="update_author">via <a href="№">Blog Name</a></div>
                                </li>
                            </ul>
                        </div>
                        <div class="show_more">
                            <a href="#">Show More Posts</a>
                            <div class="controls around_web">
                                <div class="scroll_up disabled"></div>
                                <div class="scroll_down"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        
                        <div class="right_sub_title">SDA UPDATES</div>
                        <div class="updates" id="sda_updates">
                            <ul class="update">
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_desc">Suspendisse porta ante ac elit ultrices ut sollicitudin metus ornare... </div>                                    
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_desc"><a href="#">Document Title X </a> porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_desc"><a href="#">Document Title X </a> porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_desc"><a href="#">Document Title X </a> porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_desc"><a href="#">Document Title X </a> porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_desc"><a href="#">Document Title X </a> porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_desc">Suspendisse porta ante ac elit ultrices ut sollicitudin metus ornare... </div>                                    
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_desc"><a href="#">Document Title X </a> porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_desc"><a href="#">Document Title X </a> porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_desc"><a href="#">Document Title X </a> porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_desc"><a href="#">Document Title X </a> porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                </li>
                                <li>
                                    <div class="update_date">June 19, 2011 at 4:30 pm</div>
                                    <div class="update_desc"><a href="#">Document Title X </a> porta ante ac elit ultrices ut sollicitudin metus ornare... </div>
                                </li>
                            </ul>
                        </div>
                        <div class="show_more">
                            <a href="#">Show More Posts</a>
                            <div class="controls sda_updates">
                                <div class="scroll_up disabled"></div>
                                <div class="scroll_down"></div>
                            </div>
                        </div>
                    </td>
                </tr>
            </table>
            <div class="clear"></div>
        </div>        
    </div>
    <div id="footer">
        <div class="block_inner">
            <div class="footer_menu">
                <ul>
                    <li><a href="#">yale university press</a></li>
                    <li><a href="#">terms &amp; conditions</a></li>
                    <li><a href="#">terms &amp; conditions</a></li>
                </ul>
                <div class="clear"></div>
            </div>
        </div>
    </div>
</body>
</html>