<?php
// $Id: page.tpl.php,v 1.28.2.1 2009/04/30 00:13:31 goba Exp $
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="<?php print $language->language ?>" xml:lang="<?php print $language->language ?>" dir="<?php print $language->dir ?>">
<head>
    <title>Stalin Digital Archive</title>
    <?php print $head; ?>
    <?php print $styles ?>
    <?php print js_fix_jquery_version($scripts); ?>
</head>
<body>
<?php //print $messages ?>
<? echo stalin_page_header($secondary_links,$primary_links, $node); ?>
     <div class="main">
        <div class="block_inner">
            <table cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td class="left_login">
                        <?
                            $block = module_invoke('block', 'block', 'view', 26);
                            echo $block['content'];
                        ?>
                    </td>
                    <td class="right_login">
                        <div class=login_left_header>Log In to SDA</div>
                        <!-- <h3>Registered Users</h3> -->
                        <?php
                        $block = module_invoke('user', 'block', 'view', 0);
                        print $block['content'];
                        if (!isIpAuthorized())
                        {
                        	//$block1 = module_invoke('site_management', 'block', 'view', 0);
                        	//print $block1['content'];
                          print drupal_get_form('site_management_subscription_verification');
                        }
                        ?>
                        <!-- <a href="<?php echo base_path() ?>node/16">Forgot your password?</a> -->
                        <!--
                        <a href="<?php //echo base_path() ?>user/register">Register an account.</a>
                        <? //if( !isIpAuthorized()) { ?>
                        <br><a href="<?php //echo base_path() ?>node/code_registration">Enter activation code.</a>
                        <? //}; ?>
                        -->
                    </td>
                </tr>

            </table>
            <div class="clear"></div>

        </div>
    </div>

    <!--<div id="content">
    <a href="http://yalepress.yale.edu/yupbooks/book.asp?isbn=9780300111699" target="blank">
        <img src="<?=base_path() . path_to_theme()?>/images/screen_from_YUP.png" alt="Yale University press" />
    </a>

    <div id="login_form_wrapper">
        <?php
            $block = module_invoke('user', 'block', 'view', 0);
            print $block['content'];
            ?>
    </div>-->

<div id="footer">
    <? require "GA.php" ?>
  <?php print $footer_message ?>
  <?php print $footer ?>
</div>
</body>
</html>
