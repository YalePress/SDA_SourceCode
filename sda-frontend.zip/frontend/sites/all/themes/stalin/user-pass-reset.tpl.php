<?php
    drupal_add_js('sites/all/themes/stalin/user-register.js');
    drupal_add_css('sites/all/themes/stalin/user-register.css');

    $submit_button .= '<div class="user_verification_item">
                        <div class="black_button">
                          <a href="javascript:submit_user_pass_reset_form();">
                          <div class="black_button_left">
                              <div class="black_button_middle">'
                                .$form['submit']['#value']
                              .'</div>
                            <div class="black_button_right">
                            </div>
                          </div>
                          </a>
                        </div>
                      </div>';

    $output = '';
    $output .= '<div class="user_verification_item_wrapper">'
              .'<div class="user_verification_item">'
                .drupal_render($form['message'])
              .'</div>';
    $output .=   '<div class="user_verification_item">'
                .drupal_render($form['help'])
              .'</div>';
    $output .= $submit_button;
    $output .= '</div>';

    echo $output;
?>