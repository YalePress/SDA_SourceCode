$(function() {
    var contry_combo = $('#edit-profile-country');
    var state_combo = $('#edit-profile-state');

    var state_init_val = state_combo.val();

    contry_combo.change(function() {
        if (contry_combo.val() == 'USA') {
            state_combo.val(state_init_val);
//            state_combo.removeClass('hidden');
        } else {
            state_combo.val('0'); // not set, '--'
//            state_combo.addClass('hidden');
        }
    });

//    contry_combo.change(); // trigger showing state
});

function submit_profile_form(obj) {
    jQuery('#user-profile-form').submit();
}

function check_password_fields() {
    var p1 = $.trim($('#edit-pass-pass1').val());
    var p2 = $.trim($('#edit-pass-pass2').val());

    if (p1 == '' && p2 == '') {
        alert('If you want to change the password please fill "Password" and "Confirm password" fields!');
        return false;
    }

    return true;
}

function show_select_research_interests(obj) {
    jQuery('#view_options').toggleClass('hidden');
    return false;
}

function submit_profile_form(){
	$('form#user-profile-form').submit();
}

function reset_profile_form(){
	$('#profile_form_reset').click();
	//$('form#user-profile-form').reset();

    // Reset CKEditor field (About me) value.
    CKEDITOR = window.CKEDITOR || null;
    var editor = CKEDITOR.instances['edit-profile-about-me'];
    var data = $('textarea#edit-profile-about-me').html();
    data = data.replace(/(^\s+)|(\s+$)/g, "");
    if (data.substr(0, 9) == '&lt;p&gt;') data = data.substr(9);
    if (data.substr(data.length - 10) == '&lt;/p&gt;') data = data.substr(0, data.length - 10);
    editor.setData(data);
    //editor.setData();
}

function submit_reg_form(){
	$('form#user-register').submit();
}