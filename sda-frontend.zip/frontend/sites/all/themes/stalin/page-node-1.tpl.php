<?php
// $Id: page.tpl.php,v 1.28.2.1 2009/04/30 00:13:31 goba Exp $
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="<?php print $language->language ?>" xml:lang="<?php print $language->language ?>" dir="<?php print $language->dir ?>">
<head>
<title>Stalin Digital Archive</title>
      <?php print $head; ?>
      <?php print $styles ?>
      <?php print js_fix_jquery_version($scripts); ?>
</head>
<body>
<?
  global $base_url;
  $node = node_load(array('nid'=>'1'));
  echo stalin_page_header($secondary_links,$primary_links, $node); 
?>
    <!-- <div class="page_scroller"> -->
    <div class="main">
        <div class="block_inner">
            <table cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td class="left_main front">
                        <div class="frontend_items">
                           <?=most_pick();?>
                        </div>
                       
                        <div class="left_inner_wrap">
                         <div class="frontent_block_title">
                            <div class="sub_title most_viewed">most viewed documents</div>
                            <div class="see_more"><a href="<?=$base_url?>/node/3#most_viewed">See More Most Viewed</a></div>
                            <div class="clear"></div>
                        </div>
                            <?echo most_viewes();?>  
                            <div class="clear"></div>
                        </div>
                        
                            
                               <!-- <table class="sub_bloc_table"> <tr> 
                                <td class="sub_block front">
                                    <div class="frontent_block_title">
                                        <div class="sub_title ">BROWSE GEOGRAPHICALLY</div>                                        
                                    </div>
                                    <div class="map">
                                        <img src="<?//=base_path() . path_to_theme()?>/images/garbage/2.jpg" alt="" />
                                    </div>
                                </td>
                                <td class="sub_block front">
                                    <div class="frontent_block_title">
                                        <div class="sub_title">BROWSE TAGS</div>
                                    </div>
                                    <?//=popular_tags()?>
                                </div>                                
                            </td>
                            </tr>
                        </table>  -->
                        
                        <div class="left_inner_wrap"> 
                            <div class="frontent_block_title">
                                    <div class="sub_title">BROWSE CHRONOLOGICALLY</div>                                        
                            </div>
                            <div class="chronologically_browse_wrap">
                                <div id="chronologically_browse_prev" class="disabled"></div>
                                    <div id="chronologically_browse">
                                        <ul> 
                                        <?$chrons=get_chronological_list();?> 
                                        <?foreach ($chrons as $chron):?>
                                            <?if ($chron['year_last']==0) $chron['year_last']='   ... ' ;?>
                                            <li>
                                                <div class="chronologically_prev">
                                                    <a href="<?=$base_url?>/node/3#timeline#<?=$chron['id']?>">
                                                        <img src="<?=base_path() . path_to_theme()?>/images/chrono/chrono_browse_<?=$chron['id']?>.jpg" alt="Add image" />
                                                    </a>
                                                </div>
                                                <?//if (strlen($chron['name'])>23) $chron['name']=substr($chron['name'],0,20).' ...';?>
                                                <div class="chronologically_period_title"><a href="<?=$base_url?>/node/3#timeline#<?=$chron['id']?>"><?=$chron['name']?></a></div>
                                            </li>
                                            <?endforeach;?>
                                        </ul>
                                    </div>
                                    <div id="chronologically_browse_next"></div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </div>                        
                            
                    </td>
                   <?=right_column();?>
                </tr>
            </table>
            <div class="clear"></div>
             
        </div>        
    </div>

<?php echo html_for_popup(
    'login_info',
    t('Welcome to the SDA'),
    null,
    'Welcome to the Stalin Digital Archive. To register for access, please go to <br><a href="http://yalepress.yale.edu/yupbooks/sda/">http://yalepress.yale.edu/yupbooks/sda/</a>. If you already have credentials, <br>close this window and log into the site.',
    null, null,
    null
) ?>

<div id="footer">
    <? require "GA.php" ?>
  <?php print $footer_message ?>
  <?php print $footer ?>
</div>
<!--</div>-->
</body>
</html>
