    jQuery(document).ready(function()
    {   
        var url=jQuery(location).attr('href');
        jQuery('#edit-field-collection-value').change( function(){
        var collection_name=this.value;
        jQuery.post(url,{collection_name:collection_name},function(data)
            {
            jQuery('#edit-field-volume-value').html(data);
            jQuery('#edit-field-volume-value-wrapper').show();
            });
        });
        jQuery('#edit-field-collection-value').eq(2).attr('selected','selected');
        
    });