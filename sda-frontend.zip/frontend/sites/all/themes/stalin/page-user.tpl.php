<?php
// $Id: page.tpl.php,v 1.28.2.1 2009/04/30 00:13:31 goba Exp $
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="<?php print $language->language ?>" xml:lang="<?php print $language->language ?>" dir="<?php print $language->dir ?>">
<head>
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Cache-Control" content="no-cache" />

<!--        <script type="text/javascript" src="--><?//=base_path() . path_to_theme() . '/scripts/jquery-1.6.2.min.js'; ?><!--"></script>   -->
<title>User Profile</title>
     <?php print $head; ?>
      <?php print $styles ?>
     <?php print js_fix_jquery_version($scripts); ?>
    <link rel="stylesheet" type="text/css" href="<?=base_path() . path_to_theme() . '/style/popup.css'; ?>" />
    <link rel="stylesheet" type="text/css" href="<?=base_path() . path_to_theme() . '/profile_form.css'; ?>" />
     <link rel="stylesheet" type="text/css" href="<?=base_path() . path_to_theme() . '/style/main.css'; ?>" />

     <link rel="stylesheet" type="text/css" href="<?=base_path() . '/sites/all/modules/my_sda/my_sda.css'; ?>" />

    <!--<script type="text/javascript" src="<?=base_path() . path_to_theme() . '/scripts/main.js'; ?>"></script>-->
</head>
<body>
<? echo stalin_page_header($secondary_links,$primary_links); ?>
   <!-- <div class="page_scroller"> -->
<?php echo $messages; ?><!--errors list-->
    <table cellpadding="0" cellspacing="0" border="0" width="100%" class="content_table">
        <tr>
            <td valign="top" class="left_column_td">
                <div class="left_column">
                  <?php print $left ?>
                </div>
            </td>
            <td valign="top" width="100%" class="center">

            </div>
            <?if($node->type!='archive' AND $title!='User account'){?>
            <? if ($user->uid!='0')
            {
            	?>
            	<? if($user->uid == arg(1)) echo
                '<div class="user_manage_title">
            		Manage Account
            	</div>'; ?>
            	<?
            }
            ?>
            <? $tabs = str_replace(">View</a>", ">View Profile</a>", $tabs); // Hack. ?>
            <div class="tabs"><?php print $tabs ?></div><?}?>
                <div class="center_column">

                    <?php //var_dump(arg(1));
                    if(!arg(2)&&is_numeric(arg(1))){
                    	  echo render_profile_page(arg(1));
                        //echo view_profile_page();
                    /*
                        //var_dump(arg(1));
                        global $base_url;
                        $profile=user_load($user->uid);
                        ?>
                        <div class="profile_header">
                        <?=$profile->profile_first_name.' '.$profile->profile_last_name;
                        if (!empty($profile->picture))
                            echo '<img class="user_picture" alt="User image" src="'.$base_url.'/'.$profile->picture.'">';
                        else
                            echo'<img class="user_picture"  alt="User image" src="'.$base_url.'/sites/default/files/pictures/no_avatar.png'.'">';
                        ?>
                        </div>
                        <div class="profile_category_section">
                            <?=create_profile_category_header('My Profile',false)?>
                            <?if($profile->profile_first_name){?>
                            <div class="profile_item_wrapper">
                                <div class="profile_item_title">
                                    First name:
                                </div>
                                <div class="profile_item_value">
                                    <?=$profile->profile_first_name?>
                                </div>
                            </div><?}?>
                            <?if($profile->profile_last_name){?>
                            <div class="profile_item_wrapper">
                                <div class="profile_item_title">
                                    Last name:
                                </div>
                                <div class="profile_item_value">
                                    <?=$profile->profile_last_name?>
                                </div>
                            </div><?}?>
                            <?if($profile->profile_my_bio){?>
                            <div class="profile_item_wrapper">
                                <div class="profile_item_title">
                                    My Bio:
                                </div>
                                <div class="profile_item_value">
                                    <?=$profile->profile_my_bio?>
                                </div>
                            </div><?}?>
                            <?if($profile->mail){?>
                            <div class="profile_item_wrapper">
                                <div class="profile_item_title">
                                    E-Mail address:
                                </div>
                                <div class="profile_item_value">
                                    <?=$profile->mail?>
                                </div>
                            </div><?}?>
                            <?if($profile->profile_adress_1){?>
                            <div class="profile_item_wrapper">
                                <div class="profile_item_title">
                                    Adress Line 1:
                                </div>
                                <div class="profile_item_value">
                                    <?=$profile->profile_adress_1?>
                                </div>
                            </div><?}?>
                            <?if($profile->profile_adress_2){?>
                            <div class="profile_item_wrapper">
                                <div class="profile_item_title">
                                    Adress Line 2:
                                </div>
                                <div class="profile_item_value">
                                    <?=$profile->profile_adress_2?>
                                </div>
                            </div><?}?>
                            <?if($profile->profile_country){?>
                            <div class="profile_item_wrapper">
                                <div class="profile_item_title">
                                    Country:
                                </div>
                                <div class="profile_item_value">
                                    <?=$profile->profile_country?>
                                </div>
                            </div><?}?>
                            <?if($profile->profile_state&&$profile->profile_country=="USA"){?>
                            <div class="profile_item_wrapper">
                                <div class="profile_item_title">
                                    State:
                                </div>
                                <div class="profile_item_value">
                                    <?=$profile->profile_state?>
                                </div>
                            </div><?}?>
                            <?if($profile->profile_city){?>
                            <div class="profile_item_wrapper">
                                <div class="profile_item_title">
                                    City:
                                </div>
                                <div class="profile_item_value">
                                    <?=$profile->profile_city?>
                                </div>
                            </div><?}?>
                            <?if($profile->profile_institution){?>
                            <div class="profile_item_wrapper">
                                <div class="profile_item_title">
                                    institution:
                                </div>
                                <div class="profile_item_value">
                                    <?=$profile->profile_institution?>
                                </div>
                            </div><?}?>
                        </div>
                        <div class="profile_category_section">
                            <?=create_profile_category_header('My Account',false)?>
                            <?if($profile->profile_account_type){?>
                            <div class="profile_item_wrapper">
                                <div class="profile_item_title">
                                    Account type:
                                </div>
                                <div class="profile_item_value">
                                    <?=$profile->profile_account_type?>
                                </div>
                            </div><?}?>
                        </div>
                    <?*/}
                    else{
                        print $content;
                    }?>
                </div>
            </td>
            <td id="sidebar-right" valign="top">
                <div class="right_column">
                    <?php print $right ?>
                </div>
            </td>
        </tr>
    </table>
  <!--  </div>-->
<div id="footer">  <?php print $footer ?></div>
<?php print $closure ?>
</body>
<? require "GA.php" ?>
</html>
