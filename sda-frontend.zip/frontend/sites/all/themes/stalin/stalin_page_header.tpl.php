<?
global $base_url;
global $user;
?>

<script type="text/javascript">
    var is_login_user = <?= is_login() ? 'true' : 'false' ?>;
    var current_user_id = <?= $user->uid ?>;
    var this_base_url = '<?= $base_url ?>';
    jQuery(document).ready(function() {
      if ($('div.main_menu ul.menu li.active-trail a').length!=0) {
          $('.active-trail a').first().after('<div class="selected_menu_arrow"></div>');
      }
      //$('div.main_menu > ul.menu li ul').css('top',jQuery(".main_menu").position().top+29+'px');
      $('div.main_menu > ul.menu li.expanded a.inactive').parent().css('background','none');
      if ($('div.main_menu > ul.menu li.active-trail').prev().find('a').length) {
        $('div.main_menu > ul.menu li.active-trail').prev().find('a').first().css('border','none');
      }

      $('li.expanded a').each(function() {
        if ($(this).parent().hasClass("expanded") && !$(this).hasClass("inactive")) {
          $(this).append('<img src="'+this_base_url+'/sites/all/themes/stalin/images/header/white_arrow_down.png" alt="" />');
        }
      });
    });
</script>
<link rel="stylesheet" type="text/css" href="<?=base_path() . path_to_theme() . '/font/stylesheet.css'; ?>" />
<div class="hidden" id="dark_background"></div>
<div class="hidden" id="popup"></div>
<div class="hidden" style="z-index:24; width:100%; opacity:1; position:absolute" id="background_for_pulldowns"></div>
<div id="header">
        <?
          if ($node->nid=='1') {
            $page_title_suffix = '';
            $reduced = '';
          } else {
            $page_title_suffix = '_reduced';
            $reduced = ' reduced';
          }
        ?>
    <div class="header_inner<?= $page_title_suffix ?>">
        <div class="page_title<?= $page_title_suffix ?>">
            <a class="front_page_link" href="<?= $base_url ?>/node/1">
                <img alt="Stalin Digital Archive"
                     src="<?= $base_url ?>/sites/all/themes/stalin/images/header/sda_logo<?= $page_title_suffix ?>.png"></a>
        </div>
        <?
        $site_auth_id = getSiteAuthId();
        if ($site_auth_id!='0' /*&& $node->nid=='53'*/) {
          $site_auth_name_result = db_fetch_array(db_query("SELECT account_name FROM site_auth WHERE id = %d", $site_auth_id));
          $site_auth_name = $site_auth_name_result['account_name'];
          ?>
          <div class="access_provider">Access provided by <b><? print_r($site_auth_name);?></b></div>
          <?
        } else if ($site_auth_id=='0') {
          //unset($secondary_links['menu-4932']);
        }
        unset($secondary_links['menu-269']);
        if ($user->uid != '0') {
          unset($secondary_links['menu-1849']);
          unset($secondary_links['menu-1849 active-trail']);
        }
        ?>
        <div class="rgaspi_block">
          <a href="http://www.rusarchives.ru/federal/rgaspi/" target="_blank">
            <img alt="Yale University Press" src="<?= $base_url ?>/sites/all/themes/stalin/images/header/rgaspi_logo<?= $page_title_suffix ?>.png">
          </a>
        </div>
        <div class="yale_press">
          <a href="http://www.yale.edu/yup" target="_blank">
            <img alt="Yale University Press" src="<?= $base_url ?>/sites/all/themes/stalin/images/header/yale_press_logo<?= $page_title_suffix ?>.png">
          </a>
        </div>
        <div class="clear"></div>

        <?
/*        foreach ($user->roles as $role){
            if (($user->uid==1)or($role=='DPE (Digital Prod. Editor)')){
            //$out.='<div class="href_frontend"> <a href="'.$site_url.'/backend">Go to Production Module</a></div>';
            break;
            }
        }*/
        ?>

        <div class="clear"></div>
            <?           /* .'<li class="search_site">

                    <div class="search_site_left">
                        <div class="search_site_right">
                            <div class="search_site_center">
                                <input type="text" name="search" id="search" />
                            </div>
                        </div>
                    </div>
                    <input type="button" name="submit" onclick="global_search();return false;" value="Search" class="search_site_submit" />
            </li>'*/ ?>

        <?
// see http://drupal.org/node/68578
        $menu_name = variable_get('menu_primary_links_source', 'primary-links');
        $menu_tree = menu_tree($menu_name);
        ?>
    </div>
        <div class="main_menu<?= $reduced ?>"><?= $menu_tree ?><?= top_menu($secondary_links) ?></div>
        <div class="clear"></div>
<? // Disable my sda and document viewer menu items for anonymous users. ?>
<script type="text/javascript">
    if (!is_login_user) {
        $('.main_menu a[href$="node/13"], .main_menu a[href$="sda_viewer"]')// my sda & sda_viewer
                .removeAttr('href')
                .addClass('inactive')
                .parent().find('ul').hide();
    }
</script>
<? if ($user->uid == 0) { ?>
</div>
<div class="hidden" id="back_gray" onclick="javascript:back_gray_click()">
</div>
<? if ($node->nid!='53') { ?>
<div id="login_popup" class="hidden">
  <div class="alert_icon"></div>
  <div class="alert_message">
    <h1>Login Required</h1>
    <p>A personal account is required to view archive documents and access all of the features of My SDA.</p>
    <?
    $login_form = drupal_get_form('user_login_block');
    $content.=$login_form;
    if ($node->nid !=53)
      $content.='<script type="text/javascript">
          jQuery(document).ready(function(){
              $("div#name_item_header").addClass("popup");
              jQuery("form#user-login-form").find("div#name_item_header").html("Username:");
              $("div#pass_item_header").addClass("popup");
              jQuery("form#user-login-form").find("div#pass_item_header").html("Password:");
              jQuery("form#user-login-form").find("input#edit-name").css({width:"100%",border: "1px solid gray",height:"2em"});
              jQuery("form#user-login-form").find("input#edit-pass").css({width:"100%",border: "1px solid gray",height:"2em"});
              $("div#login_button").addClass("hidden");
              $("div#block_login_links").addClass("hidden");
              $("div#block_question_links").addClass("hidden");
          });
      </script>';
    print($content);
    ?>
    <div class="login_item">
      <div class="login_item_header" id="block_question_links_header">
        Not registered?
      </div>
      <div class="login_item_link_question" id="block_question_links_text">
      	<? print('<a href="' . $base_url . '/user/register">Register for your MySDA account</a>'); ?>
      </div>
    </div>
  </div>
  <div class="gray_button" id="submit_login_popup">
    <a href="javascript:submit_login_form()">
      <div class="gray_button_left">
        <div class="gray_button_middle">
          <b>Login</b>
        </div>
        <div class="gray_button_right">
        </div>
      </div>
    </a>
  </div>
  <div class="gray_button" id="close_login_popup">
    <a href="javascript:back_gray_click()">
      <div class="gray_button_left">
        <div class="gray_button_middle">
          <b>Cancel</b>
        </div>
        <div class="gray_button_right">
        </div>
      </div>
    </a>
  </div>
</div>
<? } ?>
<div id="subscription_renew_popup" class="hidden">
  <div class="alert_icon"></div>
  <div class="alert_message">
    <h1>Your subscription has expired.</h1>
    <p><a href="<?= getBlockContentByName('subscription_site_link') ?>">Click here to renew</a> your subscription</p>
    <p>Once your subscription is renewed, you will receive a new activation code that must be entered before you can log in again</p>
  </div>
  <div class="gray_button" id="close_subscription_renew">
    <a href="javascript:back_gray_click()">
      <div class="gray_button_left">
        <div class="gray_button_middle">
          Close
        </div>
        <div class="gray_button_right">
        </div>
      </div>
    </a>
  </div>
</div>
<? } ?>