<?php
    global $user;
    $errors = form_get_errors();
    $errors_html = '';
    //global $messages;

    foreach (drupal_get_messages() as $type => $messages) {
        $errors_html .= "<div class=\"profile_messages_$type\">\n";
        if (count($messages) > 1) {
          $errors_html .= " <ul>\n";
          foreach ($messages as $message) {
          	if ($message[0] == "Institution is required") $message[0] = 'You must complete the appropriate text field when choosing "Other" from the drop-down list of institutions.'; //Hack
            $errors_html .= '  <li>'. $message ."</li>\n";
          }
          $errors_html .= " </ul>\n";
        }
        else {
        	if ($messages[0] == "Institution is required") $messages[0] = 'You must complete the appropriate text field when choosing "Other" from the drop-down list of institutions.'; //Hack
          $errors_html .= $messages[0];
        }
        $errors_html .= "</div>\n";
    }

    drupal_add_js('sites/all/themes/stalin/profile_form.js');
    drupal_add_css('sites/all/themes/stalin/profile_form.css');

    $about_category = 'Account';

    $output='';
    // Don't show username field, but submit it, as otherwise we'll get error
    $form['account']['name']['#type'] = 'hidden';
    $form['Account']['profile_first_name']['#type'] = 'hidden';
    $form['Account']['profile_last_name']['#type'] = 'hidden';
    $output .= drupal_render($form['account']['name'])
               .drupal_render($form['Account']['profile_first_name'])
               .drupal_render($form['Account']['profile_last_name']);

    $output .= '
      <div class="user_register_required">
        <span class="form-required" title="This field is required.">*</span> Required field
      </div>';
      if ($errors != null) $output .=$errors_html;

		$form['account']['pass']['pass1']['#title'] = 'New password';
		$form['account']['pass']['pass1']['#attributes'] = array('autocomplete' =>'off');
		$form['account']['pass']['pass2']['#attributes'] = array('autocomplete' =>'off');

    $pass_access = $form['account']['pass']['#access'];
    $pass_change_enabled = !isset($pass_access) || $pass_access == true;

    $output.='<div class="profile_category_section">'
              .create_profile_category_header('Password', false, 'return check_password_fields();');

    if ($pass_change_enabled) {
        $output .=
              '<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['account']['pass']['pass1'])
                .'</div>'
              .'</div>'
              .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['account']['pass']['pass2'])
                .'</div>'
              .'</div>';
    } else {
        $output .= "<div style='font-weight: bold; text-align: center'>You don't have permission to change password.</div>";
    }

    $output .= '</div>';

    $output.='<div class="profile_category_section">'
        .create_profile_category_header('My Information', false)
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                      .stalin_form_render_disabled($form['Account']['profile_first_name']['#title'],
                                                   $form['Account']['profile_first_name']['#value'],
                                                   $form['Account']['profile_first_name']['#description'])
                    //.stalin_form_render_disabled($form['Account']['profile_first_name'])
                .'</div>'
            .'</div>'
            .'<input type=hidden name="edit_form_picker" value="1">'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                      .stalin_form_render_disabled($form['Account']['profile_last_name']['#title'],
                                                   $form['Account']['profile_last_name']['#value'],
                                                   $form['Account']['profile_last_name']['#description'])
                      //.stalin_form_render_disabled($form['Account']['profile_last_name'])
                    //.drupal_render($form['Account']['profile_last_name'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">';
                unset($form['account']['mail']['#description']);
                $output.=
                    drupal_render($form['account']['mail'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_institution'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_adress_1'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_adress_2'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_city'])
                .'</div>'
            .'</div>'
            .'<div id="state_wrapper" class="profile_item_wrapper">'
                .'<div class="profile_item select_item">'
                    .drupal_render($form['Account']['profile_state'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_zip'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item select_item">'
                    .drupal_render($form['Account']['profile_country'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_position'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_department'])
                .'</div>'
            .'</div>'
            .'<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_about_me'])
                .'</div>'
            .'</div>';
        $form[$about_category]['profile_www']['#help_description'] =  'Use commas to separate multiple entries.';
        $form[$about_category]['profile_www']['#help_example'] =  'Entries stating with "http" or "www" will be recognized as URLs.';
        $output.='<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_www'])
                .'</div>'
            .'</div>';
        $form[$about_category]['profile_affiliations']['#help_description'] =  'Use commas to separate multiple entries.';
        $output.='<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_affiliations'])
                .'</div>'
            .'</div>';
        $form[$about_category]['profile_facebook']['#help_example'] =  'Example: http://www.facebook.com/yalepress';
        $output.='<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_facebook'])
                .'</div>'
            .'</div>';
        $form[$about_category]['profile_twitter']['#help_example'] =  'Example: http://www.twitter.com/@twittername';
        $output.='<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_twitter'])
                .'</div>'
            .'</div>';
        $form[$about_category]['profile_otherprofiles']['#help_description'] = 'Use commas to separate entries.';
        $form[$about_category]['profile_otherprofiles']['#help_example'] =  'Example: Linkedln, Academia.edu, etc.';
        $output.='<div class="profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form[$about_category]['profile_otherprofiles'])
                .'</div>'
            .'</div>'
          .'</div>';

        //$form['picture']['picture_upload']['#attributes'] = array('onchange'=>'javascript:show_remove_button()');
        $form['picture']['picture_upload']['#title'] = 'Upload Your Picture';
        $form['picture']['picture_upload']['#description'] = t('Your virtual face or picture. Maximum dimensions are %dimensions and the maximum size is %size MB.',
                                                               array('%dimensions' => variable_get('user_picture_dimensions', '85x85'),
                                                                     '%size' => variable_get('user_picture_file_size', '30')/1024));
        $remove_button = '';
        $remove_button.= '<div class="gray_button hidden" id="remove_button">
                              <a href="#">
                              <div class="gray_button_left">
                                <div class="gray_button_middle">
                                  Remove
                                </div>
                                <div class="gray_button_right">
                                </div>
                              </div>
                              </a>
                              <input id="picture_reset" type="reset" value="Reset" style="display:none">
                            </div>';
        $output.='<div class="profile_category_section">'
                    .create_profile_category_header('Profile Picture', false)
                  .'<div class="profile_item_wrapper picture">'
                      .'<div class="profile_item">'
                          .drupal_render($form['picture']['picture_upload'])
                          //.$remove_button
                      .'</div>'
                      .'<div class="profile_item">'
                          .drupal_render($form['picture']['picture_delete'])
                      .'</div>'
                 .'</div>'
                 .'</div>';

        unset($form['timezone']['timezone_name']['#description']);
        $form['timezone']['timezone_name']['#title'] = 'Time Zone';
        $form['timezone']['timezone_name']['#prefix'] = '<div class="prefix_description">Select your current local time. Dates and times throughout this site will be displayed using this time zone.</div>'
                      .'<div class="prefix_hint">If in doubt, choose the timezone that is closest to your location which has the same rules for daylight saving time. Dates and times throughout this site will be displayed using this time zone.</div>';
        $output.='<div class="profile_category_section">'
                    .create_profile_category_header('Time Zone', false)
                  .'<div class="profile_item_wrapper">'
                      .'<div class="profile_item">'
                          .drupal_render($form['timezone']['timezone_name'])
                      .'</div>'
                  .'</div>'
                 .'</div>';

        unset($form['Account']['profile_email_permission']['#description']);
        $form['Account']['profile_email_permission']['#title'] = 'My Email';
        $form['Account']['profile_email_permission']['#prefix'] = '<div class="prefix_description">Please select the visibility settings for your SDA Community profile below.</div>'
                      .'<div class="prefix_hint">Your profile information is not visible to public visitors of the site. Only users with registered SDA accounts can view your profile.</div>';
        $output.='<div class="profile_category_section">'
                    .create_profile_category_header('Community Profile Settings', false)
                    .'<div class="profile_item_wrapper">'
                        .'<div class="profile_item">'
                            .drupal_render($form['Account']['profile_email_permission'])
                        .'</div>'
                    .'</div>'
                 .'</div>';
        $form['Account']['profile_email_preferences']['#prefix'] = '<div class="prefix_description">Receive SDA and Yale University Press promotions at my account email address.</div>';
        unset($form['Account']['profile_email_preferences']['#title']);// = 'My Email';
        $output.='<div class="profile_category_section">'
                    .create_profile_category_header('Email Preference', false)
                    .'<div class="profile_item_wrapper">'
                        .'<div class="email_preferences profile_item" id="email_preferences_items">'
                            .drupal_render($form['Account']['profile_email_preferences'])
                        .'</div>'
                    .'</div>'
                 .'</div>';
        $site_auth_id = getSiteAuthId();
        if ($site_auth_id!='0') {//AND $site_auth_id!='1'){
        $site_auth_name_result = db_fetch_array(db_query("SELECT account_name FROM site_auth WHERE id = %d", $site_auth_id));
        $site_auth_name = $site_auth_name_result['account_name'];
        $output.='<div class="profile_category_section">'
                    .create_profile_category_header('Subscription', false)
                    .'<div class="profile_item_wrapper">'
                        .'<div class="profile_item">'
                            .'<div class="prefix_hint">Your access to the SDA is provided by '.$site_auth_name.'</div>'
                        .'</div>'
                    .'</div>'
                 .'</div>';
        } else {
        $output.='<div class="profile_category_section">'
                    .create_profile_category_header('Subscription', false)
                    .'<div class="profile_item_wrapper">'
                        .'<div class="subscrtiption_item email_preferences profile_item">'
                            .stalin_form_render_profile_auth_codes($form['Account']['profile_individual_codes']['#value'])
                        .'</div>'
                    .'</div>'
                 .'</div>';
        }

        /*if (is_admin()){
        $output.='<div class="profile_category_section">'
                    .create_profile_category_header('My Account', false)
                    .'<div class="profile_item_wrapper">'
                        .'<div class="email_preferences profile_item">'
                            .drupal_render($form['Account']['profile_account_type'])
                        .'</div>'
                    .'</div>'
                 .'</div>';
        }*/

        /*$output.'<div class="hidden profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_name_permission'])
                .'</div>'
            .'</div>'
            .'<div class="hidden profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_ardess_permission'])
                .'</div>'
            .'</div>'
            .'<div class="hidden profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_institution_permission'])
                .'</div>'
            .'</div>'
            .'<div class="hidden profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_picture_permission'])
                .'</div>'
            .'</div>'
            .'<div class="hidden profile_item_wrapper">'
                .'<div class="profile_item">'
                    .drupal_render($form['Account']['profile_my_bio_permission'])
                .'</div>'
            .'</div>';*/

          $output.=drupal_render($form['form_build_id']);
          $output.=drupal_render($form['form_token']);
          $output.=drupal_render($form['form_id']);

          $submit_button = '';
          $submit_button .= '<div class="black_button">
                                <a href="javascript:submit_profile_form();">
                                <div class="black_button_left">
                                    <div class="black_button_middle">
                                    Save and View Profile
                                    </div>
                                  <div class="black_button_right">
                                  </div>
                                </div>
                                </a>
                              </div>';
          $reset_button = '';
          $reset_button.= '<div class="gray_button" id="reset_button">
                                <a href="javascript:reset_profile_form()">
                                <div class="gray_button_left">
                                    <div class="gray_button_middle">
                                    Reset
                                    </div>
                                  <div class="gray_button_right">
                                  </div>
                                </div>
                                </a>
                                <input id="profile_form_reset" type="reset" value="Reset" style="display:none">
                              </div>';
          $output.= '<div class="profile_category_header">'
                      .$submit_button
                      .$reset_button
                    .'</div>';
echo $output;
//print_r($form);
?>