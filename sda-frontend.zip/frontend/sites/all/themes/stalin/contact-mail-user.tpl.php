<?
  global $user;
  $errors = form_get_errors();
  $errors_html = '';

  foreach (drupal_get_messages() as $type => $messages) {
      $errors_html .= "<div class=\"profile_messages_$type\">\n";
      if (count($messages) > 1) {
        $errors_html .= " <ul>\n";
        foreach ($messages as $message) {
          $errors_html .= '  <li>'. $message ."</li>\n";
        }
        $errors_html .= " </ul>\n";
      }
      else {
        $errors_html .= $messages[0];
      }
      $errors_html .= "</div>\n";
  }

  $output = '';
  $output.='<div class="profile_item_wrapper">'
              .'<div class="profile_item">'
                  .drupal_render($form['from'])
              .'</div>'
          .'</div>';

  $output.='<div class="profile_item_wrapper">'
              .'<div class="profile_item">'
                  .drupal_render($form['to'])
              .'</div>'
          .'</div>';

  $output.='<div class="profile_item_wrapper">'
              .'<div class="profile_item">'
                  .drupal_render($form['subject'])
              .'</div>'
          .'</div>';

  $output.='<div class="profile_item_wrapper">'
              .'<div class="profile_item">'
                  .drupal_render($form['message'])
              .'</div>'
          .'</div>';

  $output.='<div class="profile_item_wrapper">'
              .'<div class="profile_item">'
                  .drupal_render($form['message'])
              .'</div>'
          .'</div>';

  $output.='<div class="profile_item_wrapper">'
              .'<div class="profile_item">'
                  .drupal_render($form['copy'])
              .'</div>'
          .'</div>';

  $output.='<div class="profile_item_wrapper">'
              .'<div class="profile_item">'
                  .drupal_render($form['submit'])
              .'</div>'
          .'</div>';

  echo $output;
?>