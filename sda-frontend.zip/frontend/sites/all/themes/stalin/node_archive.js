jQuery(window).load(function() {
jQuery('.breadcrumb a').attr('href',document.referrer)
calculate_iframes_position()
});

jQuery(document).ready(function() {
    
    jQuery('td.left_column_td').hide();
    jQuery('td#sidebar-right').hide();
    
    //jQuery('.add_document').click(function(){
      //  show_popup('open_new_document')
    //});
});

function close_doc(node_id){
var url=this_base_url+'/remove_doc_from_viewed';
jQuery.post(url,{node_id:node_id});
var last_parent=jQuery('iframe#node_wrapper_'+node_id).parent()
frames[jQuery('iframe#node_wrapper_'+node_id).attr('name')] = null;
jQuery('iframe#node_wrapper_'+node_id).remove()
jQuery('.pictogram.close_doc[name='+node_id+']').parent().remove() 
if(!last_parent.hasClass('minimized_iframes')){
    if(last_parent.hasClass('left_viewer_column')){
        if(jQuery('.right_viewer_column iframe').length){
            jQuery('.right_viewer_column iframe:first').appendTo(jQuery('.left_viewer_column'))
                .load(function(){
                calculate_iframes_position();
                })
        }else{
            calculate_iframes_position();
        }
    }else{
        calculate_iframes_position();
    }
}
return false;
}

function set_iframes_position(){
    /*jQuery('.left_viewer_column iframe,.right_viewer_column iframe').each(function(index,element){
        if(index<2){
            jQuery(element).appendTo('.left_viewer_column')
        }else{
            jQuery(element).appendTo('.right_viewer_column')
        }
    })*/
}

function calculate_iframes_position(){
  // console.info('calculating')
    if(jQuery('iframe').length>3){
        jQuery('.add_document').hide()
    }else{
        jQuery('.add_document').show()
    }
    if(!jQuery('.right_viewer_column iframe').length) {
        var one_column=true;
        jQuery('.left_viewer_column').css('width','100%')
        if(jQuery('.left_viewer_column iframe').length==2){
            jQuery('.left_viewer_column iframe').css('width','50%')
        }else{
            jQuery('.left_viewer_column iframe').css('width','100%')
        }
        jQuery('.right_viewer_column').css('height','0px')
    }else{
        var one_column=false;
        jQuery('.left_viewer_column,.right_viewer_column').css('width','50%').find('iframe').css('width','100%')
    }
    jQuery('iframe').each(function(index,element){
        jQuery(element).removeAttr('onload').unbind('load')
        if(jQuery(element).parent().hasClass('minimized_iframes')) return false;
        //console.log(window.frames[jQuery(element).attr('name')].this_node_id);
        //console.log(window.frames[jQuery(element).attr('name')])
        if (window.frames[jQuery(element).attr('name')].this_node_id){
        var frames_count=jQuery(element).parent().find('iframe').length
        switch(index){
            case 0:
                if(frames_count>1){
                    if(one_column){
                        window.frames[jQuery(element).attr('name')].set_splitted(window, true,false,one_column);
                    }
                    else{
                        window.frames[jQuery(element).attr('name')].set_splitted(window, false,true,one_column);
                    }
                }else{
                    window.frames[jQuery(element).attr('name')].set_splitted(window, false,false,one_column)
                } 
            break;
            case 1:
                if(one_column){
                   //console.log(jQuery(element))
                   //console.log(window.frames[jQuery(element).attr('name')])
                    window.frames[jQuery(element).attr('name')].set_splitted(window, true,false,one_column);
                }else{
                    window.frames[jQuery(element).attr('name')].set_splitted(window, false,true,one_column);
                }
            break;
            case 2:
                if(frames_count>1){
                    window.frames[jQuery(element).attr('name')].set_splitted(window, false,true,one_column);
                }else{
                    window.frames[jQuery(element).attr('name')].set_splitted(window, false,false,one_column);
                }
            break;
            case 3:
                window.frames[jQuery(element).attr('name')].set_splitted(window, false,true,one_column);
            break;
        }
        }
    });
}

function maximize(node_id){
    if(jQuery('#node_wrapper_'+node_id).parent().hasClass('minimized_iframes')){
        if(jQuery('.left_viewer_column iframe').length<2){
            jQuery('#node_wrapper_'+node_id).appendTo('.left_viewer_column').load(function(){
                jQuery('iframe').each(function(index,element){
                if(jQuery(element).attr('id')=='node_wrapper_'+node_id){
                    window.frames[jQuery(element).attr('name')].maximize_this();
                        }
                    });
                calculate_iframes_position();
                });
        }else{
            jQuery('#node_wrapper_'+node_id).appendTo('.right_viewer_column').load(function(){
            jQuery('iframe').each(function(index,element){
            if(jQuery(element).attr('id')=='node_wrapper_'+node_id){
                window.frames[jQuery(element).attr('name')].maximize_this();
                    }
            });
            calculate_iframes_position();
        })
        }
            
    }
}

function minimize(node_id){
    //console.log(node_id)
    var last_parent=jQuery('#node_wrapper_'+node_id).parent()
    if(!last_parent.hasClass('minimized_iframes')){
        jQuery('#node_wrapper_'+node_id).css('height','40px').css('width','100%').appendTo('.minimized_iframes').load(function(){
            jQuery('iframe').each(function(index,element){
                if(jQuery(element).attr('id')=='node_wrapper_'+node_id){
                    window.frames[jQuery(element).attr('name')].minimize_this();
                }
            });
                if(last_parent.hasClass('right_viewer_column')){
                    calculate_iframes_position();
                }
                else{
                       if(jQuery('.right_viewer_column iframe').length){
                           jQuery('.right_viewer_column iframe:first')
                                .appendTo(jQuery('.left_viewer_column'))
                                .load(function(){
                               calculate_iframes_position();
                               })
                       }else{
                           calculate_iframes_position();
                       }
                }
        })   
    }
}

function hide_control_panel(){
    jQuery('.documents_control_panel').hide()
    jQuery('iframe').each(function(index,element){
       // window.frames[jQuery(element).attr('name')].hide_control_panel()
    })
        jQuery('#show_control_panel').removeClass('hidden')
        jQuery('#hide_control_panel').addClass('hidden')
}

function show_control_panel(){
    jQuery('.documents_control_panel').show()
    jQuery('iframe').each(function(index,element){
       // window.frames[jQuery(element).attr('name')].show_control_panel()
    })
        jQuery('#show_control_panel').addClass('hidden')
        jQuery('#hide_control_panel').removeClass('hidden')
}
