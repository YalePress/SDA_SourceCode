function submit_reg_form(){
  $('form#user-register').submit();
}

function submit_user_pass_reset_form() {
  $('form#site-management-user-pass-reset').submit();
}