<?php

function get_send_bulk_notice_popup_html() {
    $out = '
    <div id="popup_send_bulk_notice" class="hidden">
        <div class="popup_header">Send Bulk Notice
            <img alt="Close" src="' . base_path() . 'sites/all/themes/stalin/images/cross_close.png">
        </div>
        <div class="popup_body">
            <div class="popup_body_title">To:<p/></div>
            <div id="bulk_notice_user_list"></div><p/>
            <div class="popup_body_title">Notification message templates:<p/></div>
            <select name="previous_messages" id="previous_messages" style="width:350px;" onchange="load_message(this.options[this.selectedIndex].value);">
                <option value="0">New message</option>';
                $query = "SELECT id, topic, text FROM bulk_notification_messages_saved ORDER BY topic ASC";
                $result = db_query($query);
                while ($message = db_fetch_array($result)) {
                    if (strlen($message['topic']) > 50) {
                        $message_topic = substr($message['topic'], 0, 47) . "...";
                    } else {
                        $message_topic = $message['topic'];
                    }
                    $out .= '<option value="' . $message['id'] . '">' . $message_topic . '</option>';
                }
                $out .= '
            </select>
            <div style="float: right">'
                . button_link(array('text' => 'Save', 'onclick' => "save_bulk_notice_template(); return false;")) . '
            </div><p/>
            <div class="popup_body_title">Notification message subject:<p/></div>
            <input type="text" id="notification_message_topic" style="width:350px;"/>
            <div style="float: right">'
                . button_link(array('text' => 'Delete', 'onclick' => "delete_bulk_notice_template();return false;")) . '
            </div><p/>
            <div class="popup_body_title">Notification message text:<p/></div>
            <textarea id="notification_message_text" cols="50" rows="6"></textarea><p/>
        </div>
        <div class="popup_footer">'
            . button_link(array('text' => 'Cancel', 'onclick' => "closePopup(); return false;"))
            . button_link(array('text' => 'Send', 'onclick' => "send_bulk_notice();")) . '
        </div>
    </div>';

    echo $out;
}

function send_bulk_notice() {
    global $user;
    $ids_string = $_POST['ids'];
    $user_ids = preg_split('/,/', $ids_string);
    $notification_message_topic = $_POST['notification_message_topic'];
    $notification_message_text = $_POST['notification_message_text'];

    // Insert notification message into the bulk_notification_messages table.
    $query = "INSERT INTO bulk_notification_messages (topic, text) VALUES ('%s', '%s')";
    db_query($query, $notification_message_topic, $notification_message_text);

    // Get an id of the inserted message.
    $query = "SELECT max(id) last_id from bulk_notification_messages";
    $result = db_fetch_array(db_query($query));
    $message_id = $result['last_id'];

    // Insert notifications and send e-mails.
    foreach ($user_ids as $user_id) {
        insert_notification(NOTIFICATION_BULK_MESSAGE, $user_id, $user->uid, $message_id);

        $account = user_load(array('uid' => $user_id));
        $language = user_preferred_language($account);
        $params = array();
        $params['subject'] = $notification_message_topic;
        $params['body'] = $notification_message_text;
        drupal_mail('user_management', 'action_send_email', $account->mail, $language, $params, null, true);
    }
}

function save_bulk_notice_template() {

    $notification_message_topic = $_POST['notification_message_topic'];
    $notification_message_text = $_POST['notification_message_text'];

    // Insert notification message into the bulk_notification_messages_saved table.
    $query = "INSERT INTO bulk_notification_messages_saved (topic, text) VALUES ('%s', '%s')";
    db_query($query, $notification_message_topic, $notification_message_text);

    // Get an id of the inserted message.
    $query = "SELECT max(id) last_id from bulk_notification_messages_saved";
    $result = db_fetch_array(db_query($query));
    echo $result['last_id'];
}

function delete_bulk_notice_template() {
    $id = $_POST['id'];

    db_query("DELETE FROM bulk_notification_messages_saved WHERE id = %d", $id);
}

function user_management_mail($key, &$message, $params) {
    $message['subject'] = $params['subject'];
    $message['body'][] = $params['body'];
}

function get_notification_message() {
    $id = $_GET['id'];
    $query = "SELECT topic, text FROM bulk_notification_messages_saved WHERE id = %d";
    $result = db_fetch_array(db_query($query, $id));
    echo json_encode(array("message_topic" => $result['topic'], "message_text" => $result['text']));
}