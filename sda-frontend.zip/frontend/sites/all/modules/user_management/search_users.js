var number_of_fields = 22;

jQuery(document).ready(function() {
    jQuery('.content_table').delegate('th:not(.checkbox_cell, .not_sortable)', 'click', function() {
        var order;

        var this_th = jQuery(this);

        if (!this_th.hasClass('sorted')) {
            order = 'asc'
        } else {
            if (this_th.hasClass('reversed')) {
                order = 'asc';
            } else {
                order = 'desc';
            }
        }

        var sort_by = this_th.find('a').attr('href') || get_from_class(this_th, 'sort_by');
        var type = this_th.find('a').attr('class') || get_from_class(this_th, 'type');

        sort_table_results(sort_by, order, type);
    });

    jQuery('.content_table').delegate('.check_all', 'change', function() {
        if (jQuery(this).is(':checked')) {
            jQuery('.check_one').attr('checked', 'checked');
        } else {
            jQuery('.check_one').removeAttr('checked');
        }
    });

    search_users();
});

function sort_table_results(sort_by, order, type) {
    if (type == 'users') {
        search_users(sort_by, order);
    }
}

function search_users(sort_by, order) {
    if (sort_by == undefined) {
        sort_by = 'mail';
    }
    if (order == undefined) {
        order = 'asc';
    }
    $.post(
            'search_users',
            {
                user_email: $('#user_email').val(),
                user_first_name: $('#user_first_name').val(),
                user_last_name: $('#user_last_name').val(),
                user_address_1: $('#user_address_1').val(),
                user_address_2: $('#user_address_2').val(),
                user_city: $('#user_city').val(),
                user_state: $('#user_state').val(),
                user_country: $('#user_country').val(),
                user_institution: $('#user_institution').val(),
                user_position: $('#user_position').val(),
                user_title: $('#user_title').val(),
                user_department: $('#user_department').val(),
                user_zip_code: $('#user_zip_code').val(),
                user_role: $('#user_role').val(),
                user_expiration_date: $('#user_expiration_date').val(),
                user_status: $('#user_status').val(),
                user_account_type: $('#user_account_type').val(),
                sort_by: sort_by,
                order: order
            },
            function(data) {
                $('#search_users_result').html(data);
                jQuery('#search_users_result th.' + sort_by).addClass('sorted');
                if (order == 'desc') jQuery('#search_users_result th.' + sort_by).addClass('reversed');
                make_resizable('#search_users_result div.resize');
                apply_view_options_users();
            }
    );
}

function show_select_view_options_users(obj) {
    jQuery('#view_options').toggleClass('hidden');
    jQuery('#sort_by').addClass('hidden');

    // Save checked view options.
    var checked_options = [];
    var container = jQuery('#search_users_result');
    container.find('#view_options').find('#select_fields_to_view input').each(function(index, element) {
        if (jQuery(element).is(':checked')) {
            checked_options.push(jQuery(element).attr('value'));
        }
    });

    jQuery('#background_for_pulldowns')
        .height($(document).height())
        .removeClass('hidden')
        .click(function() {
            close_pulldowns();
            // Restore checked view options.
            container.find('#view_options').find('#select_fields_to_view input').each(function(index, element) {
                if (jQuery.inArray(jQuery(element).attr('value'), checked_options) != -1) {
                    jQuery(element).attr('checked', true);
                } else {
                    jQuery(element).attr('checked', false);
                }
            });

        });

    return false;
}

function apply_view_options_users() {
    jQuery('#view_options').addClass('hidden');
    var container = jQuery('#search_users_result');

    var all_options = [];

    container.find('#view_options').addClass('hidden').find('#select_fields_to_view input').each(function(index, element) {
        var td_class = jQuery(element).attr('value');
        if (jQuery(element).is(':checked')) {
            container.find('td.' + td_class + ',th.' + td_class).removeClass('hidden');
            all_options.push(td_class);
        } else {
            container.find('td.' + td_class + ',th.' + td_class).addClass('hidden');
        }
    });

    jQuery.post('save_users_view_options', {options: all_options});

    if (!jQuery(".search_result").hasClass("hidden") &&
        !jQuery(".search_result th div.resize").hasClass("ui-resizable")) {
        return false;
    }
}

function show_select_sort_by_users(obj) {
    jQuery(obj).siblings('#sort_by').toggleClass('hidden');
    jQuery('#view_options').addClass('hidden');
    jQuery('#background_for_pulldowns')
        .height($(document).height())
        .removeClass('hidden')
        .click(function() {
            close_pulldowns()
        });
    return false;
}

function hide_select_sort_by_users() {
    jQuery('#sort_by').addClass('hidden');
    var sort_by = jQuery('#sort_by select').attr('value');
    search_users(sort_by, 'asc');
}

function close_pulldowns() {
    jQuery('#sort_by').addClass('hidden');
    jQuery('#view_options').addClass('hidden');
    jQuery('#select_check_all').addClass('hidden');
    jQuery('#background_for_pulldowns').addClass('hidden');
}

function value_list(selector) {
    var list = [];
    $(selector).each(function () {
        list.push($(this).val());
    });
    return list;
}

function show_action_users_popup(action) {
    var ids = value_list('.check_one:checked');
    if (ids.length) {
        show_popup('user_management_action_users');
        $('#popup #action_title').html(capitalize_first_letter(action));
        $('#popup #users_title').html(ids.length == 1 ? 'User' : 'Users');
        $('#popup #action').html(action);
        $('#popup #this_user').html(ids.length == 1 ? 'this user' : 'these users');
        $('#popup #action_button_title').html(capitalize_first_letter(action));

        var users = get_selected_users();

        $('#popup #action_user_list').html(users);
        $('#popup #action_btn').click(function () {
            $.post(action + '_users', {
                ids: ids.join(',')
            }, function() {
                closePopup();
                search_users($('#sort_by').html(), $('#order').html());
            });
            return false;
        });
    }
}

function show_select_check_all() {
    var div = jQuery('#select_check_all');
    div.toggleClass('hidden');

    div.find('div.select_item').click(function() {
        if (jQuery(this).is('.select_all')) {
            jQuery("table.search_result input[type='checkbox']").attr('checked', true);
            jQuery(".check_all").attr('checked', true)
        } else if (jQuery(this).is('.clear_all')) {
            jQuery("table.search_result input[type='checkbox']").attr('checked', false);
            jQuery(".check_all").attr('checked', false)
        }
        div.addClass('hidden');
    })
}

function show_add_remove_user_role_popup(type) {
    var ids = value_list('.check_one:checked');
    if (ids.length) {
        show_popup('add_remove_user_role');
        $('#popup #add_remove_header').html(type.charAt(0).toUpperCase() + type.slice(1));
        $('#popup #add_remove_question').html(type);
        $('#popup #add_remove_button #button_text').html(type.charAt(0).toUpperCase() + type.slice(1));
        $('#popup #add_remove_button').click(function () {
            $.post('add_remove_user_role', {
                ids: ids.join(','),
                role_id: $('#role_select').val(),
                operation: type
            }, function() {
                closePopup();
                search_users($('#sort_by').html(), $('#order').html());
            });
            return false;
        });
    }
}

jQuery.download = function(url, data, method) {
    // url and data options are required.
    if (url && data) {
        // Data can be string of parameters or array/object.
        data = typeof data == 'string' ? data : jQuery.param(data);
        // Split params into form inputs.
        var inputs = '';
        jQuery.each(data.split('&'), function() {
            var pair = this.split('=');
            inputs += '<input type="hidden" name="' + pair[0] + '" value="' + pair[1] + '" />';
        });
        // Send request.
        jQuery('<form action="' + url + '" method="' + (method || 'post') + '">' + inputs + '</form>')
                .appendTo('body').submit().remove();
    }
};

function export_search_results() {
    //var all_columns = ($('input[name=include_columns]:checked').val() == 'all');
    var all_columns = true;
    var all_rows = ($("input[name='include_rows']:checked").val() == 'all');

    var result = '';

    //if ($('input[name=include_header]').is(':checked')) {
        var is_first = true;
        $('.search_result th').each(function() {
            if (all_columns || !$(this).hasClass('hidden')) {
                if (!is_first) {
                    result += '"'+$(this).text()+'"';
                    result += ',';
                } else {
                    is_first = false;
                }
            }
        });
        result += '\n';
    //}

    var field_number = 1;
    var process_row = true;
    $('.search_result td').each(function() {
        // Skip first td with checkbox.
        if (field_number % number_of_fields != 1) {
            // Skip hidden columns if not all_columns.
            if (all_columns || !$(this).hasClass('hidden')) {
                // Skip row if necessary.
                if (process_row) {
                    result += '"'+$(this).text()+'"';
                    result += ',';
                }
            }
        } else {
            if (field_number != 1 && process_row) result += '\n';
            process_row = true;
            if (!all_rows) {
                var checkbox = $(this).find('.check_one');
                if (!checkbox.attr('checked')) {
                    process_row = false;
                }
            }
        }
        field_number++;
    });

    $.download('export_search_results', {
        result: result
    });

    closePopup();
}

function capitalize_first_letter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

function get_selected_users() {
    var field_number = 1;
    var users = '';
    var process_row = true;
    $('.search_result td').each(function() {
        if (field_number % number_of_fields != 1) {
            if (process_row && (field_number % number_of_fields == 2 || field_number % number_of_fields == 4 || field_number % number_of_fields == 12)) {
                users += $(this).text() + "   ";
            }
        } else {
            if (field_number != 1 && process_row) users += '<br/>';
            process_row = true;
            var checkbox = $(this).find('.check_one');
            if (!checkbox.attr('checked')) {
                process_row = false;
            }
        }
        field_number++;
    });

    return users;
}