function show_send_bulk_notice_popup() {
    show_popup('send_bulk_notice');
    var users = get_selected_users();
    $('#popup #bulk_notice_user_list').html(users);
}

function send_bulk_notice() {
    var ids = value_list('.check_one:checked');
    if (ids.length == 0) {
        closePopup();
        return;
    }
    $.post('send_bulk_notice', {
                ids: ids.join(','),
                notification_message_topic: $('#notification_message_topic').val(),
                notification_message_text: $('#notification_message_text').val()
            },
            function() {
                closePopup();
            }
    );
}

function load_message(id) {
    if (id == 0) {
        $('#notification_message_topic').val('');
        $('#notification_message_text').val('');
    } else {
        $('#notification_message_topic').val('Loading...');
        $('#notification_message_text').val('Loading...');
        $.getJSON('get_notification_message', {
            id: id
        },
        function(data) {
            $('#notification_message_topic').val(data.message_topic);
            $('#notification_message_text').val(data.message_text);
        })
    }
}

function save_bulk_notice_template() {
    $.post('save_bulk_notice_template',
        {
            notification_message_topic: $('#notification_message_topic').val(),
            notification_message_text: $('#notification_message_text').val()
        },
        function(data) {
            $('#previous_messages')
                .prepend($('<option>', { value : data })
                .text($('#notification_message_topic').val()));
        }
    );
}

function delete_bulk_notice_template() {
    var id = $('#previous_messages').val();
    if (id == 0) return;
    $.post('delete_bulk_notice_template',
        {
            id: id
        },
        function() {
            $("#previous_messages option[value='" + id + "']").remove();
            $('#previous_messages').val('0');
            $('#notification_message_topic').val('');
            $('#notification_message_text').val('');
        }
    );
}