jQuery(document).ready(function() {

    var loc = location.hash;
    //alert (loc);
    loc = loc.split('#');
    if (loc.length > 1) {
        selector = loc[1];
        value = loc[2]
        if (selector != 'timeline') {
            browse_docs(this, selector, value);
        }
        else {
            browse_docs('f', selector, value);
        }
    }
    else {
        value = '';
        selector = 'most_viewed';
        browse_docs('', selector, value);
    }
    jQuery('#' + selector).addClass('active');
    jQuery('#' + selector).parent().next().slideToggle(200);

    jQuery('#menu_collections').addClass('active').parent().next().slideDown(200);

});


function browse_docs(obj, selector, value, or_and) {
    var url = 'browse_archives';
    data_obj = {value:value,selector:selector, or_and: or_and};
    if (selector == 'people') {
        jQuery.extend(data_obj, {text:jQuery(obj).html()})
    }
    jQuery.post(url, data_obj, function(data) {
        jQuery('#search_results').html(data)
                .search_results_callback()
                .search_results_snippets_callback();
        apply_view_options();
        jQuery('#search_results').show();
        jQuery('#search_results').removeClass('hidden');
    });
}
