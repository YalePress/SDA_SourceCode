<?php

define('NOTIFICATION_ADD_DOCUMENT_TO_RI_FOLDER', 1);
define('NOTIFICATION_REPLY_TO_POST', 2);
define('NOTIFICATION_START_TOPIC', 3);
define('NOTIFICATION_RI_INVITATION', 7);
define('NOTIFICATION_SUBTYPE_RI_INVITATION_ACCEPTED', 1);
define('NOTIFICATION_SUBTYPE_RI_INVITATION_DECLINED', 2);
define('NOTIFICATION_RI_INVITATION_REPLIED', 8);
define('NOTIFICATION_ADD_DOCUMENT_TO_SDA', 9);
define('NOTIFICATION_BULK_MESSAGE', 11);

define('NOTIFICATION_COMPLAINT_ANNOTATION', 30);
define('NOTIFICATION_COMPLAINT_FORUM_POST', 31);

function my_sda_notifications_count()
{
    global $user;
    return db_result(db_query("SELECT count(*) FROM notifications WHERE to_user_id=%d", $user->uid));
}

function my_sda_notifications()
{
    global $user;

    $notifications = db_get_list(db_query("SELECT * FROM notifications WHERE to_user_id =%d ORDER BY creation_date DESC", $user->uid));

    echo tpl('my_sda', 'notifications',
             array(
                  'notifications' => $notifications
             ));
}

function get_notification_text_html($notification)
{
    $object_id = $notification['object_id'];
    $from_user_id = $notification['from_user_id'];

    switch ($notification['type']) {
        case NOTIFICATION_ADD_DOCUMENT_TO_RI_FOLDER:
            return get_user_link($from_user_id) . " added a document to " . get_folder_link($object_id);
            break;

        case NOTIFICATION_REPLY_TO_POST:
            return get_user_link($from_user_id) . " replied to " . get_topic_link($object_id);
            break;

        case NOTIFICATION_START_TOPIC:
            return get_user_link($from_user_id) . " started a new Topic: " . get_topic_link($object_id);
            break;

        case NOTIFICATION_ADD_DOCUMENT_TO_SDA:
            return get_document_link($object_id) . " has just been added to the Stalin Digital Archives.";
            break;

        case NOTIFICATION_BULK_MESSAGE:
            return get_bulk_notice_text($object_id);
            break;

        case NOTIFICATION_COMPLAINT_ANNOTATION:
            return get_annotation_complaint_text($from_user_id, $object_id);

        case NOTIFICATION_RI_INVITATION:
            $text = "You have been invited by " . get_user_link($from_user_id) . " to join " . get_ri_link($object_id) . '<br/>';
            if ($notification['subtype'] == NOTIFICATION_SUBTYPE_RI_INVITATION_ACCEPTED) {
                $text .= "You have accepted this invitation.";
            } else if($notification['subtype'] == NOTIFICATION_SUBTYPE_RI_INVITATION_DECLINED) {
                $text .= "You have declined this invitation.";
            } else {
                $text .= '<div id="result_text_' . $notification['id'] . '">';
                $text .= '<a href="#" onclick="accept_invitation('.$notification['id'].'); return false;">Accept</a>&nbsp;&nbsp;';
                $text .= '<a href="#" onclick="decline_invitation('.$notification['id'].'); return false;">Decline</a>&nbsp;&nbsp;';
                $text .= '</div>';
            }
            return $text;

        case NOTIFICATION_RI_INVITATION_REPLIED:
            return get_user_link($from_user_id) . ' has ' .($notification['subtype'] == NOTIFICATION_SUBTYPE_RI_INVITATION_ACCEPTED ? 'accepted' : 'declined')
                    . ' your invitation to join ' . get_ri_link($object_id);

        default:
            return "Notifications of this type are not supported.";
            break;
    }
}

function get_user_name($userId)
{
    $query = "SELECT u.mail as mail, pv.value AS first_name, pv1.value AS last_name FROM users u
    LEFT JOIN profile_values pv ON pv.uid = u.uid AND pv.fid = '1'
    LEFT JOIN profile_values pv1 ON pv1.uid = u.uid AND pv1.fid = '2'
    WHERE u.uid = {$userId}";
    $result = db_fetch_array(db_query($query));
    if ($result['first_name']) {
        return $result['first_name'] . ' ' . $result['last_name'];
    } else {
        return $result['mail'];
    }
}

function get_user_link($userId)
{
    global $base_url;

    $name = get_user_name($userId);

    if (!empty($name)) {
//        TODO: replace hardcode node/13 everywhere!
        return '<a href="' . $base_url . '/node/13#page=profile&id=' . $userId . '">' . $name . '</a>';
    } else {
        return 'Deleted user';
    }
}

function get_folder_link($folderId)
{
    $name = get_folder_name($folderId);
    if (!empty($name)) {
        return '<a href="#page=folder&id=' . $folderId . '">' . $name . ' Folder</a>';
    } else {
        return 'deleted folder';
    }
}

function get_folder_name($folderId)
{
    $query = "SELECT name FROM folders WHERE id={$folderId}";
    $result = db_fetch_array(db_query($query));
    return $result['name'];
}

function get_topic_link($topicId)
{
    $query = "select ft.title topic_title, ri.id ri_id, ri.name ri_name, ft.is_deleted is_topic_deleted, f.is_deleted is_forum_deleted from forum_topics ft
    join forums f on f.id = ft.forum_id
    join research_interests ri on ri.id = f.research_interest_id
    where ft.id = {$topicId}";
    $result = db_fetch_array(db_query($query));
    if ($result['is_topic_deleted'] == '1' || $result['is_forum_deleted'] == '1' || empty($result['ri_name'])) {
        return 'deleted topic';
    } else {
        return '<a href="#page=ri&id=' . $result['ri_id'] . '">' . $result['ri_name'] . '</a>: ' .
               '<a href="#page=discussions&topic=' . $topicId . '">' . $result['topic_title'] . '</a>';
    }
}

function get_document_link($documentId)
{
    global $base_url;
    $query = "select title from node where nid = {$documentId}";
    $result = db_fetch_array(db_query($query));
    return '<a href="' . $base_url . '/sda_viewer?n=' . $documentId . '">Document ' . $result['title'] . '</a>';
}

function get_ri_link($riId)
{
    $name = get_ri_name($riId);
    if (!empty($name)) {
        return '<a href="#page=ri&id=' . $riId . '">' . $name . '</a>';
    } else {
        return 'deleted research interest';
    }
}

function get_ri_name($riId)
{
    $query = "SELECT name FROM research_interests WHERE id={$riId}";
    $result = db_fetch_array(db_query($query));
    return $result['name'];
}

function delete_my_sda_notification()
{
    $id = $_POST['id'];
    $query = "DELETE FROM notifications WHERE id={$id}";
    db_query($query);
}

function mysda_notification_format_date($date_str)
{
    return sda_format_date($date_str, 'm/d/Y g:i a');
}

function insert_notification($type, $to_user_id, $from_user_id, $object_id)
{
    $current_date = db_now();
    $query = "INSERT INTO notifications(type, to_user_id, creation_date, from_user_id, object_id) VALUES
        ($type, $to_user_id, '{$current_date}', $from_user_id, $object_id)";
    db_query($query);
}

function insert_notification_with_subtype($type, $to_user_id, $from_user_id, $object_id, $subtype)
{
    $current_date = db_now();
    $query = "INSERT INTO notifications(type, to_user_id, creation_date, from_user_id, object_id, subtype) VALUES
        ($type, $to_user_id, '{$current_date}', $from_user_id, $object_id, $subtype)";
    db_query($query);
}

function get_bulk_notice_text($id)
{
    $query = "SELECT text FROM bulk_notification_messages WHERE id = %d";
    $result = db_fetch_array(db_query($query, $id));
    return $result['text'];
}

function get_annotation_complaint_text($from_user_id, $complaint_id)
{
    global $base_url;
    $complaint = db_fetch_array(
        db_query("SELECT ca.annotation_id, ca.text, a.document_id AS nid
        FROM complaints_to_annotations ca
        JOIN annotations a ON ca.annotation_id=a.id
        WHERE ca.id=%d", $complaint_id));

    $user = get_user_link($from_user_id);

    if ($complaint) {
        $txt = $user . ' has reported annotation <a href="'
               . ($base_url . '/sda_viewer?n=' . $complaint['nid'] . '&t=ann&id=' . $complaint['annotation_id'])
               . '">(link)</a>. His comment: ' . htmlspecialchars($complaint['text']);

    } else {
        $txt = $user . ' has reported annotation, but this annotation was later removed.';
    }

    return $txt;
}