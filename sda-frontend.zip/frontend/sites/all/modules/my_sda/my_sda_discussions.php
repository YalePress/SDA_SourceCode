<?php

function echo_all_discussion_home(){
    $out=create_all_discussion_home_header();
    $out.=create_all_discussion_home_content();
    echo $out;
}

function create_all_discussion_home_header(){
    $out = '<div class="cell_title">
                <div id="results_title">Discussion Boards - All Discussions</div>' .
                    get_discussion_search_html(false) .
             '</div>';

    return $out;
}

function get_discussion_search_html($is_results) {
    if ($is_results) $initial_color = "black"; else $initial_color = "gray";
    return '<div class="discussion_search">
                <input type="text" style="width:150px; color:'.$initial_color.';" name="search_field_header" id="search_field_header" value="Search Discussions" onfocus="clearDefaultText();" onblur="replaceDefaultText();" onkeydown="if (event.keyCode == 13 && document.getElementById(\'search_field_header\').value != \'\') document.getElementById(\'btn_search_header\').click()"/>
                <input type="button" id="btn_search_header" value="Search" onclick="window.location=\'#page=search_discussions&query=\' + document.getElementById(\'search_field_header\').value;">
                <script>
                    function clearDefaultText() {
                        var searchField = document.getElementById("search_field_header");
                        if (searchField.value == "Search Discussions") {
                            searchField.value = "";
                            searchField.style.color = "black"
                        }
                    }

                    function replaceDefaultText() {
                        var searchField = document.getElementById("search_field_header");
                        if (searchField.value == "") {
                            searchField.value = "Search Discussions";
                            searchField.style.color = "gray"
                        }
                    }
                </script>
            </div>';
}

function create_all_discussion_home_content(){
$index = 0;
    $out='';
    $blocks = array();
        $blocks[++$index] = create_all_discussion_home_content_block('Discussion_forums', $index);
        $blocks[++$index] = create_all_discussion_home_content_block('recent_topics', $index);
  /*  if (!empty($_COOKIE['sortable_all_discussion']))
    {
        $order_blocks = json_decode($_COOKIE['sortable_all_discussion']);
        foreach ($order_blocks as $id => $order_block)
        {
            $out .= '<div id="'.$id.'"><ul class="connectedSortable">';
            foreach ($order_block as $number)
                $out .= $blocks[$number];
            $out .= '</ul></div>';
        }
    }
    else
    {         */
        $out .= '<div id="my_sda_home_center" class="all_disc"><ul class="connectedSortable">';
        foreach ($blocks as $id => $block)
        {
            if ($id == 2)
            {
                $out .= '</ul></div>';
                $out .= '<div id="my_sda_home_right" class="all_disc"><ul class="connectedSortable">';
            }
            $out .= $block;
        }
        $out.='</ul></div>';
 //   }   */
    $out .= "<div class='clear'></div>";
    return $out;
}

function create_all_discussion_home_content_block($selector, $index) {
    $out = '<li id="sortable_'.$selector.'" class="sortable-'.$index.'">';
        $out .= '<div id="my_sda_home_'.$selector.'" class="my_sda_home_block">';
            $out .= '<div class="my_sda_discussions_home_block_header">';
                switch ($selector) {
                    case 'Discussion_forums':
                        $out .= '<div style="float:left"><h2>'.t('Discussion Forums').'</h2></div>';
                        if (is_admin() || user_access('Create a General Discussion Forum')) {
                             $out .= '<div style="float:right"><input type="button" class="create_new_forum_button" value="Create New Forum" onclick="show_create_forum_popup(); return false;" /></div>';
                             //$out .= '<div style="float:right"><input type="button" onclick="show_create_forum_popup(); return false;" value="Create New Forum"></div>';
                             $out .= '<div id="popup_create_forum" class="hidden">
                                        <div class="popup_header">Create General Discussion Forum
                                            <img alt="Close" src="' . base_path() . 'sites/all/themes/stalin/images/cross_close.png">
                                        </div>
                                        <div class="popup_body">
                                            <div class="popup_body_title">Discussion forum name:<p/></div>
                                            <input type="text" id="forum_name" size="40"></input><p/>
                                            <div class="popup_body_title">Discussion forum description:<p/></div>
                                            <input type="text" id="forum_description" size="40"></input>
                                        </div>
                                        <div class="popup_footer">'
                                            . button_link(array('text' => 'Cancel', 'onclick' => "closePopup(); return false;"))
                                            . '<span id="create_button">' . button_link(array('text' => 'Create')) . '</span>' .
                                        '</div>
                                      </div>';
                        }
                    break;
                    case 'recent_topics':
                        $out .= '<h2>'.t('Recent Topics').'</h2>';
                    break;
                }

          //  $out.='<div class="my_sda_block_toggle_buttons">';
            //    $out.='<a href="#" onckick="return false;"><img class="minus" src="'.$base_url.'/'.$directory.'sites/all/themes/stalin/images/sda_home_button_minus.png"></a>';
             //   $out.='<a href="#" onckick="return false;"><img class="plus" src="'.$base_url.'/'.$directory.'sites/all/themes/stalin/images/sda_home_button_plus.png"></a>';
               // $out.='</div>';
            $out .='</div>';
            $out .= '<div class="my_sda_discussion_home_block_content">';
            switch ($selector) {
                case 'Discussion_forums':
                    $out.=get_discussions_forums('creation_date', 'asc');
                break;

                case 'recent_topics':
                $topics = get_recent_topics();
                $out .= '<div id="recent_topics_carousel"><ul>';
                foreach ($topics as $topic){
                    $out .= '<li class="recent_topic">';
                        $out .= '<div class="topic_title"><a href="#page=discussions&topic='.$topic['id'].'">'.htmlspecialchars($topic['title']).'</a></div>';
                        $out .= '<div class="topic_posted">Posted '.date_ago($topic['latest_reply_date']).' ago in ';
                        $out .= '<a href="#page=discussions&forum='.$topic['forum_id'].'">'.htmlspecialchars($topic['forum_name']).'</a></div>';
                    $out .= '</li>';
                }
                $out .= '</ul></div>';
                
                $out .= '<div class="controls recent_topics_carousel"><div class="scroll_up disabled"></div>
                            <div class="scroll_down"></div>
                            </div>'; 
                break;
            }
            $out .= '</div>';
        $out .= '</div>';
    $out .= '</li>';
    return $out;
}

function get_recent_forums($sort_by="creation_date", $order="asc", $general){
    $query = "SELECT f.id as id, f.name as name, f.description as description, f.number_of_topics as number_of_topics
    FROM forums f
        WHERE f.is_deleted = '0' ";
    if ($general == 0) {
        $query .= 'AND f.research_interest_id is null';
    } else {
        $query .= 'AND f.research_interest_id is not null';
    }
    $query .= " ORDER BY f.{$sort_by} {$order}";
    $forums = array();
    $results = db_query($query);
    while ($result = db_fetch_array($results)) {
        $forums[] = $result;
    }
    
    return $forums;
}

function get_recent_topics(){
    $query = "SELECT ft.id as id, ft.title as title, ft.latest_reply_date as latest_reply_date, f.name as forum_name, f.id as forum_id FROM forum_topics ft
        LEFT JOIN forums f ON f.id = ft.forum_id
        WHERE ft.is_deleted = 0
        ORDER BY latest_reply_date DESC
        LIMIT 0, 8";
    $topics = array();
    $results = db_query($query);
    while ($result = db_fetch_array($results)) {
        $topics[]=  $result;
    }

    return $topics;
}

function open_forum_discussions(){
    $forum_id = $_POST['id'];
    $order = $_POST['order'];
    $sort_by = $_POST['sort_by'];
    $page = $_POST['page'];
    $number_per_page = 10;

    if (empty($order)) $order = 'DESC';
    if (empty($sort_by)) $sort_by = 'latest_reply_date';
    if (empty($page)) $page = 1;

    $forum = db_fetch_array(db_query("SELECT name, number_of_topics, is_deleted, research_interest_id FROM forums WHERE id = %d", $forum_id));
    if (empty($forum)) {
        echo 'Sorry, this forum doesn\'t exist.';
        exit();
    } else if ($forum['is_deleted']) {
        echo 'Sorry, this forum was deleted by the administrator.';
        exit();
    }

    if ($forum['research_interest_id'] == null) $is_general_forum = true; else $is_general_forum = false;

    global $user;
    $result = db_fetch_array(db_query("SELECT * FROM research_interests_users WHERE user_id = %d AND research_interest_id = %d", $user->uid, $forum['research_interest_id']));
    $is_ri_member = !empty($result);

    $number_of_topics = $forum['number_of_topics'];
    if (empty($number_of_topics)) $number_of_topics = 0;

    $page_count = floor(($number_of_topics - 1) / $number_per_page) + 1;
    $start = ($page - 1) * $number_per_page;

    $query = "SELECT id, title, number_of_posts, latest_reply_date , latest_reply_user_id, creator_id, creation_date FROM forum_topics
    WHERE forum_id = %d AND is_deleted = 0
    ORDER BY %s %s
    LIMIT %d, %d";
    $results = db_query($query, $forum_id, $sort_by, $order, $start, $number_per_page);
    $topics = array();
    while($result = db_fetch_array($results)){
        $topics[] = $result;
    }

    $out = '<div class="cell_title">
               <div id="results_title" style="font-size: 15px">Discussion Forum</div>' .
               get_discussion_search_html(false) .
             '</div>';
    $out .= '<div class="cell_title">
               <div id="results_title">'.htmlspecialchars($forum['name']).' ('.$number_of_topics.')</div>
               <div id="back_link"><a href="#page=discussions">&#9668; Discussion Boards Home</a></div>
             </div>';
    $out .= '<div class="hidden" id="forum_id">'.$forum_id.'</div>';
    $out .= '<div class="hidden" id="popup_delete_forum_topic"></div>';
    $out .= '<table cellpadding="0" cellspacing="0" border="0" class="my_sda_result">';
    $out .= '<thead>
              <tr class="header">
                <th class="title">';
    $access_to_join_forum = true; //user_access('Join a Discussion Forum');
    if (($is_ri_member || $is_general_forum) && $access_to_join_forum) $out .= '<div class="btn_start_topic"><input type="button" value="Start New Topic"/></div>';
                $out .='<div class="resize">TOPIC<a class="discussions" href="title"></a><div class="va_middle"></div></div></th>
                <th class="number_of_posts"><div class="resize">REPLIES<a class="discussions" href="number_of_posts"></a><div class="va_middle"></div></div></th>
                <th class="creation_date"><div class="resize">CREATED BY<a class="discussions" href="creation_date"></a><div class="va_middle"></div></div></th>
                <th class="latest_reply_date "><div class="resize">LATEST REPLY<a class="discussions" href="latest_reply_date "></a><div class="va_middle"></div></div></th>
              </tr>
             </thead>
             <tbody>';
    foreach ($topics as $topic){
        $out .= '<tr id="topic_'.$topic['id'].'">';
        $out .= '<td>';
        if (is_admin()) {
            $out .= '<img style="padding-left: 10px; cursor: pointer" src="' . base_path() . 'sites/all/themes/stalin/images/cross_close.png" onclick="show_delete_forum_topic_popup(' . $topic['id'] . ',\''.$topic['title'].'\');" />';
        }
        $out .= '<a href="#page=discussions&topic='.$topic['id'].'">'.htmlspecialchars($topic['title']).'</a></td>';
        $out .= '<td>'.($topic['number_of_posts'] - 1).'</td>';
        $out .= '<td>'.'<div class="discussion_username"><a href="#" onclick="show_prew_user_info_popup('.$topic['creator_id'].'); return false;">'.get_apropriate_user_name($topic['creator_id']).'</a></div><div class="discussion_date">'.mysda_format_date($topic['creation_date']).'</div></td>';
        $out .= '<td><div class="discussion_username"><a href="#" onclick="show_prew_user_info_popup('.$topic['latest_reply_user_id'].'); return false;">'.get_apropriate_user_name($topic['latest_reply_user_id']).'</a></div><div class="discussion_date">'.mysda_format_date($topic['latest_reply_date']).'</div></td></tr>';
    }
    $out.='</tbody></table>';

    $out.='<div class="pagination bottom_no_hr">';
    $need_points = true;
    if ($page_count > 1) {
        $out .= '<ul>
                  <li class="prev">';
                    if ($page > 1) {
                        $out .= '<a href="#page=discussions&forum='.$forum_id.'&sort_by='.$sort_by.'&order='.$order.'&p='.($page - 1).'"></a>';
                    } else {
                        $out .= '<a href="#" onclick="return false;"></a>';
                    }
        $out .= '</li>';
        for ($i = 1; $i <= $page_count; $i++) {
            if ($i != 1 && $i != 2 && $i != $page - 1 && $i != $page && $i != $page + 1 && $i != $page_count - 1 && $i != $page_count) {
                if ($need_points) {
                    $out .= '<li><span>...</span></li>';
                    $need_points = false;
                }
                continue;
            } else {
                $needPoints = true;
            }
            if ($i == $page) {
                $out .= '<li><span>'.$i.'</span></li>';
            } else {
                $out .= '<li><a href="#page=discussions&forum='.$forum_id.'&sort_by='.$sort_by.'&order='.$order.'&p='.$i.'">'.$i.'</a></li>';
            }
        }
        $out .=  '<li class="next">';
        if ($page < $page_count) {
            $out .= '<a href="#page=discussions&forum='.$forum_id.'&sort_by='.$sort_by.'&order='.$order.'&p='.($page + 1).'"></a>';
        } else {
            $out .= '<a href="#" onclick="return false;"></a>';
        }
        $out .= '</li>
            </ul>';
    }
    $out .= '</div>';

    echo $out;
}

function create_delete_forum_topic_popup() {
    $topic_id = $_POST['topic_id'];
    $topic_title = $_POST['topic_title'];
    $out = '<div class="popup_header">'
            .t('Delete Topic')
            .'<img alt="Close" src="'.base_path().'sites/all/themes/stalin/images/cross_close.png">'
         .'</div>'
         .'<div class="popup_body">'
            .'<b>'.$topic_title.'</b>'
            .'<p/>Are you sure you want to delete this Topic?</p>';

    $out .= '<input type="button" class="popup_button" onclick="delete_forum_topic('.$topic_id.'); closePopup();" value="Delete Topic">';
    $out .= '<input type="button" class="popup_button" onclick="closePopup()" value="Cancel">';
    $out .= '</div>';

    echo $out;
}

function create_delete_forum_post_popup() {
    $post_id = $_POST['post_id'];
    $out = '<div class="popup_header">Delete Post'
        .'<img alt="Close" src="'.base_path().'sites/all/themes/stalin/images/cross_close.png">'
         .'</div>'
         .'<div class="popup_body">';
    $out.='Are you sure you want to delete this reply?<p/>';

    $out.='<input type="button" class="popup_button" value="Delete Post" onclick="delete_post('.$post_id.'); closePopup();"/>';
    $out.='<input type="button" class="popup_button" value="Cancel" onclick="closePopup();"/>';
    $out.='</div>';
    echo $out;
}

function popup_add_link_to_document(){
    global $user;
    $query="SELECT f.name as name, f.id as id FROM folders f WHERE f.user_id = %d";
    $user_folders = array();
    $results = db_query($query, $user->uid);
    while ($result = db_fetch_array($results)){
        $user_folders[] = $result;
    }
    $query = "SELECT f.name as name, f.id as id FROM folders f
              JOIN research_interests ri ON ri.id = f.research_interest_id
              JOIN research_interests_users riu ON riu.research_interest_id = ri.id
              WHERE riu.user_id = %d"; // AND ri.type = 0

    $ri_folders=array();
    $results=db_query($query, $user->uid);
    while ($result=db_fetch_array($results)){
        $ri_folders[]=$result;
    }
    /*$query = "SELECT f.name as name, f.id as id FROM folders f
              JOIN research_interests ri ON ri.id = f.research_interest_id
              JOIN research_interests_users riu ON riu.research_interest_id = ri.id
              WHERE ri.type = 1 AND riu.user_id = %d";

    $private_folders=array();
    $results=db_query($query, $user->uid);
    while ($result=db_fetch_array($results)){
        $private_folders[]=$result;
    }*/
    $out = '<div id="popup_add_link_to_document" class="hidden">
        <div class="popup_header">Link to Document'
        .'<img alt="Close" src="'.base_path().'sites/all/themes/stalin/images/cross_close.png">'
         .'</div>'
         .'<div class="popup_body">';
    $out.='<div class="popup_body_title">Choose folder:</div>';
    $out.='<div class="popup_body_select" id="folder_select"> <select name="folder" id="folder">';
    if (count($user_folders) > 0) {
        $out.='<option value="0" disabled="disabled" selected="selected">Personal Folders:</option>';
        foreach ($user_folders as $user_folder){
            $out.='<option value="'.$user_folder['id'].'">'.$user_folder['name'].'</option>';
        }
    }
    /*if (count($private_folders) > 0) {
        $out.='<option value="0" disabled="disabled">Private Group Folders:</option>';
        foreach ($private_folders as $private_folder){
            $out.='<option value="'.$private_folder['id'].'">'.$private_folder['name'].'</option>';
        }
    }*/
    if (count($ri_folders) > 0) {
        $out.='<option value="0" disabled="disabled">Research Interests:</option>';
        foreach ($ri_folders as $ri_folder){
            $out.='<option value="'.$ri_folder['id'].'">'.$ri_folder['name'].'</option>';
        }
    }
    $out.='</select></div>';
    $out.='<div class="popup_body_title">Select document:</div>';
    $out.='<div class="popup_body_select" id="document_select"> <select name="document" id="document">';
    $out.='<option value="0" disabled="disabled" selected="selected">Select</option>';
    $out.='</select></div>';
    $out.='<div class="popup_body_buttons">';
    $out.='<input type="button" value="Cancel" onclick="closePopup();"/>';
    $out.='<input type="button" value="Post Link" onclick="post_link_to_document();"/>';
    $out.='</div></div></div>';
    return $out;
}

function show_start_topic(){
    global $user;
    $forum_id=$_POST['forum_id'];
    $out = '<div class="cell_title">
            <div id="results_title">Start New Topic</div>
    </div>';
    $query = "SELECT f.id, f.name FROM forums f
                JOIN research_interests ri ON ri.id = f.research_interest_id
                JOIN research_interests_users riu ON riu.research_interest_id = ri.id
                WHERE f.is_deleted = 0 AND riu.user_id = %d " . /* AND ri.type = 0*/
                "ORDER BY name";
    $results = db_query($query, $user->uid);
    $public_forums = array();
    while ($result = db_fetch_array($results)){
        $public_forums[] = $result;
    }

    $query = "SELECT f.id, f.name FROM forums f
                WHERE f.is_deleted = 0 AND f.research_interest_id is null
                ORDER BY name";
    $results = db_query($query);
    $general_forums = array();
    while ($result = db_fetch_array($results)){
        $general_forums[] = $result;
    }
    /*$query = "SELECT f.id, f.name FROM forums f
                JOIN research_interests ri ON ri.id = f.research_interest_id
                JOIN research_interests_users riu ON riu.research_interest_id = ri.id
                WHERE f.is_deleted = 0 AND riu.user_id = %d AND ri.type = 1
                ORDER BY name";
    $results = db_query($query, $user->uid);
    $private_forums = array();
    while ($result = db_fetch_array($results)){
        $private_forums[] = $result;
    }*/

    $out .= '<div id="start_new_topic">
        <form method="post">
        <div><div class="start_form_title">Forum:</div>
        <select name="forum" id="forum">';
    if ($forum_id == 0) {
        $out .= '<option value="0" selected="selected">Select Forum</option>';
    }
    if (count($general_forums) > 0) {
        $out .= '<option value="0" disabled>General Forums:</option>';
        foreach($general_forums as $forum){
            if ($forum_id == $forum['id']) $selected = 'selected="selected"'; else $selected = '';
            $out .= '<option value="'.$forum['id'].'" '.$selected.'>'.$forum['name'].'</option>';
        }
    }
    if (count($public_forums) > 0) {
        $out .= '<option value="0" disabled>Research Interest Forums:</option>';
        foreach($public_forums as $forum){
            if ($forum_id == $forum['id']) $selected = 'selected="selected"'; else $selected = '';
            $out .= '<option value="'.$forum['id'].'" '.$selected.'>'.$forum['name'].'</option>';
        }
    }
    /*if (count($private_forums) > 0) {
        $out .= '<option value="0" disabled>Private Group Forums:</option>';
        foreach($private_forums as $forum){
            if ($forum_id == $forum['id']) $selected = 'selected="selected"'; else $selected = '';
            $out .= '<option value="'.$forum['id'].'" '.$selected.'>'.$forum['name'].'</option>';
        }
    }*/
    $out .= '</select>
        </div>
        <div id="forum_error" class="error_div"></div>

        <div> <div class="start_form_title">Topic Title: </div>
        <input type"text" name="title" id="title" size="120" width="500px"/>
        <div id="title_error" class="error_div"></div>
        </div>';

        $out .='<div><div class="start_form_title">Post:</div>';
        $out .= '<div class="link_to_document"><input id="link_document_button" type="button" onclick="show_popup(\'add_link_to_document\')" value="Link to document"></div><p/>';
        $out .= popup_add_link_to_document();

        $out .= '<textarea cols="90" rows="10" name="first_post" width="500px" id="first_post"></textarea>
        <div id="first_post_error" class="error_div"></div>
        </div>';

        if (user_access('Create a Sticky/NO replies Discussion Post')) {
            $out .= '<div class="start_form_right" id="normal_or_sticky">
            <div><input type="radio" name="normal_or_sticky" value="normal" id="normal" checked="checked"> Normal </div>
            <div><input type="radio" name="normal_or_sticky" id="sticky" value="sticky"> Sticky </div>
            <div id="prevent_replies" style="display:none"><input type="checkbox" name="prevent" id="prevent"> Prevent Replies </div></div>';
        }
    $out .= '<div>
                <div class="hidden" id="linked_document_id"></div>
                <div class="add_document" id="doc_title"></div>
                <div class="start_form_buttons"><input type="button" onclick="window.location=\'#page=discussions&forum='.$forum_id.'\'" value="Cancel"> <input type="button" onclick="post_new_topic(); return false;" name="post_form" value="Post"></div>
             </div>
            </form></div>';

    echo $out;
}

function create_list_docs_to_folder($folder_id){
    $query="SELECT f.document_id as id, d.title as title FROM documents_folders f
    JOIN node_view d ON f.document_id=d.nid
    WHERE f.folder_id={$folder_id}
    ORDER BY d.title";
    $results=db_query($query);
    $out = '';
    while ($result=db_fetch_array($results)){
        $out .= '<option value="'.$result['id'].'">'.crop($result['title'],30).'</option>';
    }
    return $out;
}

function echo_list_to_folder(){
    $folder_id=$_POST['folder_id'];
    $out = '<select name="document" id="document">';
    $out.=create_list_docs_to_folder($folder_id);
    $out.='</select>';
    echo $out;
}

function create_new_topic()
{
    global $user;
    $title = $_POST['title'];
    $forum = $_POST['forum'];
    $first_post = $_POST['first_post'];
    $type = $_POST['sticky'];
    $prevent = $_POST['prevent'];
    $linked_document_id = $_POST['linked_document_id'];

    if (empty($linked_document_id)) {
        $linked_document_id = 0;
    }

    $current_date = db_now();

    db_query(
        "INSERT INTO forum_topics (title, creator_id, creation_date, forum_id)
        VALUES ('%s',%d,'%s',%d)",
        $title, $user->uid, $current_date, $forum
    );

    $topic_id = db_last_insert_id("forum_topics","id");

    db_query(
        "INSERT INTO forum_posts (text, creator_id, creation_date, topic_id, type, replies_prevented, linked_document_id)
        VALUES ('%s', %d, '%s', %d, %d, %d, %d)",
        $first_post, $user->uid, $current_date,$topic_id,$type,$prevent,$linked_document_id
    );

    // Insert notifications.
    $results = db_query(
        "SELECT user_id FROM research_interests_users
        WHERE research_interest_id = (SELECT research_interest_id FROM forums WHERE id = %d)", $forum);

    while ($result = db_fetch_array($results)) {
        if ($result['user_id'] == $user->uid) {
            // Don't send the notification to the user that generated this event.
            continue;
        }
        insert_notification(NOTIFICATION_START_TOPIC, $result['user_id'], $user->uid, $topic_id);
    }

    echo $topic_id;
}

function show_topic() {
    $topic_id = $_POST['topic_id'];

    // Removing BOM (YUPDSP-268).
    if (substr($topic_id, 0,3) == pack('CCC',0xef,0xbb,0xbf)) {
        $topic_id = substr($topic_id, 3);
    }

    $topic = db_fetch_array(db_query(
        "SELECT ft.title as title, f.name as forum_name, f.id as forum_id, ft.number_of_posts, ft.is_deleted is_topic_deleted, f.is_deleted is_forum_deleted, f.research_interest_id FROM forum_topics ft
    JOIN forums f ON f.id = ft.forum_id
    WHERE ft.id = %d", $topic_id));

    if (empty($topic)) {
        echo 'Sorry, this topic doesn\'t exist.';
        exit();
    } else if ($topic['is_topic_deleted']) {
        echo 'Sorry, this topic was deleted by the administrator.';
        exit();
    } else if ($topic['is_forum_deleted']) {
        echo 'Sorry, this forum was deleted by the administrator.';
        exit();
    }

    $is_general_forum = $topic['research_interest_id'] == null;

    global $user;
    $result = db_fetch_array(db_query(
        "SELECT * FROM research_interests_users WHERE user_id = %d AND research_interest_id = %d",
        $user->uid, $topic['research_interest_id']));

    $is_ri_member = !empty($result);

    $out = '<div class="cell_title">
               <div id="results_title" style="font-size: 15px">Discussion Board</div>' .
               get_discussion_search_html(false) .
             '</div>';
    $out .= '<div class="cell_title">
            <div id="results_title"><a href="#page=discussions&forum='.$topic['forum_id'].'">'.$topic['forum_name'].'</a> : Discussion Topic</div>
            <div id="back_link"><a href="#page=discussions">&#9668; Discussion Boards Home</a></div>
    </div>';
    $out .= '<div id="topic_title">'.htmlspecialchars($topic['title']).'</div>';
    $out .= '<div id="topic_id" class="hidden">'.$topic_id.'</div>';

    $first_post = db_fetch_array(db_query(
        "SELECT fp.id as id, fp.parent_id, fp.creator_id as parent_creator, fp.text, fp.linked_document_id, fp.creator_id, fp.creation_date, fp.replies_prevented, fp.topic_id, fp.type
        FROM forum_posts fp
        WHERE fp.topic_id = %d AND fp.parent_id = 0
        ORDER BY fp.creation_date DESC", $topic_id));

    $out .= popup_add_link_to_document();
    $out .= '<div id="popup_delete_forum_post" class="hidden"></div>';

    $out .= '<div id="first_post_id" class="hidden">'.$first_post['id'].'</div>';
    $first_post['is_ri_member'] = $is_ri_member;
    $first_post['is_general_forum'] = $is_general_forum;
    $out .= create_echo_post($first_post);
    $out .= '<div id="reply_liner">Replies (<span id="replies_number">'.($topic['number_of_posts'] - 1).'</span>)</div>';

    $posts = db_query(
        "SELECT fp.id, fp.parent_id, fp.topic_id, fp1.creator_id as parent_creator, fp.text, fp.linked_document_id, fp.creator_id, fp.creation_date, fp.replies_prevented, fp.type
        FROM forum_posts fp
        LEFT JOIN forum_posts fp1 ON fp1.id = fp.parent_id
        WHERE fp.topic_id = %d AND fp.parent_id <> 0 AND fp.is_deleted = 0
        ORDER BY fp.type DESC, fp.creation_date ASC",
        $topic_id);

    while ($post = db_fetch_array($posts)) {
        $post['is_ri_member'] = $is_ri_member;
        $post['is_general_forum'] = $is_general_forum;
        $out .= create_echo_post($post);
    }

    echo $out;
}

function create_echo_post($post) {
    global $base_url;
    global $user;
    $creator = user_load($post['creator_id']);

    $out = '<div id="post_'.$post['id'].'" class="post';
    if ($post['type'] == 1) $out .= ' sticky_post';
    $out .= '">';
    $out .= '<div class="post_user_info">';
    $out .= '<div class="post_user_avatar">';
    if (!empty($creator->picture)) {
        $out .= '<img alt="User image" src="'.$base_url.'/'.$creator->picture.'">';
    } else {
        $out .= '<img alt="User image" src="'.$base_url.'/sites/default/files/pictures/no_avatar.png">';
    }
    $out .= '</div>';
    $out .= '<div class="post_user_name"><a href="#" onclick="show_prew_user_info_popup('.$post['creator_id'].'); return false;">'.get_apropriate_user_name($post['creator_id']).'</a></div>';
    $out .= '<div class="post_inst">'.htmlspecialchars($creator->profile_institution).'</div></div>';

    $out .= '<div class="post_body"><div class="post_head">';
    if (is_admin()) {
      $out .= '<div class="post_id">Post #'.$post['id'].'</div>';
    }    
    $out .= '<div class="creation_date">'.mysda_format_date($post['creation_date']);
    if ($post['parent_id']) $out .= ' (in response to <a href="#" onclick="show_prew_user_info_popup('.$post['parent_creator'].'); return false;">'.get_apropriate_user_name($post['parent_creator']).'</a>)';
    $out .= '</div></div>';

    // Replace links with hyperlinks.
    $post['text'] = ereg_replace("[[:alpha:]]+://[^<>[:space:]]+[[:alnum:]/]",
                     "<a target='_blank' href=\"\\0\">\\0</a>", $post['text']);

    $out .= '<div class="post_text">'.$post['text'].'</div>';
    if (!empty($post['linked_document_id']) && $post['linked_document_id'] != 0) {
        $result = db_fetch_array(db_query("SELECT title FROM node WHERE nid = %d", $post['linked_document_id']));
        $document_title = $result['title'];
        if (mb_strlen($document_title) > 75) {
            $document_title = mb_substr($document_title, 0, 75) . "...";
        }
        $out .= '<div class="linked_document">
                    <img style="padding-left: 10px; cursor: pointer" src="' . base_path() . 'sites/all/themes/stalin/images/document_link.png" onclick="window.open(\''.$base_url.'/sda_viewer?n='.$post['linked_document_id'].'\')"/>
                    <a href="'.$base_url.'/sda_viewer?n='.$post['linked_document_id'].'">'.htmlspecialchars($document_title).'</a></div>';
    }

    $access_to_join_forum = true; //user_access('Join a Discussion Forum');
    if ($post['replies_prevented'] == '0' && ($post['is_ri_member'] || $post['is_general_forum']) && $access_to_join_forum) {        $out .= '<div class="reply_post"><a onclick="show_form_for_reply('.$post['id'].');">Reply to this topic</a></div>';
    }
    if ((is_admin()) or ($post['creator_id'] == $user->uid)) $out .= '<div class="delete_post"><a href="#" onclick="show_delete_forum_post_popup('.$post['id'].'); return false;">Delete post</a></div>';
    $access_to_report_posts = user_access('Report Posts');
    if ($access_to_report_posts) $out .= '<div class="report_post"><a class="post_report_link" target="_blank" href=\''.create_report_post_link($post).'\'>Report post</a></div>';
    $out .= '</div>';
    $out .= '<div class="post_reply_form" id="reply_'.$post['id'].'"></div>';
    $out .= '</div>';

    return $out;
}

function create_report_post_link($post) {
    global $site_url;
    global $base_url;
    $admin_email = variable_get('site_mail', "admin@stalindigitalarchive.com");
    $subject = "Forum post report.";
    $link = "mailto:" . $admin_email . "?subject=" . $subject . "&body=";

    $link .= "Post by " . get_apropriate_user_name($post['creator_id']) . "%0A";
    $link .= 'Link to the post: ' . $site_url . $base_url . "/node/13%23page=discussions%26topic=" . $post['topic_id'] . "%26post=" . $post['id'];

    return $link;
}

function show_form_for_reply() {
    $post_id = $_POST['post_id'];

    echo create_new_post_form($post_id);
}

function create_new_post_form($post_id) {
    $out = '<div class="new_post_form">';
    $out .= '<div>';
    $out .= '<div class="Reply_to_this_post">Reply to this topic:</div>';
    $out .= '<form method="post" id="post_form">';
    $out .= '<div class="link_to_document"><input type="button" id="link_document_button" onclick="show_popup(\'add_link_to_document\')" value="Link to document"></div>';

    $out .= '<textarea name="post_text" id="post_text">';
    $out .= '</textarea>';
    $out .= '<div class="hidden" id="parent_id">'.$post_id.'</div></div>';

    $out .= '<div class="hidden" id="linked_document_id"></div>
        <div class="add_document" id="doc_title"></div>';

    if (user_access('Create a Sticky/NO replies Discussion Post')) {
        $out .= '<div class="start_form_right" id="normal_or_sticky">
        <div><input type="radio" name="normal_or_sticky" value="normal" id="normal" checked="checked"> Normal </div>
        <div><input type="radio" name="normal_or_sticky" id="sticky" value="sticky"> Sticky </div>
        <div id="prevent_replies" style="display:none"><input type="checkbox" name="prevent" id="prevent"> Prevent Replies </div></div>';
    }

    $out .= '<div class="post_form_buttons">
    <input type="button" value="Cancel" name="Cancel" onclick="hide_reply_form();">
    <input type="button" value="Post" name="post" onclick="create_post();">';
    $out .= '</div></form></div>';
    return $out;
}

function create_new_post()
{
    global $user;
    $post = array();
    $post['text'] = $_POST['text'];
    $post['parent_id'] = $_POST['parent_id'];
    $post['creator_id'] = $user->uid;
    $post['topic_id'] = $_POST['topic'];
    $post['creation_date'] = db_now();
    $post['linked_document_id'] = $_POST['linked_document_id'];
    $post['type'] = $_POST['sticky'];
    $post['replies_prevented'] = $_POST['replies_prevented'];

    db_query(
        "INSERT INTO forum_posts (text, parent_id, creator_id, topic_id, creation_date, linked_document_id, type, replies_prevented) VALUES ('%s','%d','%d','%d','%s','%d','%d','%d')",
        $post['text'], $post['parent_id'], $post['creator_id'], $post['topic_id'], $post['creation_date'], $post['linked_document_id'], $post['type'], $post['replies_prevented']);

    $post['id'] = db_last_insert_id('forum_posts', 'id');

    // Insert notifications.
    $results = db_query(
        "SELECT user_id FROM research_interests_users
        WHERE research_interest_id = (SELECT research_interest_id FROM forums WHERE id = (SELECT forum_id FROM forum_topics WHERE id = %d))", $post['topic_id']);

    while ($result = db_fetch_array($results)) {
        if ($result['user_id'] == $user->uid) {
            // Don't send the notification to the user that generated this event.
            continue;
        }
        insert_notification(NOTIFICATION_REPLY_TO_POST, $result['user_id'], $user->uid, $post['topic_id']);
    }

    $result = db_fetch_array(db_query("SELECT creator_id FROM forum_posts WHERE id = %d", $post['parent_id']));
    $post['parent_creator'] = $result['creator_id'];

    $post['is_ri_member'] = true;

    echo create_echo_post($post);
}

function delete_post() {
    $post_id = $_POST['post_id'];
    $query = "UPDATE forum_posts SET is_deleted = 1 WHERE id = %d";
    db_query($query, $post_id);

    $query = "UPDATE forum_topics SET is_deleted = 1 WHERE id = (select topic_id from forum_posts where parent_id = 0 and id = %d)";
    db_query($query, $post_id);

    echo $post_id;
}

function delete_forum_topic() {
    $topic_id = $_POST['topic_id'];
    $query = "UPDATE forum_topics SET is_deleted = 1 WHERE id = %d";
    db_query($query, $topic_id);
}

function discussion_search_result(){
    global $base_url;
    global $site_url;
    $query=$_POST['query'];
    $page=$_POST['page'];
    if (empty($page)) {
        $page = 1;
    }
    $search_type=$_POST['search_type'];

    $query= strip_tags($query);

    $sphinx_ids = null;
    try {
        $result = search_forum_posts_sphinx($search_type, $query, $page);
        $sphinx_ids = $result['ids'];
        $total_count = $result['total_count'];
    } catch (Exception $e) {
        $errors [] = $e->getMessage();
    }
    if ($total_count <= ($page - 1) * 10) {
        $page = 1;
    }
    $begin_index = ($page - 1) * 10  + 1;
    $end_index = min($page * 10, $total_count);
    $page_count = floor(($total_count - 1) / 10) + 1;

    $out = '<div class="cell_title">
            <a href="#page=discussions">&#9668; Back to discussions</a>' .
                get_discussion_search_html(true) .
            '</div>';

    $out.='<div class="discussion_search_results">
                <div class="search_results_title">Search Results</div>
                    <table class="search_form_table" cellpadding="0" cellspacing="0" width="100%">
                        <script type="text/javascript" language="javascript">
                            function getSearchType() {
                                if (document.getElementById(\'search_type_any\').checked) {
                                    return \'any\';
                                } else if (document.getElementById(\'search_type_all\').checked) {
                                    return \'all\';
                                } else if (document.getElementById(\'search_type_boolean\').checked) {
                                    return \'ext\';
                                }
                            }

                            function resetSearch() {
                                document.getElementById("results").style="visibility:hidden";
                                document.getElementById("search_type_any").checked = "checked";
                                document.getElementById("search_field").value="";
                                document.getElementById("search_field_header").value="";
                            }

                        </script>
                        <tr>
                            <td width="70%">
                                <div class="search_word"><input type="text" name="search_field" id="search_field" onkeydown="if (event.keyCode == 13 && document.getElementById(\'search_field\').value != \'\') document.getElementById(\'btn_search\').click()"/></div>
                            </td>
                            <td>
                               <a id="btn_search" href="#" onclick="window.location=\'#page=search_discussions&query=\' + document.getElementById(\'search_field\').value + \'&search_type=\' + getSearchType(); return false;"><img alt="Search" src="'.$base_url.'/sites/all/themes/stalin/images/search_submit.png" /></a>
                            </td>
                            <td style="vertical-align:middle"><a href="#" onclick="resetSearch(); return false;">Reset Search</a></td>
                        </tr>
                        <tr>
                        <td>
                        <input type="radio" value="any" name="search_type" id="search_type_any" checked="checked"> any of these words&nbsp&nbsp
                        <input type="radio" value="all" name="search_type" id="search_type_all"> all words&nbsp&nbsp
                        <input type="radio" value="ext" name="search_type" id="search_type_boolean"> boolean search
                        </td>
                        </tr>
                    </table>
                <div id="results">
                <div class="discussion result">
                <div class="search_results_count result">'.get_results_count_html($begin_index, $end_index, $total_count, $query).'</b></div>
                <div class="pagination top result">';
                    $out .= get_paginator_html($page, $page_count, $search_type, $query);
$out .=         '</div>
                <div class="clear"></div>
                </div>
                <div class="clear"></div>
                <ol id="post_list" class="search_items">';
                if (!empty($sphinx_ids)) {
                    foreach ($sphinx_ids as $post_id) {
                        $post_data = db_fetch_array(db_query("SELECT f.name forum_name, f.id forum_id, t.title topic_title, t.id topic_id, p.text post_text, p.id post_id FROM forum_posts p
                                  JOIN forum_topics t ON t.id = p.topic_id
                                  JOIN forums f ON f.id = t.forum_id
                                  WHERE p.id = %d", $post_id));
                        $out.='
                        <li class="discussions_search_li">
                            <div class="search_title"><h3><a href="#page=discussions&forum='.$post_data['forum_id'].'">'.htmlspecialchars($post_data['forum_name']).'</a> | <a href="#page=discussions&topic='.$post_data['topic_id'].'">'.htmlspecialchars($post_data['topic_title']).'</a></h3></div>
                            <div class="search_text"><span>'.get_post_text_to_display($post_data['post_text']).'</span></div>
                            <a href="'.$site_url.$base_url.'/node/13#page=discussions&topic='.$post_data['topic_id'].'&post='.$post_data['post_id'].'">'.$site_url.$base_url.'/node/13#page=discussions&topic='.$post_data['topic_id'].'&post='.$post_data['post_id'].'</a>
                        </li>';
                    }
                }
$out.=          '</ol>
                <div class="pagination bottom_no_hr" style="float:right;">';
                    $out .= get_paginator_html($page, $page_count, $search_type, $query);
$out.=          '</div>
                 </div>
            </div>';
  echo $out;
}

function get_post_text_to_display($post_text) {
    $post_text = htmlspecialchars($post_text);
    if (mb_strlen($post_text) > 500) {
        $post_text = mb_substr($post_text, 0, 500) . "...";
    }

    return $post_text;
}

function get_results_count_html($begin_index, $end_index, $total_count, $query) {
    if ($total_count == 0) {
        return "No results for <b>$query</b>";
    } else if ($total_count == 1) {
        return "1 result for <b>$query</b>";
    } else if ($total_count < 10) {
        return "$total_count results for <b>$query</b>";
    } else {
        return $begin_index.'-'.$end_index.' of '.$total_count.' results for <b>'.$query.'</b>';
    }
}

function get_paginator_html($page, $page_count, $search_type, $query) {
    if ($page_count < 2) {
        return "";
    } else {
        $out = '<ul>
                <li class="prev">';
                if ($page > 1) {
                    $out .= '<a href="#page=search_discussions&query='.$query.'&search_type='.$search_type.'&p='.($page - 1).'"></a>';
                } else {
                    $out .= '<a href="#" onclick="return false;"></a>';
                }
        $out .= '</li>';
                $needPoints = false;
                for ($i = 1; $i <= $page_count; $i++) {
                    if ($i != 1 && $i != 2 && $i != $page - 1 && $i != $page && $i != $page + 1 && $i != $page_count -1 && $i != $page_count) {
                        if ($needPoints) {
                            $out .= '<li><span>...</span></li>';
                            $needPoints = false;
                        }
                        continue;
                    } else {
                        $needPoints = true;
                    }
                    if ($i == $page) {
                        $out .= '<li><span>'.$i.'</span></li>';
                    } else {
                        $out .= '<li><a href="#page=search_discussions&query='.$query.'&search_type='.$search_type.'&p='.$i.'">'.$i.'</a></li>';
                    }
                }
        $out .=  '<li class="next">';
                if ($page < $page_count) {
                    $out .= '<a href="#page=search_discussions&query='.$query.'&search_type='.$search_type.'&p='.($page + 1).'"></a>';
                } else {
                    $out .= '<a href="#" onclick="return false;"></a>';
                }
        $out .= '</li>
            </ul>';
    }
    return $out;
}

function get_discussions_forums($sort_by, $order_by) {
    $general_forums = get_recent_forums($sort_by, $order_by, 0);
    $ri_forums = get_recent_forums($sort_by, $order_by, 1);
    $out = '<div class="recent_forums_header discussion">
    <div class="forum" id="forum_header_title"><a  onclick="order_forums(this,\'name\');return false;" href="#">FORUM</a></div>
    <div class="topics" id="topics_header_title"><a  onclick="order_forums(this,\'number_of_topics\');return false;" href="#"># TOPICS</a></div>
    </div>';
    $out .= '<div id="recent_forums_carousel"><ul>';
    if (count($general_forums > 0)) {
        $out .= '<li class="recent_forum">';
            $out .= '<div class="forum"><div style="height: 80px; line-height: 80px; text-align: center;"><b>General Forums:</b></div></div>';
        $out .= '</li>';
        foreach ($general_forums as $forum) {
            $out .= '<li id="forum_' . $forum['id'] . '" class="recent_forum">';
                $out .= '<div class="forum">
                <div class="forum_title">';
                if (is_admin() || user_access('Delete general discussion forum')) {
                    $out .= '<img style="cursor: pointer" src="' . base_path() . 'sites/all/themes/stalin/images/cross_close.png" onclick="delete_forum(' . $forum['id'] . ');" />';
                }
                $out .= '<a href="#page=discussions&forum='.$forum['id'].'">'.htmlspecialchars($forum['name']).'</a></div>';
                $out .= '<div class="forum_description">'.htmlspecialchars($forum['description']).'</div>' ;
                $out .= '</div>
                <div class="topics">'.$forum['number_of_topics'].'</div>';
            $out .= '</li>';
        }
    }
    if (count($ri_forums > 0)) {
        $out .= '<li class="recent_forum">';
            $out .= '<div class="forum"><div style="height: 80px; line-height: 80px; text-align: center;"><b>Research Interest Forums:</b></div></div>';
        $out .= '</li>';
        foreach ($ri_forums as $forum) {
            $out .= '<li id="forum_' . $forum['id'] . '" class="recent_forum">';
                $out .= '<div class="forum">
                <div class="forum_title"><a href="#page=discussions&forum='.$forum['id'].'">'.htmlspecialchars($forum['name']).'</a></div>';
                $out .= '<div class="forum_description">'.htmlspecialchars($forum['description']).'</div>' ;
                $out .= '</div>
                <div class="topics">'.$forum['number_of_topics'].'</div>';
            $out .= '</li>';
        }
    }
    $out .= '</ul></div>';

    $out .= '<div class="controls recent_forums_carousel"><div class="scroll_up disabled"></div>
                <div class="scroll_down"></div>
             </div>';
    return $out;
               
}

function echo_sorted_forums(){
    $sort_by=$_POST['sort_by'];
    $order=$_POST['order'];
    echo get_discussions_forums($sort_by, $order);
}

function get_document_title_by_id() {
    $result = db_fetch_array(db_query("SELECT title FROM node WHERE nid = %d", $_POST['id']));
    echo $result['title'];
}

function create_forum() {
    global $user;
    $forum_name = $_POST['forum_name'];
    $forum_description = $_POST['forum_description'];

    db_query("INSERT INTO forums (name, creator_id, creation_date, description) values ('%s', %d, '%s', '%s')",
             $forum_name, $user->uid, db_now(), $forum_description);

    $result = db_fetch_array(db_query("SELECT max(id) last_forum_id FROM forums WHERE name = '%s'", $forum_name));
    echo $result['last_forum_id'];
}

function delete_forum() {
    $forum_id = $_POST['forum_id'];

    $query = "UPDATE forum_topics SET is_deleted = '1' WHERE forum_id = %d";
    db_query($query, $forum_id);
    $query = "UPDATE forums SET is_deleted = '1' WHERE id = %d";
    db_query($query, $forum_id);
}