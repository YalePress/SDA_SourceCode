<?php

function show_my_research_list() {
    global $user;
    $showType = $_GET['showType'];
    $order = $_GET['order'];
    $sortBy = $_GET['sortBy'];

    if (empty($showType)) {
        $showType = 'my';
    }
    if (empty($sortBy)) {
        if ($showType == 'my'/* || $showType == 'pg'*/) {
            $sortBy = 'join_date';
        } else {
            $sortBy = 'creation_date';
        }
    }
    if (empty($order)) $order = 'DESC';

    //if ($showType != 'pg') {
        $out = '<div class="cell_title"><div id="results_title">Research Interests</div></div>';
        $out .= '<div class="research_interests_second_line">';
            $out .= '<select id="select_type" class="show_type_dropdown" onchange="show_my_research_list(document.getElementById(\'select_type\').value, \'' . $sortBy . '\', \'desc\');">';
            $out .= '<option value="my">My Research Interests</option>';
            $out .= '<option value="all"';
            if ($showType == 'all') {
                $out .= ' selected="selected"';
            }
            $out .= '>All Research Interests</option>';
            $out .= '</select>';

        if (user_access('Create Research Interest')) {
            $out .= create_new_research_interest_popup($showType, $sortBy, $order);
            $out .= '<input type="button" class="create_new_ri_button" value="Create New Research Interest" onclick="show_popup(\'create_new_research_interest\');" />';
        }
        $out .= '</div>';
    /*} else {
        $out = '<div class="cell_title">
            <div id="results_title">Private Groups</div>' .
            create_new_research_interest_popup($showType, $sortBy, $order) .
            '<input type="button" class="create_new_pg_button" value="Create New Private Group" onclick="show_popup(\'create_new_research_interest\');" />
        </div>';
    }*/
    if ($showType == 'all') {
        $query = "SELECT ri.id, ri.name, ri.creation_date,
            (select count(*) from research_interests_users where research_interest_id = ri.id) as members_count,
            (select count(*) from research_interests_users where research_interest_id = ri.id and user_id = {$user->uid}) as status
            FROM research_interests ri" . /*WHERE ri.type = 0*/ " ORDER BY {$sortBy} {$order}";
    } else if ($showType == 'my') {
        $query = "SELECT ri.id, ri.name,
            (select count(*) from research_interests_users where research_interest_id = ri.id) as members_count,
            riu.join_date, '1' as status
            FROM research_interests_users riu
            JOIN research_interests ri ON ri.id = riu.research_interest_id
            WHERE riu.user_id = {$user->uid}" . /*AND ri.type = 0*/ " ORDER BY {$sortBy} {$order}";
    }/* else {
        $query = "SELECT id, name, members_count, status, join_date FROM
                  (
                  SELECT ri.id, ri.name, '2' as status, ri.creation_date as join_date,
                  (select count(*) from research_interests_users where research_interest_id = ri.id) as members_count
                  FROM research_interests ri
                  WHERE ri.creator_id = {$user->uid} AND ri.type = 1

                  UNION SELECT ri.id, ri.name, '1' as status, riu.join_date,
                  (select count(*) from research_interests_users where research_interest_id = ri.id) as members_count
                  FROM research_interests ri
                  JOIN research_interests_users riu ON riu.research_interest_id = ri.id
                  WHERE riu.user_id = {$user->uid} AND ri.type = 1 AND ri.creator_id != {$user->uid}
                  ) result
                  ORDER BY {$sortBy} {$order}
                  ";
    }*/

    $results = db_query($query);
    $researchInterests = array();
    while ($result = db_fetch_array($results)) {
        $researchInterests[] = $result;
    }

    $out .= create_my_research_list($researchInterests, $showType, $sortBy, $order);

    echo $out;
}

function create_new_research_interest_popup($showType, $sortBy, $order) {
    $out = '<div class="hidden" id="popup_create_new_research_interest">';
    $out .= '<div class="popup_header">';
    $out .= 'Create New ' . /*($showType == 'pg' ? 'Private Group' :*/ 'Research Interest'/*)*/;
    $out .= '<img alt="Close" src="' . base_path() . 'sites/all/themes/stalin/images/cross_close.png">';
    $out .= '</div>';
    $out .= '<div class="popup_body">';
    $out .= '<b>Group Name:</b><p/>';
    $out .= '<input type="text" style="width:160px" id="riName" /><p/>';
    $out .= '<p/>';
    $out .= '<b>Description:</b><p/>';
    $out .= '<textarea cols="40" rows="10" id="riDescription" />';
    $out .= '<p/>';
    /*if ($showType == 'pg') {
        $out .= '<input type="checkbox" id="is_content_editable" /> Allow members to edit private group folder content.<p/>';
    }*/
    //if ($showType == 'pg') {
    //    $out .= '<input type="button" class="popup_button" value="Create Group" onClick="create_research_interest(document.getElementById(\'riName\').value, document.getElementById(\'riDescription\').value, \'' . $showType . '\', \'' . $sortBy . '\', \'' . $order . '\', document.getElementById(\'is_content_editable\').checked); closePopup();" />';
    //} else {
        $out .= '<input type="button" class="popup_button" value="Create Group" onClick="create_research_interest(document.getElementById(\'riName\').value, document.getElementById(\'riDescription\').value, \'' . $showType . '\', \'' . $sortBy . '\', \'' . $order . '\'); closePopup();" />';
    //}
    $out .= '<input type="button" class="popup_button" value="Cancel" onClick="closePopup()"/>';
    $out .= '</div>';
    $out .= '</div>';

    return $out;
}

function create_join_research_interest_popup($riId, $riName, $showType, $sortBy, $order) {
    $out = '<div class="hidden" id="popup_join_research_interest_' . $riId . '">';
    $out .= '<div class="popup_header">';
    $out .= 'Join Research Interest Group';
    $out .= '<img alt="Close" src="' . base_path() . 'sites/all/themes/stalin/images/cross_close.png">';
    $out .= '</div>';
    $out .= '<div class="popup_body">';
    $out .= '<b>' . $riName . '</b><p/>';
    $out .= 'Are you sure you want to join this Research Interest Group?';
    $out .= '<p/>';
    $out .= '<div style="align:right">';
    $out .= '<input type="button" class="popup_button" value="Join" onClick="join_research_interest(' . $riId . ',\'' . $showType . '\',\'' . $sortBy . '\',\'' . $order . '\'); closePopup();" />';
    $out .= '<input type="button" class="popup_button" value="Cancel" onClick="closePopup()"/>';
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';

    return $out;
}

function create_my_research_list($researchInterests, $showType, $sortBy, $order) {
    $out = '<div>';

    $out .= '<table id="my_ri_list" cellpadding="0" cellspacing="0" border="0" width="100%" class="my_sda_result">';
    $out .= '<thead>';
    $out .= '<tr class="header">';
    $out .= '<th class="name" style="width:40%"><div class="resize">' . /*($showType == 'pg' ? 'PRIVATE GROUP' :*/ 'RESEARCH INTEREST'/*)*/ . '<a class="' . $showType . '_research_interests" href="name"></a><div class="va_middle"></div></div></td>';
    $out .= '<th class="members_count"><div class="resize">' . t('MEMBERS') . '<a class="' . $showType . '_research_interests" href="members_count"></a><div class="va_middle"></div></div></td>';
    $out .= '<th class="status"><div class="resize">' . t('STATUS') . '<a class="' . $showType . '_research_interests" href="status"></a><div class="va_middle"></div></div></td>';
    $out .= '<th class="not_sortable"><div class="resize"><span style="color:black">' . t('OPTIONS') . '</span><div class="va_middle"></div></div></td>';
    if ($showType == 'my'/* || $showType == 'pg'*/) {
        $out .= '<th class="join_date"><div class="resize">' . t('JOINED ON') . '<a class="' . $showType . '_research_interests" href="join_date"></a><div class="va_middle"></div></div></td>';
    } else {
        $out .= '<th class="creation_date"><div class="resize">' . t('CREATED ON') . '<a class="' . $showType . '_research_interests" href="creation_date"></a><div class="va_middle"></div></div></td>';
    }
    $out .= '<th class="hidden ri_id"></th>';
    $out .= '</tr>';
    $out .= '</thead>';
    $out .= '<tbody>';

    foreach ($researchInterests as $researchInterest) {
        $out .= '<tr style="height:40px">';

        $out .= '<td style="width:40%" class="ri_title">';
        $out .= '<a href="#page=ri&id=' . $researchInterest['id'] . '">' . $researchInterest['name'] . '</a>';
        if (user_access('Delete Research Interest')/* && $showType != 'pg'*/) {
            $out .= '<img style="padding-left: 10px; cursor: pointer" src="' . base_path() . 'sites/all/themes/stalin/images/cross_close.png" onclick="delete_research_interest(' . $researchInterest['id'] . ',\'' . $showType . '\',\'' . $sortBy . '\',\'' . $order . '\');" />';
        }
        $out .= '</td>';

        $out .= '<td class="ri_members_count">';
        $out .= $researchInterest['members_count'];
        $out .= '</td>';

        if ($showType == 'all') {
            if ($researchInterest['status'] != '0') {
                $out .= '<td class="ri_status">';
                $out .= 'Member';
                $out .= '</td>';

                $out .= '<td class="ri_options">';
                $out .= '<a href="#" onclick="leave_research_interest(' . $researchInterest['id'] . ',\'' . $showType . '\',\'' . $sortBy . '\',\'' . $order . '\'); return false;">Leave group</a>';
                $out .= '</td>';
            } else {
                $out .= '<td class="ri_status">';
                $out .= 'Non-Member';
                $out .= '</td>';

                $out .= '<td class="ri_options">';
                $out .= create_join_research_interest_popup($researchInterest['id'], $researchInterest['name'], $showType, $sortBy, $order);
                $out .= '<input type="button" class="join_button" value="Join" onclick="show_popup(\'join_research_interest_' . $researchInterest['id'] . '\')" />';
                $out .= '</td>';
            }
            $out .= '<td class="ri_created_on">';
            $out .= mysda_format_date($researchInterest['creation_date']);
            $out .= '</td>';
        } else if ($showType == 'my') {
            $out .= '<td class="ri_status">';
            $out .= 'Member';
            $out .= '</td>';

            $out .= '<td class="ri_options">';
            $out .= '<a href="#" onclick="leave_research_interest(' . $researchInterest['id'] . ',\'' . $showType . '\',\'' . $sortBy . '\',\'' . $order . '\');">Leave group</a>';
            $out .= '</td>';

            $out .= '<td class="ri_joined_on">';
            $out .= mysda_format_date($researchInterest['join_date']);
            $out .= '</td>';
        }/* else {
            if ($researchInterest['status'] == '1') {
                $out .= '<td class="ri_status">';
                $out .= 'Member';
                $out .= '</td>';

                $out .= '<td class="ri_options">';
                $out .= '<a href="#" onclick="leave_research_interest(' . $researchInterest['id'] . ',\'' . $showType . '\',\'' . $sortBy . '\',\'' . $order . '\'); return false;">Leave group</a>';
                $out .= '</td>';
            } else {
                $out .= '<td class="ri_status">';
                $out .= 'Owner';
                $out .= '</td>';

                $out .= '<td class="ri_options">';
                $out .= '<a href="#" onclick="delete_research_interest(' . $researchInterest['id'] . ',\'' . $showType . '\',\'' . $sortBy . '\',\'' . $order . '\'); return false;">Remove group</a>';
                $out .= '</td>';
            }
            $out .= '<td class="ri_joined_on">';
            $out .= mysda_format_date($researchInterest['join_date']);
            $out .= '</td>';
        }*/

        $out .= '</tr>';
    }
    $out .= '</tbody>';
    $out .= '</table>';
    $out .= '</div>';

    return $out;
}

function join_research_interest() {
    $riId = $_GET['riId'];
    join_research_interest_inner($riId);
}

function join_research_interest_inner($riId) {
    global $user;

    $result = db_fetch_array(db_query("SELECT * FROM research_interests_users WHERE research_interest_id = %d AND user_id = %d", $riId, $user->uid));
    if (!empty($result)) {
        // User is already a member of this RI.
        exit();
    }

    $current_date = db_now();
    $query = "INSERT INTO research_interests_users (research_interest_id, user_id, join_date)";
    $query .= " VALUES ({$riId}, {$user->uid}, '$current_date')";

    db_query($query);
}

function leave_research_interest() {
    $riId = $_GET['riId'];
    global $user;

    $query = "DELETE FROM research_interests_users WHERE research_interest_id = {$riId} and user_id = {$user->uid}";

    db_query($query);
}

function create_research_interest() {
    global $user;
    $name = $_GET['name'];
    $description = $_GET['description'];
    $type = $_GET['groupType'];
    //$is_content_editable = $_GET['isContentEditable'];

    $current_date = db_now();

    // Create research interest.
    $query = "INSERT INTO research_interests (name, description, creation_date, creator_id" . /*, type*/ ")" .
             " VALUES ('{$name}', '{$description}', '$current_date', {$user->uid}" . /*, $type*/ ")";

    db_query($query);

    // Create forum.
    $riId = db_last_insert_id('research_interests', 'id');
    $query = "INSERT INTO forums (research_interest_id, name, description, creator_id, creation_date)" .
             " VALUES ({$riId}, '{$name}', '{$description}', {$user->uid}, '$current_date')";
    db_query($query);

    // Create RI folder.
    $query = "INSERT INTO folders (name, description, research_interest_id, creation_date" . /*, is_content_editable*/ ")" .
             " VALUES ('{$name}', '{$description}', {$riId}, '$current_date'" . /*, {$is_content_editable}*/ ")";
    db_query($query);

    // Join group in case of private group.
    if ($type == 1) {
        $current_date = db_now();
        $query = "INSERT INTO research_interests_users (research_interest_id, user_id, join_date)" .
                 " VALUES ({$riId}, {$user->uid}, '$current_date')";
        db_query($query);
    }
}

function delete_research_interest() {
    $riId = $_GET['riId'];

    // Delete research interest.
    $query = "DELETE FROM research_interests_users WHERE research_interest_id = {$riId}";
    db_query($query);
    $query = "DELETE FROM research_interests WHERE id = {$riId}";
    db_query($query);

    // Delete forums.
    $query = "UPDATE forum_topics SET is_deleted = '1' WHERE forum_id IN (SELECT id FROM forums WHERE research_interest_id = {$riId})";
    db_query($query);
    $query = "UPDATE forums SET is_deleted = '1' WHERE research_interest_id = {$riId}";
    db_query($query);

    // Delete RI folders.
    $query = "DELETE FROM documents_folders WHERE folder_id IN (SELECT id FROM folders WHERE research_interest_id = {$riId})";
    db_query($query);
    $query = "DELETE FROM folders WHERE research_interest_id = {$riId}";
    db_query($query);
}