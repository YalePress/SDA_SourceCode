<?php
$type = param($type, 'type', PARAM_STRING, false);
$folders = param($folders, 'folders', PARAM_ARRAY);

if ($type == FOLDER_TYPE_PERSONAL) {
    $cell_title = 'Personal Folders';
} else if ($type == FOLDER_TYPE_RI) {
    $cell_title = 'Public Folders';
}/* else {
    $cell_title = 'Private Folders';
}*/

$can_edit = ($type == FOLDER_TYPE_PERSONAL);

global $base_url;
?>

<?php
    display_errors();
?>

<input type="hidden" id="folder_type" value="<?php echo $type ?>">
<input type="hidden" id="sort_by" value="<?php echo $_POST['sort_by'] ?>">
<input type="hidden" id="order" value="<?php echo $_POST['order'] ?>">

<!--popups-->
<?php echo html_for_popup(
    'my_sda_folder_remove',
    t('Remove Folder'),
    null,
    '<b>' . '<span id="folder_name">{{folder_name}}</span>' . '</b><br><br>Are you sure you want to remove <span id="this_folder">this folder</span> and all of its contents from your library?',
    null, null,
    array(
         array(
             'id' => "remove_btn",
             'text' => 'Remove'
         )
    )
) ?>

<?php echo html_for_popup(
    'my_sda_folder_create',
    '{{title}}',
    null, null,
    'create_new_folder_form',
    null,
    array(
         array(
             'id' => 'create_apply',
             'text' => '{{create_apply}}'
         )
    )
) ?>

<?php echo hidden_divs_for_export_popup(); ?>
<?php echo prepare_hidden_ann_form(); ?>

<!--end popups-->

<div class="cell_title">
    <div id="results_title">
        <?php echo $cell_title ?>
    </div>
</div>

<div class="folders_buttons results_filter">
    <?php ;

    echo tpl('sda_library', 'select_all_control');

    if ($can_edit) {
        echo button_link(array('text' => 'Remove',
                              'onclick' => "show_remove_folder_popup(); return false;"));
    } ?>

    <?php echo button_link(array('text' => 'Export Citation',
                                'onclick' => "show_create_export_form_popup('folder'); return false;")) ?>

    <?php echo button_link(array('text' => 'Export Annotation',
                                'onclick' => "show_export_form_popup('folder', 'export_annotation_form'); return false;")) ?>
    <?php ;

    if ($can_edit) {
        echo button_link(array('text' => 'Create New Folder',
                              'onclick' => "show_create_edit_folder_popup('create'); return false;"));
    } ?>
</div>

<div class="folders_list">
    <table class="my_sda_result">
        <tr class="header">
            <th class="checkbox_cell">
                <div class=""></div>
            </th>
            <th class="type_folders sort_by_name">
                <div class="resize">FOLDER
                    <div class="va_middle"></div>
                </div>
            </th>
            <th class="type_folders sort_by_doc_number">
                <div class="resize">DOCUMENTS
                    <div class="va_middle"></div>
                </div>
            </th>
            <th class="type_folders not_sortable">
                <div class="resize">DESCRIPTION
                    <div class="va_middle"></div>
                </div>
            </th>
            <th class="type_folders sort_by_created">
                <div class="resize">CREATED
                    <div class="va_middle"></div>
                </div>
            </th>
            <th class="type_folders sort_by_last_updated">
                <div class="resize">LAST UPDATED
                    <div class="va_middle"></div>
                </div>
            </th>
        </tr>
        <?php foreach ($folders as $folder): ?>
        <tr id="folder_<?php echo $folder['id'] ?>">
              <td>
                <input type="checkbox" class="check_one" value="<?php echo $folder['id'] ?>" name="row_check"/>
                <?php if ($can_edit): ?>
                <?php echo button_link(array('text' => 'Edit',
                                            'onclick' => "return show_create_edit_folder_popup('edit', '{$folder['id']}');")) ?>
                <?php endif; ?>
            </td>
            <td><a href="#page=folder&id=<?php echo $folder['id'] ?>">
                <img width="16" height="14" alt=""
                     src="<?php echo $base_url ?>/sites/all/themes/stalin/images/folder_icon.png"/>
                <span class="name"><?php echo htmlspecialchars($folder['name']) ?></span>
            </a></td>
            <td>
                <?php echo $folder['doc_number'] ?>
                <div style="display:none" id="docs_<?php echo $folder['id'] ?>"><?php echo get_document_ids_for_folder($folder['id']) ?></div>
            </td>
            <td>
                <span class="description"><?php echo htmlspecialchars($folder['description']) ?></span>
            </td>
            <td><?php echo $folder['created'] ?></td>
            <td><?php echo $folder['last_updated'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>