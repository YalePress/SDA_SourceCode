<?php

$notifications = param($notifications, 'notifications', PARAM_ARRAY);

?>

<div class="cell_title">
    <div id="results_title">Notifications</div>
</div>

<?php if ($notifications): ?>
    <table id="notifications_list" cellpadding="0" cellspacing="0" border="0" width="100%">
    <?php foreach ($notifications as $notification): ?>
        <tr class="notification">
            <td class="notification">
                <div class="notification_date">
                    <?php echo mysda_notification_format_date($notification['creation_date']) ?>
                </div>
                <div class="notification_text">
                    <?php echo get_notification_text_html($notification); ?>
                </div>
            </td>
            <td class="notification_delete">
                <input type="button" class="notification_delete_button" value="Delete"
                       onclick="delete_notification(<?php echo $notification['id'] ?>)"/>
            </td>
        </tr>
    <?php endforeach; ?>
<?php else: ?>
You don't have any Notifications.
<?php endif; ?>
