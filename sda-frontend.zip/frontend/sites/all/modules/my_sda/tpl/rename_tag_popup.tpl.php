<div class="popup_rename_tag hidden" id="popup_rename_tag">
    <div class="popup_header"><?= t('Rename Tag') ?>
        <img alt="Close" src="<?= base_path() ?>sites/all/themes/stalin/images/cross_close.png"></div>
    <div class="popup_body">
        <div>
            <label for="tag_id">Select Tag:</label>
            <select id="tag_id">
                <? foreach ($tags as $tag) { ?>
                <option value="<?= $tag['name'] ?>"><?= $tag['name'] ?></option>
                <? } ?>
            </select>
        </div>
        <div>
            <label for="new_tag_name">New Name:</label>
            <input type="text" name="new_tag_name" id="new_tag_name"/>
        </div>
        <div>
            <input type="button" onclick="closePopup();" value="Cancel">
            <input type="button" onclick="rename_tag();" value="Apply">
        </div>
    </div>
</div>
