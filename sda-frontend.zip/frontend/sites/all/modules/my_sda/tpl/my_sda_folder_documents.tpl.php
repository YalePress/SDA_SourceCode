<?php
$folder = param($folder, 'folder', PARAM_UNKNOWN, false); // folder obj
$documents = param($documents, 'documents', PARAM_ARRAY);
$owner_mode = param($owner_mode, 'owner_mode', PARAM_BOOL, false);
$sort_by = param($sort_by, 'sort_by', PARAM_UNKNOWN);
$user_folders = param($user_folders, 'user_folders', PARAM_ARRAY);
$ri_folders = param($ri_folders, 'ri_folders', PARAM_ARRAY);
$private_folders = param($private_folders, 'private_folders', PARAM_ARRAY);

$can_remove_documents = empty($folder['research_interest_id']) || // User can remove docs from his personal folder
            user_access('Delete Documents from RI Folder');    // Check permission to delete from RI folder
            //(/*$folder['type'] == 0 &&*/ user_access('Delete Documents from RI Folder'))/* || // Only admins can remove docs from research interest folder
            //($folder['type'] == 1 && $folder['is_content_editable' == 1]) || // Members can remove docs from private group folder with editable content
            //($folder['type'] == 1 && $folder['is_content_editable' == 0] && $owner_mode)*/; // Only owner can remove docs from private folder with disallowed content editing.
global $base_url;
global $user;
?>

<?php
    display_errors();
?>

<input type="hidden" id="folder_id" value="<?php echo $folder['id'] ?>">

<!--popups-->
<?php echo html_for_popup(
    'my_sda_folder_document_remove',
    t('Remove Document'),
    null,
    '<b>' . $folder['name'] . '</b><br><br>Are you sure you want to remove these documents from this folder?',
    null, null,
    array(
         array(
             'id' => "remove_btn",
             'text' => 'Remove'
         )
    )
) ?>

<?php echo get_copy_move_popup_html('copy', $folder, $user_folders, $ri_folders/*, $private_folders*/) ?>
<?php echo get_copy_move_popup_html('move', $folder, $user_folders, $ri_folders/*, $private_folders*/) ?>

<?php echo hidden_divs_for_export_popup(); ?>
<?php echo prepare_hidden_ann_form(); ?>
<!--end popups-->

<div class="folder_desc">
    <img width="16" height="14" alt=""
         src="<?php echo $base_url ?>/sites/all/themes/stalin/images/folder_icon.png"/>
    <b>Folder <?php echo $folder['name'] ?></b>
    <br/>
    <?php //if (user_access('Edit Name/Description of RI')) {
        if (is_admin()) {
        echo '<textarea style="display: none" id="folder_desc_edit" rows="2" cols="120"></textarea>
            <br/>
            <a href="#" id="lnk_edit_desc" onclick="edit_folder_description(this, true); return false;">Edit Description</a>
            <a href="#" id="lnk_save_desc" onclick="edit_folder_description(this, false); return false;" style="display: none">Save Description</a>';
    } ?>
    <p/>
</div>

<div class="folders_buttons results_filter">
    <?php ;

    echo tpl('sda_library', 'select_all_control');

    if ($can_remove_documents) {
        echo button_link(array('text' => 'Remove',
                              'onclick' => "show_remove_folder_document_popup(); return false;"));
    } ?>

    <?php ;
    if ($can_remove_documents) {
        echo(button_link(array('text' => 'Move To Folder',
                          'onclick' => "show_popup('move_document_to_folder'); return false;")));
    }
    echo(button_link(array('text' => 'Copy To Folder',
                          'onclick' => "show_popup('copy_document_to_folder'); return false;")));
    ?>

    <?php ;
    echo button_link(array('text' => 'Export Citation',
                          'onclick' => "show_create_export_form_popup('document'); return false;"));
    ?>
    <?php echo button_link(array('text' => 'Export Annotation',
                                'onclick' => "show_export_form_popup('folder', 'export_annotation_form'); return false;"));
    ?>
    <div class="sort_lists" style="position:relative; float: right">
        <a class="active sort_lists" onclick="show_select_view_options_folder_documents(this);return false;" href="#">View options</a>
        <div class="hidden" id="view_options">
            <?php echo drupal_get_form('select_fields_to_view_form_folder_documents'); ?>
            <hr>
            <a href="#" onclick="apply_view_options_folder_documents();return false;" class="apply button_outer_left"><span class="button_outer_right"><span class="button_outer_center"><span class="button_inner">Apply</span><span class="va_middle"></span></span></span></a>
        </div>

        <a class="active" onclick="show_select_sort_by_folder_documents(this);return false;" href="#">Sort by</a>
        <div id="sort_by" class="hidden">
            <select onclick="hide_select_sort_by_folder_documents();" size="9">
                <?php // TODO: Generate these options. ?>
                <option <?php if($sort_by=="title") echo 'selected="selected"' ?> value="title">Title</option>
                <option <?php if($sort_by=="rating") echo 'selected="selected"' ?> value="rating">Avg. Rating</option>
                <option <?php if($sort_by=="author") echo 'selected="selected"' ?> value="author">Author</option>
                <option <?php if($sort_by=="document_id") echo 'selected="selected"' ?> value="document_id">ID</option>
                <option <?php if($sort_by=="publication_date") echo 'selected="selected"' ?> value="publication_date">Publication Date</option>
                <option <?php if($sort_by=="recipient") echo 'selected="selected"' ?> value="recipient">Recipients</option>
                <option <?php if($sort_by=="relevancy") echo 'selected="selected"' ?> value="relevancy">Relevancy</option>
                <option <?php if($sort_by=="subject") echo 'selected="selected"' ?> value="subject">Subject</option>
                <option <?php if($sort_by=="views_count") echo 'selected="selected"' ?> value="views_count"># of Views</option>
                <option <?php if($sort_by=="save_date") echo 'selected="selected"' ?> value="save_date">Date Saved</option>
            </select>
        </div>
    </div>
</div>

<div class="folder_documents_list">
    <table class="my_sda_result">
        <tr class="header">
            <th class="checkbox_cell">
                <div class=""></div>
            </th>
            <th class="type_files sort_by_title title">
                <div class="resize">TITLE
                    <div class="va_middle"></div>
                </div>
            </th>
            <th class="type_files sort_by_rating rating">
                <div class="resize">AVG. RATING
                    <div class="va_middle"></div>
                </div>
            </th>
            <th class="type_files sort_by_author author">
                <div class="resize">AUTHOR
                    <div class="va_middle"></div>
                </div>
            </th>
            <th class="type_files sort_by_document_id document_id">
                <div class="resize">ID
                    <div class="va_middle"></div>
                </div>
            </th>
            <th class="type_files sort_by_publication_date publication_date">
                <div class="resize">PUBLICATION DATE
                    <div class="va_middle"></div>
                </div>
            </th>
            <th class="type_files sort_by_recipient recipient">
                <div class="resize">RECIPIENTS
                    <div class="va_middle"></div>
                </div>
            </th>
            <th class="type_files sort_by_relevancy relevancy">
                <div class="resize">RELEVANCY
                    <div class="va_middle"></div>
                </div>
            </th>
            <th class="type_files sort_by_subject subject">
                <div class="resize">SUBJECT
                    <div class="va_middle"></div>
                </div>
            </th>
            <th class="type_files sort_by_views_count views_count">
                <div class="resize"># OF VIEWS
                    <div class="va_middle"></div>
                </div>
            </th>
            <th class="type_files sort_by_save_date save_date">
                <div class="resize">DATE SAVED
                    <div class="va_middle"></div>
                </div>
            </th>
        </tr>
        <?php foreach ($documents as $doc): ?>
        <tr id="doc_<?php echo $doc['id'] ?>">
            <td>
                <input type="checkbox" class="check_one" value="<?php echo $doc['id'] ?>" name="row_check"/>
            </td>
            <td class="title"><a href="<?php echo $base_url ?>/sda_viewer?n=<?php echo $doc['id'] ?>">
                <span class="title"><?php echo htmlspecialchars($doc['title']) ?></span>
            </a></td>
            <td class="rating"><?php echo $doc['rating'] ?></td>
            <td class="author"><span class="author"><?php echo nl2br($doc['author']) ?></span></td>
            <td class="document_id"><?php echo $doc['document_id'] ?></td>
            <td class="publication_date">
                <span class="publication_date"><?php echo $doc['publication_date'] ?></span>
            </td>
            <td class="recipient"><?php echo $doc['recipient'] ?></td>
            <td class="relevancy"><?php echo $doc['relevancy'] ?></td>
            <td class="subject"><?php echo $doc['subject'] ?></td>
            <td class="views_count"><?php echo $doc['views_count'] ?></td>
            <td class="save_date"><?php echo $doc['save_date'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>