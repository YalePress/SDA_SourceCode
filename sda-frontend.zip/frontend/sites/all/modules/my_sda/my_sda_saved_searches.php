<?php

function show_my_saved_searches() {
    $sort_by = $_POST['sort_by'];
    $order = $_POST['order'];
    if (empty($sort_by)) $sort_by = 'search_date';
    if (empty($order)) $order = 'desc';

    global $user;
    global $base_url;
    $out = '<div class="cell_title">
            <div id="results_title">Saved Searches</div>
    </div>';
    $out .= '<div class="results_filter">
                <a class="button_outer_left">
                    <span class="button_outer_right">
                    <span class="button_outer_center">
                    <span class="button_inner">
                        <input class="check_all" type="checkbox" name="empty">
                        <img class="arrow_down" alt="" src="'.$base_url.'/sites/all/themes/stalin/images/arrow_down.png" onclick="show_select_check_all()">
                    </span>
                        <span class="va_middle"></span>
                    </span>
                    </span>
                </a>
                <div style="position:relative;float:left">
                    <div id="select_check_all" class="hidden">
                        <div class="select_item select_all">Select All</div>
                        <div class="select_item clear_all">Clear All</div>
                    </div>
                </div>
                <a class="button_outer_left" onclick="delete_checked_saved_searches();return false;" href="#">
                    <span class="button_outer_right"><span class="button_outer_center">
                    <span class="button_inner button_text">Remove</span>
                    <span class="va_middle"></span>
                    </span></span>
                </a>
            </div>';
    $out .= '<div id="searches_list">';
    $searches=db_query("
        SELECT search_header,search_id,search_date, search_title
        FROM user_saved_searches
        WHERE user_id='{$user->uid}'
        ORDER BY {$sort_by} {$order}
    ");
    $out .= '<table cellpadding="0" cellspacing="0" border="0" class="my_sda_result">';
    $out .= '<thead>
                <tr class="header">
                    <th class="checkbox_cell search not_sortable"><div class="resize"><div class="va_middle"></div></div></th>
                    <th class="search_title"><div class="resize">SEARCH NAME<a class="s_searches" href="search_title"></a><div class="va_middle"></div></div></th>
                    <th class="search_header"><div class="resize">SEARCH CRITERIA<a class="s_searches" href="search_header"></a><div class="va_middle"></div></div></th>
                    <th class="search_date"><div class="resize">LAST SEARCHED<a class="s_searches" href="search_date"></a><div class="va_middle"></div></div></th>
                </tr>
             </thead>
             <tbody>';

    while($search = db_fetch_array($searches)) {
        $out .= '<tr>';
        $out .= '<td><input type="checkbox" value="'.$search['search_id'].'" class="check_one" name="remove_search" id="ch_'.$search['search_id'].'"/>';
        $out .= '<td class="title" id="t_'.$search['search_id'].'">';
        if (strlen($search['search_title']) > 0) {
            $out .= '<span id="search_title_span_'.$search['search_id'].'" ondblclick="show_rename_saved_search('.$search['search_id'].');">' . $search['search_title'] . '</span>';
            $out .= '<input type="text" style="display:none" id="search_title_input_'.$search['search_id'].'" value="'.$search['search_title'].'" onkeydown="if (event.keyCode == 13) rename_saved_search('.$search['search_id'].', this.value);" onblur="rename_saved_search('.$search['search_id'].', this.value);"></input>';
            $out .= '<input type="button" style="display:none" id="search_title_button_'.$search['search_id'].'" value="Create" onclick="show_create_saved_search_name('.$search['search_id'].')"></input>';
        } else {
            $out .= '<span style="display:none" id="search_title_span_'.$search['search_id'].'" ondblclick="show_rename_saved_search('.$search['search_id'].');">' . $search['search_title'] . '</span>';
            $out .= '<input type="text" style="display:none" id="search_title_input_'.$search['search_id'].'" value="'.$search['search_title'].'" onkeydown="if (event.keyCode == 13) rename_saved_search('.$search['search_id'].', this.value);" onblur="rename_saved_search('.$search['search_id'].', this.value);"></input>';
            $out .= '<input type="button" id="search_title_button_'.$search['search_id'].'" value="Create" onclick="show_create_saved_search_name('.$search['search_id'].')"></input>';
        }
        $out .= '</td>';
        $out .= '<td class="search"><a href="#page=s_searches&id='.$search['search_id'].'">'.$search['search_header'].'</a></td>';
        $out .= '<td class="last_searched">'.mysda_format_date($search['search_date']).'</td>';
        $out .= '</tr>';
    }
    $out .= '</tbody></table>';
    $out .= '</div>';

    echo $out;
}

function rename_saved_search() {
    $search_id=$_POST['search_id'];
    $search_name=mysql_escape_string(strip_tags($_POST['search_name']));
    $query="UPDATE user_saved_searches SET search_title='{$search_name}' WHERE search_id='{$search_id}'";
    db_query($query);
    echo $search_name;
}

function remove_checked_saved_searches() {
    $post_saved_searches = $_POST['check_arr'];
    if (count($post_saved_searches) > 1){
    $saved_searches = implode(', ',$post_saved_searches);
    }
    else $saved_searches = $post_saved_searches[0];
    $query = "DELETE FROM user_saved_searches WHERE search_id IN ({$saved_searches})";
    $result = db_query($query);

    echo $result;
}
