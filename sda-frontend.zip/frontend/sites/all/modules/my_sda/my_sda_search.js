$(document).ready(function () {
    var content_table = $('.content_table');
    if (content_table.length) {
        content_table.delegate('.check_all', 'change', function () {
            if ($(this).is(':checked')) {
                // $(this).parent().parent().find('.form-item:not(:hidden) input').attr('checked','checked')
                $('.check_one').attr('checked', 'checked');
            } else {
                //$(this).parent().parent().find('input').removeAttr('checked')
                $('.check_one').removeAttr('checked');
            }
        });

        $('.center_column').delegate('div.select_item', 'click', function () {
            if ($(this).is('.select_all')) {
                $("table.my_sda_result input[type='checkbox']").attr('checked', true);
                $("div.save_checkbox input").attr('checked', true)
            } else if ($(this).is('.clear_all')) {
                $("table.my_sda_result input[type='checkbox']").attr('checked', false);
                $("div.save_checkbox input").attr('checked', false)
            }
        });

        content_table.delegate('th:not(.checkbox_cell, .not_sortable)', 'click', function () {
            var order;

            var this_th = $(this);

            if (!this_th.hasClass('sorted')) {
                order = 'asc'
            } else {
                if (this_th.hasClass('reversed')) {
                    order = 'asc';
                } else {
                    order = 'desc';
                }
            }

            var sort_by = this_th.find('a').attr('href') || get_from_class(this_th, 'sort_by');
            var type = this_th.find('a').attr('class') || get_from_class(this_th, 'type');
            //alert(sort_by);

            sort_table_results(sort_by, order, type);
        });

        content_table.delegate('.btn_start_topic input', 'click', function () {
            var forum_id = $("#forum_id").html();
            window.location = '#page=discussions&forum=' + forum_id + '&act=start_topic';
            return false;
        });

        content_table.delegate('input[name="normal_or_sticky"]', 'change', function () {
            if ($('#sticky').attr('checked') == 'checked') {
                $('#prevent_replies').show();
            }
            else {
                $('#prevent_replies').hide();
                $('#prevent').removeAttr('checked');
            }
        });

        $('#popup').delegate('#folder', 'change', function (data) {
            var folder_id = $('#folder').val();
            $.post('echo_list_to_folder', {folder_id:folder_id}, function (data) {
                $('#document_select').html(data);
            })
        })
    }

    content_table.delegate('#sda_tags input:radio[name="list_or_snippets"]', 'change', function () {
        apply_view_options_tags_documents();
    });

    content_table.delegate('#sda_tags .check_all', 'change', function () {
//        console.info('change');
        var checked = $(this).is(":checked");
        $("table.my_sda_result input[type='checkbox']").attr('checked', checked);
        $("div.save_checkbox input").attr('checked', checked);
        return false;
    });
});

function show_my_sda_annotations(sort_by, order) {
    $.post("echo_my_annotations", {sort_by:sort_by, order:order}, function (data) {
        $('#my_sda_docs').html(data);

        make_resizable(".my_sda_result th div.resize");

        if (sort_by != '') $('.my_sda_result th.' + sort_by).addClass('sorted');
        if (order == 'desc') $('.my_sda_result th.' + sort_by).addClass('reversed')
    });
}

function get_checked_ids() {
    var checked = [];
    $(".my_sda_result").find("tbody input:checked").each(function (id) {
        checked.push($(this).attr('value'));
    });
    return checked;
}

function delete_checked_annotations() {
    var check_arr = get_checked_ids();
    if (check_arr.length) {
        $.post('remove_checked_annotations', {check_arr:check_arr}, function (data) {
            if (data) {
                for (var key in check_arr) {
                    var check = check_arr[key];
                    $(".my_sda_result").find(".check_one[value='" + check + "']").parent().parent().hide();
                }
            }
        })
    } else {
        alert('You haven\'t checked any annotations.');
    }
}

function delete_checked_saved_searches() {
    var check_arr = get_checked_ids();
    if (check_arr.length) {
        $.post('remove_checked_saved_searches', {check_arr:check_arr}, function (data) {
            if (data) {
                for (var key in check_arr) {
                    var check = check_arr[key];
                    $(".my_sda_result").find(".check_one[value='" + check + "']").parent().parent().hide();
                }
            }
        })
    } else {
        alert('You haven\'t checked any saved searches.');
    }
}

function show_create_saved_search_name(search_id) {
    $("#search_title_input_" + search_id).show();
    $("#search_title_button_" + search_id).hide();
    $("#search_title_input_" + search_id).focus();
}

function show_rename_saved_search(search_id) {
    $("#search_title_input_" + search_id).show();
    $("#search_title_span_" + search_id).hide();
    $("#search_title_input_" + search_id).focus();
}

function rename_saved_search(search_id, search_name) {
    $.post("rename_saved_search", {search_id:search_id, search_name:search_name}, function (data) {
        $("#search_title_span_" + search_id).html(search_name);
        if (search_name.length == 0) {
            $("#search_title_input_" + search_id).hide();
            $("#search_title_button_" + search_id).show();
        } else {
            $("#search_title_input_" + search_id).hide();
            $("#search_title_span_" + search_id).show();
        }
    })
}

function sort_table_results(sort_by, order, type) {
    if (type == 'my_research_interests') {
        show_my_research_list('my', sort_by, order);

    } else if (type == 'all_research_interests') {
        show_my_research_list('all', sort_by, order);
    } else if (type == 'pg_research_interests') {
        show_my_research_list('pg', sort_by, order);
    } else if (type == 'annotations') {
        show_my_sda_annotations(sort_by, order);
    } else if (type == 'discussions') {
        var id = $("#forum_id").html();
        open_forum(id, sort_by, order)

    } else if (type == 's_searches') {
        show_my_saved_searches(sort_by, order);

    } else if (type == 'folders') {
        show_folders($('#folder_type').val(), sort_by, order);
    } else if (type == 'files') {
        show_folder_documents($('#folder_id').val(), sort_by, order);
        apply_view_options_folder_documents();
    } else if (type == 'tags_documents') {
        var tagstr = $('#str_tags').text();
        show_docs_for_tagstr(tagstr, sort_by, order);
    }
}

function show_all_discussions() {
    $.get('echo_all_discussion_home', function (data) {
        $('#my_sda_docs').html(data);
        var forums_count = $("#recent_forums_carousel ul").children().length;
        var topics_count = $("#recent_topics_carousel ul").children().length;
        var height = 500;

        var forums_visible_count = 0;
        var forums_height = 0;
        var topics_visible_count = 0;
        var topics_height = 0;
        $("#recent_forums_carousel ul").children().each(function () {
            forums_height += $(this).outerHeight();
            if (forums_height > height) {
                return;
            }
            forums_visible_count++;
        });

        $("#recent_topics_carousel ul").children().each(function () {
            topics_height += $(this).outerHeight();
            if (topics_height > height) {
                return;
            }
            topics_visible_count++;
        });


        if (topics_visible_count < topics_count) {
            if ($("#recent_topics_carousel").length) {
                $("#recent_topics_carousel").jCarouselLite({
                    btnNext:".recent_topics_carousel .scroll_down",
                    btnPrev:".recent_topics_carousel .scroll_up",
                    vertical:true,
                    circular:false,
                    visible:topics_visible_count,
                    speed:400,
                    start:0
                });
            }
        } else {
            $(".controls.recent_topics_carousel").addClass("hidden")
        }

        if (forums_visible_count < forums_count) {
            if ($("#recent_forums_carousel").length) {
                $("#recent_forums_carousel").jCarouselLite({
                    btnNext:".recent_forums_carousel .scroll_down",
                    btnPrev:".recent_forums_carousel .scroll_up",
                    vertical:true,
                    circular:false,
                    visible:forums_visible_count,
                    speed:400,
                    start:0
                });
            }
        } else {
            $(".controls.recent_forums_carousel").addClass("hidden")
        }
    })
}

function open_forum(id, sort_by, order, page) {
//    console.info('open_forum', arguments);
    $.post('open_forum_discussions',
        {
            id:id,
            sort_by:sort_by,
            order:order,
            page:page
        },
        function (data) {
            $('#my_sda_docs').html(data);
            make_resizable('.my_sda_result th div.resize');

            if (sort_by) {
                var th_sorted = $('.my_sda_result th.' + sort_by);
                th_sorted.addClass('sorted');
                if (order == 'desc') {
                    th_sorted.addClass('reversed');
                }
            }
        }
    )
}

function show_prew_user_info_popup(user_id) {
    $.post('create_prew_user_info_popup', {user_id:user_id}, function (data) {
        $('#popup_user_info').html(data);
        show_popup('user_info');
    })
}

function show_delete_forum_topic_popup(topic_id, topic_title) {
    $.post('create_delete_forum_topic_popup',
        {
            topic_id:topic_id,
            topic_title:topic_title
        },
        function (data) {
            $('#popup_delete_forum_topic').html(data);
            show_popup('delete_forum_topic');
        })
}

function show_delete_forum_post_popup(post_id) {
    $.post('create_delete_forum_post_popup', {post_id:post_id}, function (data) {
        $('#popup_delete_forum_post').html(data);
        show_popup('delete_forum_post');
    });
}

function show_start_topic(forum_id, doc_id) {
    $.post('show_start_topic', {forum_id:forum_id}, function (data) {
        $('#my_sda_docs').html(data);
        if (doc_id != undefined) {
            $.post('get_document_title_by_id', {id:doc_id}, function (data) {
                post_link_to_document(doc_id, data);
            })
        }
    });
}

function start_new_topic() {
    $.post('show_start_topic', {forum_id:$("#forum_id").html()}, function (data) {
        $('#my_sda_docs').html(data);
    });

    return false;
}

function post_new_topic() {
    var title = $('#start_new_topic').find('#title').val();
    var first_post = $('#start_new_topic').find('#first_post').val();
    var forum = $('#start_new_topic').find('#forum').val();

    var sticky = $('#start_new_topic').find('#sticky').attr('checked');
    if (sticky) {
        sticky = 1;
        var prevent = $('#start_new_topic').find('#prevent').attr('checked');
        if (prevent) {
            prevent = 1;
        } else {
            prevent = 0;
        }
    } else {
        sticky = 0;
        prevent = 0;
    }
    var is_error = false;
    if (forum == 0) {
        $('#forum_error').html('Please, select forum.');
        is_error = true;
    } else {
        $('#forum_error').html('');
    }
    if (!title) {
        $('#title_error').html('Please, enter the title of the topic.');
        is_error = true;
    } else {
        $('#title_error').html('');
    }
    if (!first_post) {
        $('#first_post_error').html('Please, enter the first post of the topic.');
        is_error = true;
    } else {
        $('#first_post_error').html('');
    }
    if (is_error) {
        return false;
    }

    var linked_document_id = $('#linked_document_id').html();

    $.post('create_new_topic',
        {
            title:title,
            first_post:first_post,
            forum:forum, sticky:sticky,
            prevent:prevent,
            linked_document_id:linked_document_id
        },
        function (data) {
            if (data) {
                window.location = '#page=discussions&topic=' + data;
            }
        }
    );

    return false;
}

function open_topic(topic_id, post_id) {
    $.post('show_topic', {topic_id:topic_id}, function (data) {
        $('#my_sda_docs').html(data);
        if (post_id != undefined) {
            $(window).scrollTop($('#post_' + post_id).position().top)
        }
        if ($.browser.name == "chrome" || $.browser.safari == true) {
          $('.post_report_link').each(function() {
            $(this).removeAttr('target');
          });
        }
    })
}

function create_post() {
    var parent_id = $('#parent_id').html();
    var text = $('#post_text').val();
    var topic = $('#topic_id').html();
    var linked_document_id = $('#linked_document_id').html();

    var sticky = $('#sticky').attr('checked');
    if (sticky) {
        sticky = 1;
        var prevent = $('#prevent').attr('checked');
        if (prevent) {
            prevent = 1;
        } else {
            prevent = 0;
        }
    } else {
        sticky = 0;
        prevent = 0;
    }

    $.post('create_new_post',
        {
            parent_id:parent_id,
            text:text, topic:topic,
            linked_document_id:linked_document_id,
            sticky:sticky,
            replies_prevented:prevent
        },
        function (data) {
            if (sticky == 0) {
                $("#my_sda_docs").append(data);
            } else {
                $("#reply_liner").after(data);
            }
            hide_reply_form();

            var replies_number = parseInt($('#replies_number').html());
            $('#replies_number').html(replies_number + 1);

            var begin = data.indexOf('\"');
            var theend = data.indexOf('\"', begin + 1);
            var div_id = data.substr(begin + 1, theend - begin - 1);
            $.scrollTo('#' + div_id);
        }
    );
}

function show_my_research_list(showType, sortBy, order) {
    $.get('show_my_research_list',
        {
            showType:showType,
            sortBy:sortBy,
            order:order
        },
        function (data) {
            $('#my_sda_docs').html(data);
            make_resizable('.my_sda_result div.resize');
            sort_ri_list(sortBy, order);
        })
}

function sort_ri_list(sortBy, order) {
    $('.my_sda_result th.' + sortBy).addClass('sorted');
    if (order == 'desc') $('.my_sda_result th.' + sortBy).addClass('reversed');
}

function show_form_for_reply(post_id) {
    $.post('show_form_for_reply', {post_id:post_id}, function (data) {
        $('.post_reply_form').html('');
        $('#reply_' + post_id).html(data);
    });
}

function hide_reply_form() {
    $('.post_reply_form').html('');
}

function highlightTermsIn(jQueryElements, terms) {
    var wrapper = ">$1<b style='font-weight:normal;color:#000;background-color:rgb(255,255,102)'>$2</b>$3<";
    for (var i = 0; i < terms.length; i++) {
        var regex = new RegExp(">([^<]*)?(" + terms[i] + ")([^>]*)?<", "ig");
        jQueryElements.each(function (i) {
            $(this).html($(this).html().replace(regex, wrapper));
        });
    }
}

// returns array of unique search terms (words, phrases) found in value
function parseSearchTerms(value) {
    // split string on spaces and respect double quoted phrases
    var splitRegex = /("[^"]*")|([^"\s]+(\s|$))/g;
    var rawTerms = value.match(splitRegex);

    var terms = [];
    for (var i = 0; i < rawTerms.length; i++) {

        // trim whitespace, quotes, apostrophes and query syntax special chars
        var term = rawTerms[i].replace(/^[\s"'+-][\s"'+-]*/, '').replace(/[\s*~"'][\s*~"']*$/, '').toLowerCase();

        // ignore if <= 2 chars
        if (term.length <= 2) {
            continue;
        }

        // ignore stopwords
        var stopwords = ["about", "are", "from", "how", "that", "the", "this", "was", "what", "when", "where", "who", "will", "with", "the"];
        var isStopword = false;
        for (var j = 0; j < stopwords.length; j++) {
            if (term == stopwords[j]) {
                isStopword = true;
                break;
            }
        }
        if (isStopword === true) {
            continue;
        }

        // add term to term list
        terms[terms.length] = term;
    }
    return terms;
}


function show_discussion_search_result(query, search_type, page) {
    $.post('discussion_search_result', {query:query, page:page, search_type:search_type}, function (data) {
        $('#my_sda_docs').html(data);
        $("input[name='search_field']").val(query);
        $("input[name='search_field_header']").val(query);
        if (search_type == 'any') {
            $('#search_type_any').attr('checked', 'checked');
        } else if (search_type == 'all') {
            $('#search_type_all').attr('checked', 'checked');
        } else if (search_type == 'ext') {
            $('#search_type_boolean').attr('checked', 'checked');
        }

        highlightTermsIn($("div.search_title"), parseSearchTerms(query));
        highlightTermsIn($("div.search_text"), parseSearchTerms(query));
    })
}

function post_link_to_document(document_id, title) {
    if (document_id == undefined) {
        var document_id = $('#document').val();
        var title = $('#document').text();
    }
    if (document_id && document_id != 0) {
        $('#doc_title').html('Linked Document: <a href="' + document_id + '" >' + title + '</a>' +
            '<input type="button" onclick="remove_link_to_document();" id="remove_link" value="Remove"/>');
        $('#linked_document_id').html(document_id);
        $('#link_document_button').attr('disabled', 'disabled');
    }
    closePopup();
}

function remove_link_to_document() {
    $('#doc_title').html('');
    $('#linked_document_id').html('');
    $('#link_document_button').removeAttr('disabled');
}

function delete_post(post_id) {
    $.post('delete_post', {post_id:post_id}, function (data) {
        $('#post_' + post_id).addClass('hidden');

        var replies_number = parseInt($('#replies_number').html());
        $('#replies_number').html(replies_number - 1);
    })
}

function delete_forum_topic(topic_id) {
    $.post('delete_forum_topic', {topic_id:topic_id}, function (data) {
        $('#topic_' + topic_id).addClass('hidden');
    });
}

function join_research_interest(riId, showType, sortBy, order) {
    $.get('join_research_interest', {riId:riId}, function () {
        window.location.href = "#page=ri_list";
        $.get('show_my_research_list', {showType:showType, sortBy:sortBy, order:order}, function (data) {
            $('#my_sda_docs').html(data);
            sort_ri_list(sortBy, order);
        });
    });
}

function leave_research_interest(riId, showType, sortBy, order) {
    $.get('leave_research_interest', {riId:riId}, function () {
        window.location.href = "#page=ri_list";
        $.get('show_my_research_list', {showType:showType, sortBy:sortBy, order:order}, function (data) {
            $('#my_sda_docs').html(data);
            sort_ri_list(sortBy, order);
        });
    });
}

function create_research_interest(name, description, showType, sortBy, order/*, isContentEditable*/) {
    //var groupType = 0;
    //if (showType == 'pg') {
    //    groupType = 1
    //}
    //if (isContentEditable == undefined) {
    //    isContentEditable = 0;
    //}
    $.get('create_research_interest', {name:name, description:description/*, groupType: groupType, isContentEditable: isContentEditable*/}, function () {
        $.get('show_my_research_list', {showType:showType, sortBy:sortBy, order:order}, function (data) {
            $('#my_sda_docs').html(data);
            sort_ri_list(sortBy, order);
        });
    });
}

function delete_research_interest(riId, showType, sortBy, order) {
    $.get('delete_research_interest', {riId:riId}, function () {
        $.get('show_my_research_list', {showType:showType, sortBy:sortBy, order:order}, function (data) {
            $('#my_sda_docs').html(data);
            sort_ri_list(sortBy, order);
        });
    });
}

function edit_research_interest_name(thisLnk, start_edit) {
    $(thisLnk).hide();

    var span = $('#ri_title');
    var ta = $('#ri_title_edit');

    if (start_edit) {
        $('#lnk_save_title').show();
        span.hide();
        ta.show();
        ta.val($.trim(span.html()));
    } else {
        $('#lnk_edit_title').show();
        span.show();
        ta.hide();
        span.html(ta.val());
    }
    $.post('edit_research_interest_name', {riId:$('#ri_id').val(), name:ta.val()})
}

function edit_research_interest_description(thisLnk, start_edit) {
    $(thisLnk).hide();

    var span = $('#ri_description');
    var ta = $('#ri_description_edit');

    if (start_edit) {
        $('#lnk_save_description').show();
        span.hide();
        ta.show();
        ta.val($.trim(span.html()));
    } else {
        $('#lnk_edit_description').show();
        span.show();
        ta.hide();
        span.html(ta.val());
    }
    $.post('edit_research_interest_description', {riId:$('#ri_id').val(), description:ta.val()})
}

function open_research_interest(ri) {
    $.post('echo_ri_content', {ri:ri}, function (data) {
        $('#my_sda_docs').html(data);
    })
}

function add_document_to_ri() {
    var document_id = $('#document').val();
    var ri = $('#ri_id').val();
    var title = $('#document option:selected').text();

    if (document_id) {
        $.post('add_document_to_ri', {document_id:document_id, ri:ri}, function (data) {
            var template = '<tr><td class="remove">' +
                '<a href="#" onclick="delete_document_from_ri(' + document_id + '); return false;">' +
                '<img alt="Remove" src="' + this_base_url + '/sites/all/themes/stalin/images/cross_close.png"></a>' +
                '<a href="#" onclick="open_document(' + document_id + ')"></td><td><a>' + title + '</a></td><td>Now</td></tr>';
            $('#ri_recent_documents').append(template);
        })

    }
    closePopup();
}

function delete_document_from_ri(document_id) {
    var ri = $('#ri_id').val();
    $.post('delete_document_from_ri', {document_id:document_id, ri:ri}, function (data) {
        $('#doc_' + document_id).addClass("hidden");
    })
}

function rename_tag() {
    var tag = $('#tag_id').val();
    var name = $('#new_tag_name').val();
    if (name) {
        $.post('rename_tag', {tag:tag, name:name}, function (data) {
            closePopup();

            // Reload page.
            var url = window.location.hash;
            var url_obj = $.url(url);
            var page = url_obj.fparam('page');
            if (page == 'tags') {
                show_my_tags();
            } else {
                var tags = url_obj.fparam('tags');
                var sort_by = url_obj.fparam('sort_by');
                var order = url_obj.fparam('order');
                show_docs_for_tags(tags, sort_by, order);
            }

        })
    } else {
        alert('No correct name');
    }
}

function order_forums(a, sort_by) {
    var this_th = $(a).parent();
    //console.log(this_th);
    var sort_id = this_th.attr('id');
    if (!(this_th.hasClass('sorted'))) {
        order = 'asc'
    } else {
        if (this_th.hasClass('reversed'))
            order = 'asc';
        else order = 'desc';
    }
    $.post('echo_sorted_forums', {sort_by:sort_by, order:order}, function (data) {
        $('#my_sda_home_center .my_sda_discussion_home_block_content').html(data);
        var forums_count = $("#recent_forums_carousel ul").children().length;
        var height = 500;
        var forums_visible_count = 0;
        var forums_height = 0;
        $("#recent_forums_carousel ul").children().each(function () {
            forums_height += $(this).outerHeight();
            if (forums_height > height) {
                return;
            }
            forums_visible_count++;
        });

        //console.log($('#'+sort_id));
        $('#' + sort_id).addClass('sorted');
        if (order == 'desc') $('#' + sort_id).addClass('reversed');

        if (forums_visible_count < forums_count) {
            if ($("#recent_forums_carousel").length) {
                $("#recent_forums_carousel").jCarouselLite({
                    btnNext:".recent_forums_carousel .scroll_down",
                    btnPrev:".recent_forums_carousel .scroll_up",
                    vertical:true,
                    circular:false,
                    visible:forums_visible_count,
                    speed:400,
                    start:0
                });
            }
        } else {
            $(".controls.recent_forums_carousel").addClass("hidden")
        }
    })
}

function show_create_export_form_popup(type) {
    if (get_checked_ids().length == 0) {
        alert('Please, select ' + type + '.');
    } else {
        show_popup('create_export_form');
    }
}

function show_export_form_popup(type, form_id) {
    if (get_checked_ids().length == 0) {
        alert('Please, select ' + type + '.');
    } else {
        show_popup(form_id);
    }
}
