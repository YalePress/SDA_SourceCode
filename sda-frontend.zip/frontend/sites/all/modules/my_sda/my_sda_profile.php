<?php

function create_prew_user_info_popup() {
    global $base_url;
    $user_id=$_POST['user_id'];
    $profile=user_load($user_id);
    $out='<div class="popup_header">'
            .(!empty($profile->profile_last_name) ? $profile->profile_first_name.' '.$profile->profile_last_name : $profile->mail)
            .'&nbsp;<img alt="Close" src="'.base_path().'sites/all/themes/stalin/images/cross_close.png">'
         .'</div>'
         .'<div class="popup_body">';
        $out.='<div class="popup_top_user_info">';
            $out.='<div class="popup_user_city">'
                .$profile->profile_city.' '.(($profile->profile_country=='USA' && $profile->profile_state)?$profile->profile_state:'').' '.$profile->profile_country
            .'</div>'
            .'<div class="popup_user_university">'
                .$profile->profile_institution
            .'</div>';
        if (can_access_mail($profile)) {
          $out.= '<div class="popup_user_mail">'
                   .$profile->mail
                 .'</div>';
        }
        $out.= '</div>';
        if (!empty($profile->profile_about_me)) {
            $out.='<div class="popup_user_about">'
                .'<div class="popup_user_about_title">About me:</div>'
                .'<div class="popup_user_about_text">'
                    .$profile->profile_about_me
                .'</div>'
            .'</div>';
        }
        $alias_url = db_fetch_object(db_query("SELECT dst FROM url_alias WHERE src='user/{$profile->uid}'"));
        $out.='<input type="button" class="popup_button" onclick="window.location=\''.$base_url.'/'.$alias_url->dst.'\'; closePopup()" value="Go to Profile">';
        $out.='</div>';

      echo $out;
}

function view_profile_page() { // Could be removed
    global $base_url;
    $id = $_POST['id'];
    if (empty($id) || $id == 0) {
        global $user;
        $id = $user->uid;
    }

    $profile = user_load($id);

    if ($profile == FALSE) {
        echo "Sorry, this user doesn't exist.";
        exit();
    }

    $back_link = $_POST['back_link'];
    if (empty($back_link)) $back_link = "#";

    $out = '<table class="table_no_top_border" cellspacing="0" cellpadding="0" style="margin: 8pt 10px;">
                <tr>
                    <td colspan="2">
                        <div class="back_link"><a href="' . $back_link . '">&#9668; Back</a></div>
                    </td>
                </tr>
                <tr>
                    <td width="450px">
                        <table>
                            <tr>
                                <td width="10%">
                                    <div class="profile_user_image">';
        if(!empty($profile->picture)) {
                $out .= '               <img width="100px" alt="User image" src="'.$base_url.'/'.$profile->picture.'?'.time().'"></div><p/>';
        }
        else {
            $out .= '                   <img alt="User image" src="$base_url/sites/default/files/pictures/no_avatar.png"></div><p/>';
        }
        $out .= "               </td>
                                <td>
                                    <span class=\"profile_user_name\">$profile->profile_first_name $profile->profile_last_name</span>
                                    <p/><span class=\"profile_location\">$profile->profile_city, $profile->profile_state, $profile->profile_country</span>
                                    <p/><span class=\"profile_university\">$profile->profile_institution</span>
                                    <p/><span class=\"profile_email\"><a href=\"mailto:$user->mail\">$user->mail</a></span>
                                </td>
                            </tr>
                            <tr>
                                <td colspan=\"2\">";

	// OTHER FIELDS SECTION
	// Position
	if(!empty($profile->profile_position)) {
		$out .= "<p><span class=\"profile_field_title\">Position:</span><br><span class=\"profile_field_text\">$profile->profile_position</span></p>";
	}

	// Title
	if(!empty($profile->profile_title)) {
		$out .= "<p><span class=\"profile_field_title\">Title:</span><br><span class=\"profile_field_text\">$profile->profile_title</span></p>";
	}

	// Department
	if(!empty($profile->profile_department)) {
		$out .= "<p><span class=\"profile_field_title\">Department:</span><br><span class=\"profile_field_text\">$profile->profile_department</span></p>";
	}

	// About Me
	if(!empty($profile->profile_about_me)) {
		$out .= "<p><span class=\"profile_field_title\">About Me:</span><br><span class=\"profile_field_text\">$profile->profile_about_me</span></p>";
	}

	// Website/Blogs
	if(!empty($profile->profile_www)) {
		$out .= "<p><span class=\"profile_field_title\">Website/Blogs:</span><br><span class=\"profile_field_text\">$profile->profile_www</span></p>";
	}

	// Affilations
	if(!empty($profile->profile_affiliations)) {
		$out .= "<p><span class=\"profile_field_title\">Affiliations:</span><br><span class=\"profile_field_text\">$profile->profile_affiliations</span></p>";
	}

    $out .= '                   </td>
                            </tr>
                        </table>
                    </td>
                    <td>';

    $query = "SELECT ri.id, ri.name FROM research_interests ri
                JOIN research_interests_users ru ON ru.research_interest_id=ri.id
                WHERE ru.user_id = %d"; // AND ri.type = 0";
    $results = db_query($query. $id);
    $ris = array();
    while ($result = db_fetch_array($results)){
        $ris[] = $result;
    }

    $out .= '           <div id="my_sda_home_my_groups" class="my_sda_home_block" style="width:390px; float: left;">
                        <div class="my_sda_home_block_header" style="cursor: default;">
                            <h2>Research Interests</h2>
                        </div>
                        <div class="my_sda_home_block_content">';
    if (count($ris) == 0) {
        $out .=             'User isn\'t a member of any Research Interest.';
    } else {
        foreach ($ris as $ri){
            $out.='         <div class="ri_name" style="line-height: 28px;"><a href="'.base_path().'node/13#page=ri&id='.$ri['id'].'">'.$ri['name'].'</a></div>';
        }
    }
    $out .=             '</div>
                    </div>
                </td>
            </tr>
        </table>';

	echo $out;
}

function render_profile_page($id = 0) {
  global $base_url;
  global $user;
  //$id = $_POST['id'];
  if (empty($id) || $id == 0) {
    $id = $user->uid;
  }

  $profile = user_load($id);

  if (!$profile)
  {
    return "Sorry, this user doesn't exist.";
  }

  $output = '';
  $output .= '<div class="profile_view_name">'.$profile->profile_first_name.' '.$profile->profile_last_name.'</div>';

  $output .= '<div class="profile_view_photo">';
  if(!empty($profile->picture)) {
    $output .= '<img width="100px" alt="User image" src="'.$base_url.'/'.$profile->picture.'?'.time().'"><p/>';
  } else {
  	$output .= '<img width="85px" alt="User image" src="'.$base_url.'/sites/default/files/pictures/no_avatar.png"><p/>';
  }
  $output .= '</div>';

  $output .= '<div class="profile_view_info">';
    $output .= '<div class="profile_view_mail">';
    if(!empty($profile->mail) && can_access_mail($profile)) {
    	$output .= '<div class="profile_view_title">Email:'.$profile->mail->title.'</div>';
    	$output .= '<div class="profile_view_item">' . $profile->mail . ($profile->profile_email_permission == 'Private' ? ' (Private)' : ' (Public)').'</div>';
    }
    $output .= '</div>';
    $output .= '<div class="profile_view_institution">';
    if(!empty($profile->profile_institution)) {
    	$output .= '<div class="profile_view_title">Institution:</div>';
    	$output .= '<div class="profile_view_item">'.$profile->profile_institution.'</div>';
    }
    $output .= '</div>';
    $output .= '<div class="profile_view_location">';
    if(!empty($profile->profile_country)) {
    	$output .= '<div class="profile_view_title">Location:</div>';
    	$output .= '<div class="profile_view_item">'."$profile->profile_city, ".($profile->profile_state!='0' ? $profile->profile_state.', ' : '')."$profile->profile_country</div>";
    }
    $output .= '</div>';
    $output .= '<div class="profile_view_location">';
    if(!empty($profile->profile_position)) {
    	$output .= '<div class="profile_view_title">Title/Position:</div>';
    	$output .= '<div class="profile_view_item">'.$profile->profile_position.'</div>';
    }
    $output .= '</div>';
    $output .= '<div class="profile_view_department">';
    if(!empty($profile->profile_department)) {
    	$output .= '<div class="profile_view_title">Department:</div>';
    	$output .= '<div class="profile_view_item">'.$profile->profile_department.'</div>';
    }
    $output .= '</div>';
    $output .= '<div class="profile_view_www">';
    if(!empty($profile->profile_www)) {
    	$output .= '<div class="profile_view_title">Websites/Blogs:</div>';
    	$output .= '<div class="profile_view_item">'.render_urls($profile->profile_www).'</div>';
    }
    $output .= '</div>';
    $output .= '<div class="profile_affiliations">';
    if(!empty($profile->profile_affiliations)) {
    	$output .= '<div class="profile_view_title">Affiliations:</div>';
    	$output .= '<div class="profile_view_item">'.find_url($profile->profile_affiliations).'</div>';
    }
    $output .= '</div>';
    $output .= '<div class="profile_view_facebook">';
    if(!empty($profile->profile_facebook)) {
    	$output .= '<div class="profile_view_title">Facebook:</div>';
    	$output .= '<div class="profile_view_item">'.render_urls($profile->profile_facebook).'</div>';
    }
    $output .= '</div>';
    $output .= '<div class="profile_view_twitter">';
    if(!empty($profile->profile_twitter)) {
    	$output .= '<div class="profile_view_title">Twitter:</div>';
    	$output .= '<div class="profile_view_item">'.render_urls($profile->profile_twitter).'</div>';
    }
    $output .= '</div>';
    $output .= '<div class="profile_view_otherprofiles">';
    if(!empty($profile->profile_otherprofiles)) {
    	$output .= '<div class="profile_view_title">Other Profiles:</div>';
    	$output .= '<div class="profile_view_item">'.find_url($profile->profile_otherprofiles).'</div>';
    }
    $output .= '</div>';

  $output .= '</div>';

  $output .= '<div class="profile_view_extra">';
    $output .= '<div class="profile_view_about_me">';
    if(!empty($profile->profile_about_me)) {
    	$output .= '<div class="profile_view_title">About Me:</div>';
    	$output .= '<div class="profile_view_item">'.$profile->profile_about_me.'</div>';
    }
    $query = "SELECT ri.id, ri.name FROM research_interests ri
                JOIN research_interests_users ru ON ru.research_interest_id=ri.id
                WHERE ru.user_id = %d"; // AND ri.type = 0";
    $results = db_query($query. $id);
    $ris = array();
    while ($result = db_fetch_array($results)){
        $ris[] = $result;
    }
    $output .= '<div class="profile_view_title">Research Interests:</div>';
    $output .= '<div class="profile_view_item">';
    if (count($ris) == 0) {
        $output .= 'User isn\'t a member of any Research Interest.';
    } else {
        foreach ($ris as $ri){
            $output.=' <div class="ri_name" style="line-height: 1.5em;"><a href="'.base_path().'node/13#page=ri&id='.$ri['id'].'">'.$ri['name'].'</a></div>';
        }
    }
    $output .= '</div>
              </div>';
  $output .= '</div>';

  echo $output;
}

function render_urls($in_string, $max=0) {
	$out = '';
	$url_array = explode(',', $in_string);
	$secure = false;
	foreach ($url_array as $url) {
		$new_url = trim($url);
		if (strpos($new_url, 'http://')===0) {
			$new_url = substr($new_url, 7);
		} else if (strpos($new_url, 'https://')===0) {
			$new_url = substr($new_url, 8);
			$secure = true;
		}
		$link = $new_url;
		if (strpos($new_url,'http://')!==0) {
			$link = ($secure===true) ? 'https://'.$new_url : 'http://'.$new_url;
		} else {
			$new_url = substr($new_url, 8);
		}
		$out .= '<div class="profile_view_url" style="line-height: 1.5em;"><a href="'.$link.'" target="_blank">'.$url.'</a></div>';
	}
  return $out;
}

function find_url($in_str) {
	$replacements = '<a href="http\\3://\\4\\5" target="_blank">http\\3://\\4\\5</a>';
	$pattern = '/((http([s]?):\/\/)|(www))([\/.a-zA-Z0-9_-]+)/i';
	$out = preg_replace($pattern, $replacements, $in_str);
	return $out;
}

function can_access_mail($in_user) {
    global $user;
    if (is_admin_user($user)) return true;
    
    if ($user->uid == $in_user->uid) return true;
    
    if ($in_user->profile_email_permission == 'Everyone') return true;
    
    if ($in_user->profile_email_permission == 'My Groups Only') {
      $groups = db_fetch_object(db_query("SELECT riu.research_interest_id FROM research_interests_users riu LEFT JOIN research_interests_users riu2 ON (riu.research_interest_id = riu2.research_interest_id) WHERE (riu.user_id = %d AND riu2.user_id = %d)", $user->uid, $in_user->uid));
      if ($groups) return true;
    }
    
    return false;
}
