<?php

function my_tags()
{
    global $user;
    $uid = $user->uid;

    $fetch_tags_query =
            'SELECT
                UPPER(t.name) tag_id,
                t.document_id node_id,
                UPPER(t.name) tag_name,
                n.title node_title
            FROM tags t
            JOIN node_view n ON n.nid = t.document_id
            WHERE user_id=%d';

    $fetch_tags_result = db_query($fetch_tags_query, $uid);

    while ($tag_line = db_fetch_array($fetch_tags_result)) {
        $by_tag_arr[$tag_line['tag_id']]['tag_name'] = $tag_line['tag_name'];
        $by_tag_arr[$tag_line['tag_id']]['nodes'][$tag_line['node_id']] = array('node_id' => $tag_line['node_id'],
                                                                                'node_title' => $tag_line['node_title']);
        $by_node_arr[$tag_line['node_id']]['node_title'] = $tag_line['node_title'];
        $by_node_arr[$tag_line['node_id']]['tags'][$tag_line['tag_id']] = array('tag_id' => $tag_line['tag_id'],
                                                                                'tag_name' => $tag_line['tag_name']);
        $tags[] = $tag_line;
    }

    echo '<div class="cell_title"><div id="results_title">My Tags</div></div>';

    if (empty($tags)) {
        return;
    }

    echo '<div class="tags_buttons results_filter">';

    echo button_link(array('text' => 'Rename Tag',
                          'onclick' => "show_popup('rename_tag'); return false;"));
    echo '</div>';

    echo html_for_rename_tag_popup();

    echo '<div style="font-size: 12pt; padding: 8pt 10px;">';

    echo process_my_tags_tree($by_tag_arr, $by_node_arr);

    echo "</div>\n";
}

function html_for_rename_tag_popup()
{
    global $user;

    $tags = db_get_list(db_query("SELECT DISTINCT name FROM tags WHERE user_id=%d", $user->uid));

    return tpl('my_sda', 'rename_tag_popup',
               array(
                    'tags' => $tags
               ));
}

// utility function
function offset($layer = 0)
{
    $offset = '';
    for ($i = 0; $i < $layer; $i++) {
        $offset .= "\t";
    }
    return $offset;
}

// callback function for uasort
function cmp_tags($tag1, $tag2)
{
    $cmp_result = 0;
    if (is_array($tag1) && is_array($tag2) && isset($tag1['tag_name']) && isset($tag2['tag_name'])) {
        $cmp_result = strncasecmp($tag1['tag_name'], $tag2['tag_name'], 255);
    }
    return $cmp_result;
}

// tags tree processing function
function process_my_tags_tree($by_tag_arr, $by_node_arr, &$tag_counter = 0, &$layer = 0, &$tags_history = array())
{
    $echo['main'] = ''; // main echo write buffer

    $offset = offset($layer);

    #print_r($by_tag_arr);
    #print_r($by_node_arr);

    uasort($by_tag_arr, 'cmp_tags');

    // itarate over list of tags
    foreach ($by_tag_arr as $tag_id => $tag_entry) {
        $echo['arrow'] = ''; // arrow buffer
        $echo['delayed'] = ''; // delayed write buffer
        $echo['tree'] = ''; // tree processing buffer

        $tag_name = $tag_entry['tag_name'];
        $nodes = $tag_entry['nodes'];
        foreach ($nodes as $t_node_id => $t_node_entry) {
            if (!array_key_exists($t_node_id, $by_node_arr)) {
                unset($nodes[$t_node_id]);
            }
        }
        // ► &#9658;
        // ▼ &#9660;
        $node_count = count($nodes);
        // if tag has nodes attached
        if ($node_count > 0) {
            // remember this tag in history not to use further in the tree
            $tags_history[$tag_id] = $tag_id;

            $echo['main'] .= "$offset<div><p>";
            $echo['arrow'] .= "<div style='float: left;padding-left: 0px; width: 12px;'><a href=\"javascript:toggle_tag($tag_counter)\" id=\"ref$tag_counter\" style=\"color: gray; text-decoration: none;\">&#9658;</a></div>";
            #$echo['delayed'] .= " <a href=\"javascript:show_docs_for_tagstr('".array_to_httpget("tags", $tags_history)."','','')\">$tag_name ($node_count)</a></p>\n";
            $echo['delayed'] .= "<a href=\"#page=docs_by_tags&tags=" . implode(",", $tags_history) . "\">$tag_name ($node_count)</a></p>";
            $echo['delayed'] .= "$offset<div id=\"tag$tag_counter\" style=\"visibility: hidden; position: absolute; padding-left: 20px;\">\n";

            $tag_counter++;

            // iterate over nodes for current tag
            $by_tag_arr_filtered = $by_tag_arr;
            $by_node_arr_filtered = $by_node_arr;
            foreach ($nodes as $node_id => $node_entry) {
                $tags = $by_node_arr[$node_id]['tags'];
                $tags_count = count($tags);
                if ($tags_count == 1 || $layer > 0) {
                    $node_title = $node_entry['node_title'];
                    #$echo['tree'] .= "$offset<p><a href=\"../sda_viewer?n=$node_id\">$node_title</a></p>\n";
                }
                else if ($tags_count > 1) {
                    unset($by_tag_arr_filtered[$tag_id]);
                    foreach ($by_node_arr_filtered as $t_node_id => $t_node) {
                        if (!isset($t_node['tags'][$tag_id])) {
                            unset($by_node_arr_filtered[$t_node_id]);
                        }
                        else {
                            unset($by_node_arr_filtered[$t_node_id]['tags'][$tag_id]);
                        }
                    }
                    $layer++;
                    $echo['tree'] .= process_my_tags_tree($by_tag_arr_filtered, $by_node_arr_filtered, $tag_counter, $layer, $tags_history);
                    $layer--;
                    #break;
                }
            }
            if (empty($echo['tree'])) {
                // leaf is empty, no tree expand available
                $echo['arrow'] = '<div style="float: left;padding-left: 0px; width: 12px;">&nbsp;</div>';
            }
            $echo['main'] = implode('', $echo);
            $echo['main'] .= "$offset</div></div>\n";
            unset($tags_history[$tag_id]);
        }
    }
    #print_r($echo);
    return $echo['main'];
}

function docs_by_tag()
{
    global $user;
    $tags = $_GET['tags'];
    $order = $_GET['order'];
    $sort_by = $_GET['sort_by'];
    $out = '<div id="sda_tags">';
    $i = 0;
    $tags_str = '';

    $out .= '<div id="str_tags" style="display:none">' . array_to_httpget("tags", $tags) . '</div>';
    $out .= make_tags_results_header($tags);

    if (count($tags) && $tags[0] != '') {
        $out .= make_tags_results_table($tags, $order, $sort_by, 0, 1);
    }
    $out .= '</div>';

    echo $out;
}

function make_tags_results_header($tags, $selector = '', $value = "")
{
//    global $user;
//    global $theme_path;
    $out = '<div id="search_results_header">
            <div class="cell_title">
            <div id="results_title">';
    $out .= 'My Tags: ';
    $is_single_tag = (count($tags) == 1);
    for ($i = 0; $i < count($tags); $i++) {
        $tag = $tags[$i];
        if (!$is_single_tag) {
            $other_tag = $tags[1 - $i];
        }
        $out .= $tag;
        if ($is_single_tag) {
            $out .= '<img style="cursor: pointer" src="' . base_path() . 'sites/all/themes/stalin/images/cross_close.png" onclick="window.location=\'#page=tags\'"/>';
        } else {
            $out .= '<img style="cursor: pointer" src="' . base_path() . 'sites/all/themes/stalin/images/cross_close.png" onclick="window.location=\'#page=docs_by_tags&tags=' . $other_tag . '\'"/>';
        }
        if (!$is_single_tag && $i == 0) $out .= ', ';
    }
    $out .= '</div>';
    $out .= '<div id="back_link"><a href="#page=tags">&#9668; Back to My Tags</a></div>';
    $out .= '</div>';
    $out .= '<div class="results_filter">
                        <div class="filter_ations">
                            <a class="button_outer_left"><span class="button_outer_right"><span class="button_outer_center"><span class="button_inner"><input type="checkbox" name="empty" class="check_all" /><img onclick="show_select_check_all()" src="' . base_path() . 'sites/all/themes/stalin/images/arrow_down.png" class="arrow_down" alt="" /></span> <span class="va_middle"></span></span></span></a>'

            . '<div style="position:relative;float:left">'
            . '<div class="hidden" id="select_check_all">'
            . '<div class="select_item select_all">Select All</div>'
            . '<div class="select_item clear_all">Clear All</div>'
            . '</div>'
            . '</div>';


    //if($user->uid){
    $out .= '<a onclick="perform_export();" class="button_outer_left">
                            <span class="button_outer_right"><span class="button_outer_center">
                            <span class="button_inner">' . t('Export Citation') . '</span><span class="va_middle">
                            </span></span></span></a>
                            ' . hidden_divs_for_export_popup();
    //}
    //else
    //{
    /*$out.='<a onclick="show_popup(\'login_page\');return false;" class="button_outer_left">
    <span class="button_outer_right"><span class="button_outer_center">
    <span class="button_inner">'.t('Export Citation').'</span><span class="va_middle">
    </span></span></span></a>' ;
    }*/
    $out .= '<a onclick="show_popup(\'rename_tag\');" class="button_outer_left">
                            <span class="button_outer_right"><span class="button_outer_center">
                            <span class="button_inner">' . t('Rename Tag') . '</span><span class="va_middle">
                            </span></span></span></a>';
    $out .= '</div>';

    $out .= '<div class="sort_lists" style="position:relative">
                            <a class="active" onclick="show_select_view_options(this);return false;" href="#">' . t('View options') . '</a>
                                <div class="hidden" id="view_options">'
            . drupal_get_form('select_tags_fields_to_view_form') .
            '<hr>
                                <a href="#" onclick="apply_view_options_tags_documents();return false;" class="apply button_outer_left"><span class="button_outer_right"><span class="button_outer_center"><span class="button_inner">' . t('Apply') . '</span><span class="va_middle"></span></span></span></a>
                                </div>
                            <a class="active" onclick="show_select_sort_by(this);return false;" href="#">' . t('Sort by') . '</a>
                                <div id="sort_by" class="hidden"><select onclick="hide_select_sort_by();" size="6">
                                <option selected="selected" value="title">' . t('Title') . '</option>
                                <option value="doc_tags">' . t('Tags') . '</option>
                                <option value="author">' . t('Author') . '</option>
                                <option value="doc_id">ID #</option>
                                <option value="date">' . t('Date') . '</option>
                                <option value="doc_tagged_date">' . t('Date Tagged') . '</option>
                                </select></div>
                        </div>
                        <div class="clear"></div>
                    </div>';
    $out .= '</div>';

    $out .= html_for_rename_tag_popup();

    return $out;
}

function make_tags_results_table($tags, $order, $sort_by, $offset = 0, $tags_result = 0)
{ //offset = number of page, zero-based

    $out = '';
    $s_html = '';
    global $user;
    global $base_url;
    global $directory;

    $query_args = array();
    $query = "
            SELECT
             n.nid, n.title as title, c.field_doc_id_value as doc_id, c.field_date_value as date,
             c.field_autors_value as author,

             group_concat(DISTINCT t.name separator ',') as doc_tags,
             max(t.creation_date) as doc_tagged_date,

             c.field_recipient_value, c.field_subject_value,
             c.field_description_value, c.average_avg_rating
            FROM node_view n
            INNER JOIN content_type_archive c ON c.nid = n.nid
            INNER JOIN node_revisions nr ON nr.nid = n.nid
            LEFT JOIN url_alias ua ON ua.src=CONCAT('node/',n.nid)";

            for ($i=0; $i<count($tags); $i++) {
                $tag_tbl_name = "tt$i";
                $query .= " JOIN tags $tag_tbl_name ON $tag_tbl_name.document_id=n.nid AND $tag_tbl_name.name='%s' ";
                $query_args[] = $tags[$i];
            }

            $query .= " LEFT JOIN tags t ON t.document_id=n.nid ";
    //if($module=='browse'&&$m_data['selector']=='RGASPI'){
    //$query.=" LEFT JOIN node_level nl ON nl.node_id=c.nid AND nl.".$m_data['rgaspi_child']." is not null ";}
    $query .= " WHERE n.type='archive'".
            "AND t.user_id = %d
            GROUP BY n.nid ";

    $query_args[] = $user->uid;

    if ($sort_by) {
        $query .= "ORDER BY " . $sort_by . " " . $order;
    } else {
//        $query .= " ORDER BY POSITION(','+n.nid+',' IN '({$ids_string})')";
    }

    $archives = db_get_list(db_query($query, $query_args));

    /* TODO: correct paging!!! */
    $items_per_page = 50;
//    $items_per_page = 3;
    $start = $items_per_page * $offset;
    $count = count($archives) - $start;
    $links_count = (int)((count($archives) - 1) / $items_per_page) + 1;
    if ($count > $items_per_page) {
        $count = $items_per_page;
    }
    $last = $start + $count;

    if ($links_count > 1) {
        $out .= '<div id="pager">';
        $out .= '<a href="0" onclick="show_pager(this);return false;"><span class="first_page"></span></a>';
        if ($offset > 2) {

            $out .= '<a href="0" onclick="show_pager(this);return false;">1</a>';

        }
        if ($offset > 3) $out .= ' ... ';
        for ($i = ($offset - 2); $i < ($offset + 3); $i++) {
            if ($i >= 0 && $i < $links_count) {
                $out .= '<a href="' . $i . '" onclick="show_pager(this);return false;"> ';
                if ($i == $offset) $out .= '<b>' . ($i + 1) . '</b>';
                else $out .= ($i + 1);
                $out .= ' </a>';
            }
        }
        if ($offset < ($links_count - 4)) $out .= ' ... ';
        if ($offset < ($links_count - 3)) {
            $out .= '<a href="' . ($links_count - 1) . '" onclick="show_pager(this);return false;"> ' . ($links_count) . '</a>';

        }
        $out .= '<a href="' . ($links_count - 1) . '" onclick="show_pager(this);return false;"><span class="last_page"></span></a>';
        $out .= '</div>';
    }

    $out .= '<form action="">';
    //$out.='<div class="search_result_wrap">';
    $out .= '<div id="popup_more_info" class="hidden"></div>';
    $out .= '<table cellpadding="0" cellspacing="0" border="0" class="my_sda_result">';
    $out .= '<thead>';
    $out .= '<tr class="header">';
    $out .= '<th class="checkbox_cell"></th>';
    $out .= '<th class="type_tags_documents title"><div class="resize">TITLE<a href="title"></a><div class="va_middle"></div></div></th>';
    $out .= '<th class="type_tags_documents doc_tags"><div class="resize">TAGS<a href="doc_tags"></a><div class="va_middle"></div></div></th>';
    $out .= '<th class="type_tags_documents author"><div class="resize">AUTHOR<a href="author"></a><div class="va_middle"></div></div></th>';
    $out .= '<th class="type_tags_documents doc_id"><div class="resize">ID #<a href="doc_id"></a><div class="va_middle"></div></div></th>';
    $out .= '<th class="type_tags_documents date"><div class="resize">DATE<a href="date"></a><div class="va_middle"></div></div></th>';
    $out .= '<th class="hidden node_id"><div class="resize">node_id<a href="node_id"></a><div class="va_middle"></div></div></th>';
    $out .= '<th class="hidden doc_image"><div class="resize"><div class="va_middle"></div></div></th>';
    $out .= '<th class="type_tags_documents doc_tagged_date"><div class="resize">DATE TAGGED<a href="doc_tagged_date"></a><div class="va_middle"></div></div></th>';
    $out .= '</tr>';
    $out .= '</thead>';
    $out .= '<tbody>';
    /////////////////////////
    //$full_fields=array('dst','title','field_autors_value','field_recipient_value','field_subject_value');

    foreach ($archives as $archive)
    {
        foreach ($archive as $key => &$field) {
            //if(!in_array($key,$full_fields))
            //    $field=crop($field,35);
            if (!$field) $field = 'N/A';
        }

        $out .= '<tr>';
        $out .= '<td class="checkbox_cell"><input name="row_check" type="checkbox" value="' . $archive['nid'] . '"></td>';
        $out .= '<td class="title">';
        $out .= '<a href="' . $base_url . '/sda_viewer?n=' . $archive['nid'] /*. '&t=tag&id=' . $tags_ids[0]*/ . '">' . $archive['title'] . '</a>';
        $out .= '</td>';

        $out .= '<td class="doc_tags">';
        $results = db_query("SELECT t.id, t.name FROM tags t WHERE t.user_id = %d AND t.document_id = %d", $user->uid, $archive['nid']);
        $tag_links = array();
        while ($result = db_fetch_array($results)) {
//            $tag_links[] = '<a href="#page=docs_by_tags&tags=' . $result['id'] . '">' . $result['name'] . '</a>';
            $tag_links[] = '<a href="' .$base_url. '/sda_viewer?n=' . $archive['nid'] .'&t=tag&id='. $result['id'] . '">' . $result['name'] . '</a>';
        }
        $tags_out = join(', ', $tag_links);
        $out .= $tags_out;
        $out .= '</td>';

        $out .= '<td class="author">';
        $out .= $archive['author'];
        $out .= '</td>';

        $out .= '<td class="doc_id">';
        $out .= $archive['doc_id'];
        $out .= '</td>';

        $out .= '<td class="date">';
        //$out.=get_archive_publication_date($archive['nid']);
        $out .= $archive['date'];
        $out .= '</td>';

        $out .= '<td class="hidden node_id">';
        $out .= $archive['nid'];
        $out .= '</td>';

        $out .= '<td class="hidden doc_image">';
        $node_uploads = db_query("SELECT f.filepath FROM files f,upload u WHERE u.fid = f.fid AND u.nid='{$archive['nid']}'");
        $node_upload = db_fetch_object($node_uploads);

        $out .= get_appropriate_img_path($node_upload->filepath);

        $out .= '</td>';

        $out .= '<td class="doc_tagged_date">';
        $out .= mysda_format_date($archive['doc_tagged_date']);
        $out .= '</td>';


        $out .= '</tr>';

        //create one snippet
         $s_html.='<div class="snippet hidden">';

            $s_html.='<div class="snippet-left">';
            $s_html.='<div class="trumbs"><img onclick="open_document(\''.$base_url.'/sda_viewer?n='.$archive['nid'].'\');return false;" src="'.get_appropriate_img_path($node_upload->filepath).'"></div>';
            $s_html.='<div class="save_checkbox"><input type="checkbox" value="'.$archive['nid'].'"> Select</div>';
            $s_html.='<a href="#" class="show_pop_up_preview submit_outer_left"><span class="submit_outer_right"><span class="submit_outer_center"><span class="submit_inner">'.t('More Info').'</span><span class="va_middle"></span></span></span></a>';
            $s_html.='</div>';

            $s_html.='<div class="snippet-right">';
            $s_html.='<div class="doc_title"><a href="'.$base_url.'/sda_viewer?n='.$archive['nid'].'">'.crop($archive['title'],100).'</a></div>';
            $s_html.='<div class="doc_author">Author: '.crop(sda_render_multiline($archive['author']),100).'</div>';
            $s_html.='<div class="doc_publication_date">Date: '.arch_formate_date($archive['date']).'</div>';
            $s_html.='<div class="hidden node_id">'.$archive['nid'].'</div>';
            $s_html.='<div class="doc_recipient">Recipient: '.crop(sda_render_multiline($archive['field_recipient_value']),100).'</div>';
            $s_html.='<div class="doc_subject">Subject: '.crop(sda_render_multiline($archive['field_subject_value']), 100).'</div>';
            $s_html.='<div class="doc_id">ID #: '.$archive['doc_id'].'</div>';
            $s_html.='<div class="doc_description">Description: '.crop($archive['field_description_value'], 500).'</div>';
            $s_html.='<div class="hidden doc_views_count">'.$archive['field_views_count'].'</div>';
            $s_html.='<div class="doc_rating">Avg. User Rating: '.$archive['average_avg_rating'].'</div>';

            $s_html.='<div class="doc_tags">User tags: ';
            $s_html .= $tags_out;
            $s_html .= '</div>';

            $s_html.='<div class="hidden doc_relevancy">'.$archive['relevancy'].'</div>';
            $s_html.='</div>';

         $s_html.='</div>';
    }
    $out .= '</tbody>';
    $out .= '</table>';
    $out .= '<div id="search_results_snippets">';
    $out .= $s_html;
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</form>';

    return $out;
}

function select_tags_fields_to_view_form()
{
    global $user;
    if (!session_id()) {
        session_start();
    }
    if (isset ($_SESSION['tags_documents_view_type'])) $results['view_type'] = $_SESSION['tags_documents_view_type'];
    else $results['view_type'] = 'list';
    $form['list_or_snippets'] = array(
        '#type' => 'radios',
        '#title' => '<b>View results as</b>',
        '#options' => array(
            'list' => 'List',
            'snippets' => 'Thumbnails',),
        '#prefix' => '<div id="list_or_snippets">',
        '#suffix' => '</div>',
        '#default_value' => $results['view_type'],
    );

    if (isset ($_SESSION['tags_documents_view_options'])) {
        $options = $_SESSION['tags_documents_view_options'];
    } else {
        $options = array('title', 'doc_tags', 'author', 'date', 'doc_id', 'doc_tagged_date');
        $_SESSION['tags_documents_view_options'] = $options;
    }

    $form['fields_to_view'] = array(
        '#type' => 'checkboxes',
        '#title' => '<b>Result fields</b>',
        '#options' => array(
            'title' => 'Title',
            'doc_tags' => 'Tags',
            'author' => 'Author',
            'date' => 'Date',
            'doc_id' => 'ID#',
            'doc_tagged_date' => 'Date Tagged',
        ),
        '#default_value' => $options,
        '#prefix' => '<div id="select_fields_to_view">',
        '#suffix' => '</div>'
    );

    return $form;
}

function save_user_view_options_tags_documents()
{
    $options = $_POST['options'];
    $_SESSION['tags_documents_view_options'] = $options;

    $view_type = $_POST['view_type'];
    $_SESSION['tags_documents_view_type'] = $view_type;
}