<?php

define('FOLDER_TYPE_RI', 'research_interests');
define('FOLDER_TYPE_PERSONAL', 'personal');
//define('FOLDER_TYPE_PRIVATE', 'private');

function create_new_folder_form()
{
    $form['folder_name'] = array(
        '#title' => t('Folder Name'),
        '#type' => 'textfield',
        '#required' => TRUE // TODO: how to validate by drupal?
    );

    $form['folder_desc'] = array(
        '#title' => 'Description <i>(optional)</i>',
        '#type' => 'textarea'
    );

    return $form;
}

function show_my_sda_folders()
{
    $type = $_POST['type'];
    $sort_by = $_POST['sort_by'];
    $order = $_POST['order'];

    $folders = get_my_sda_folders($type, $sort_by, $order);

    echo tpl('my_sda', 'my_sda_folders',
             array(
                  'type' => $type,
                  'folders' => $folders));
    exit();
}

function get_my_sda_folders($type, $sort_by, $order)
{
    // TODO: clean $sort_by $order against SQL INJ
    global $user;

    $user_id = $user->uid;

	if (trim($sort_by) != '') {
        $order_clause = " ORDER BY $sort_by $order ";
    } else {
        $order_clause = '';
    }
	
	if ($type == FOLDER_TYPE_PERSONAL) {
		$res = db_query("SELECT f.id, f.name, f.description,
                         f.creation_date created, f.last_update_date last_updated, count(df.document_id) doc_number
                         FROM folders f LEFT JOIN documents_folders df on f.id = df.folder_id
                         WHERE f.research_interest_id IS null AND f.user_id=$user_id
                         GROUP BY f.id
                         $order_clause");
    } else {
        //if ($type == FOLDER_TYPE_RI) {
            $type_id = 0;
        //} else { // Private group folder
        //    $type_id = 1;
        //}
        $res = db_query("SELECT f.id, f.name, f.description,
                         f.creation_date created, f.last_update_date last_updated, count(df.document_id) doc_number
                         FROM folders f
                         LEFT JOIN documents_folders df on f.id = df.folder_id
                         JOIN research_interests ri on ri.id = f.research_interest_id
                         JOIN research_interests_users riu on riu.research_interest_id = ri.id
                         WHERE riu.user_id=$user_id " .
                         //AND ri.type = $type_id
                         "GROUP BY f.id
                         $order_clause");
    }

    $folders = array();

    while ($row = db_fetch_array($res)) {
        $row['created'] = mysda_format_date($row['created']);
        $row['last_updated'] = mysda_format_date($row['last_updated']);
        $folders[] = $row;
    }

    return $folders;
}

function create_folder()
{
    $folder_name = $_POST['folder_name'];
    $folder_desc = $_POST['folder_desc'];

    global $user;

    $res = array();

    $now = db_now();

    $user_id = $user->uid;

    if (trim($folder_name) == '') {
        add_error($res, 'Please provide folder name!');
    } else {

        if (!db_result(db_query("SELECT f.id FROM folders f WHERE f.user_id=%d AND f.name='%s'",
                                $user_id, $folder_name))
        ) {
            if (!db_query("INSERT INTO folders
        (name, description, user_id, creation_date, last_update_date)
        VALUES
        ('%s', '%s', %d, '%s', '%s')",
                          $folder_name, $folder_desc, $user_id, $now, $now)
            ) {
                add_error($res, 'Failed to create folder!');
            }
        } else {
            add_error($res, 'Folder with this name already exists!');
        }
    }
    echo json_encode($res);
    exit();
}

function edit_folder()
{
    $folder_id = $_POST['id'];
    $folder_name = $_POST['folder_name'];
    $folder_desc = $_POST['folder_desc'];

    global $user;

    $res = array();

    $now = db_now();

    $user_id = $user->uid;

    if (!isset($folder_id)) {
        add_error($res, 'No folder id provided!');
    } else {
        if (trim($folder_name) == '') {
            add_error($res, 'Please provide folder name!');
        } else {
            if (!db_query("UPDATE folders SET
        name='%s', description='%s', last_update_date='%s'
        WHERE id=%d AND user_id=%d",
                          $folder_name, $folder_desc, $now,
                          $folder_id, $user_id)
            ) {
                add_error($res, 'Failed to update folder!');
            }
        }
    }
    echo json_encode($res);
    exit();
}

function remove_folder()
{
    $folder_ids = $_POST['ids'];

    global $user;

    $res = array();

    $user_id = $user->uid;

    if (!isset($folder_ids)) {
        add_error($res, 'No folder ids provided!');
    } else {
        if (!db_query("DELETE FROM folders
        WHERE id in (%s) AND user_id=%d",
                      $folder_ids, $user_id) // TODO: protect from SQL INJ
        ) {
            add_error($res, 'Failed to remove folder!');
        }
    }
    echo json_encode($res);
    exit();
}

function remove_folder_document()
{
    $folder_id = $_POST['folder_id'];
    $document_ids = $_POST['ids'];

    $res = array();

    if (!isset($document_ids)) {
        add_error($res, 'No document ids provided!');
    } else {
        if (!db_query("DELETE FROM documents_folders
        WHERE document_id in (%s) AND folder_id=%d",
                      $document_ids, $folder_id) // TODO: protect from SQL INJ
        ) {
            add_error($res, 'Failed to remove documents!');
        }
    }
    echo json_encode($res);
    exit();
}

function copy_document_to_folder() {
    global $user;
    $folder_id = $_POST['folder_id'];
    $document_ids = $_POST['ids'];

    $res = array();

    if (!isset($document_ids)) {
        add_error($res, 'No document ids provided!');
    } else {
        // Delete these documents from the destination folder. (To avoid duplicates and update save_date field.)
        $query = "DELETE FROM documents_folders WHERE folder_id = $folder_id AND document_id IN (";
        foreach ($document_ids as $document_id) {
            $query .= "$document_id,";
        }
        $query = substr($query, 0, strlen($query) - 1);
        $query .= ')';
        if (!db_query($query) // TODO: protect from SQL INJ
        ) {
            add_error($res, 'Failed to copy documents!');
        }

        // Insert documents into the destination folder.
        $query = "INSERT INTO documents_folders(document_id, folder_id, save_date) VALUES";
        $current_date = db_now();
        foreach ($document_ids as $document_id) {
            $query .= "($document_id, $folder_id, '$current_date'),";
        }
        $query = substr($query, 0, strlen($query) - 1);

        if (!db_query($query) // TODO: protect from SQL INJ
        ) {
            add_error($res, 'Failed to copy documents!');
        }

        // Insert notifications.
        $result = db_fetch_array(db_query("SELECT research_interest_id FROM folders WHERE id = %d", $folder_id));
        $ri = $result['research_interest_id'];
        if (empty($ri)) {
            exit;
        }
        $results = db_query("SELECT user_id FROM research_interests_users WHERE research_interest_id = %d", $ri);
        while ($result = db_fetch_array($results)) {
            if ($result['user_id'] == $user->uid) {
                // Don't send the notification to the user that generated this event.
                continue;
            }
            insert_notification(NOTIFICATION_ADD_DOCUMENT_TO_RI_FOLDER, $result['user_id'], $user->uid, $folder_id);
        }
    }
    echo json_encode($res);
    exit();
}

function move_document_to_folder() {
    global $user;
    $from_folder_id = $_POST['from_folder_id'];
    $to_folder_id = $_POST['to_folder_id'];
    $document_ids = $_POST['ids'];

    $res = array();

    if (!isset($document_ids)) {
        add_error($res, 'No document ids provided!');
    } else {
        // Delete these documents from the destination folder. (To avoid duplicates and update save_date field.)
        $query = "DELETE FROM documents_folders WHERE folder_id = $to_folder_id AND document_id IN (";
        foreach ($document_ids as $document_id) {
            $query .= "$document_id,";
        }
        $query = substr($query, 0, strlen($query) - 1);
        $query .= ')';
        if (!db_query($query) // TODO: protect from SQL INJ
        ) {
            add_error($res, 'Failed to copy documents!');
        }

        // Insert documents into the destination folder.
        $query = "INSERT INTO documents_folders(document_id, folder_id, save_date) VALUES";
        $current_date = db_now();
        foreach ($document_ids as $document_id) {
            $query .= "($document_id, $to_folder_id, '$current_date'),";
        }
        $query = substr($query, 0, strlen($query) - 1);

        if (!db_query($query) // TODO: protect from SQL INJ
        ) {
            add_error($res, 'Failed to copy documents!');
        }

        // Delete documents from the source folder.
        $query = "DELETE FROM documents_folders WHERE folder_id = $from_folder_id AND document_id IN (";
        foreach ($document_ids as $document_id) {
            $query .= "$document_id,";
        }
        $query = substr($query, 0, strlen($query) - 1);
        $query .= ')';
        if (!db_query($query) // TODO: protect from SQL INJ
        ) {
            add_error($res, 'Failed to copy documents!');
        }

        // Insert notifications.
        $result = db_fetch_array(db_query("SELECT research_interest_id FROM folders WHERE id = %d", $to_folder_id));
        $ri = $result['research_interest_id'];
        if (empty($ri)) {
            exit;
        }
        $results = db_query("SELECT user_id FROM research_interests_users WHERE research_interest_id = %d", $ri);
        while ($result = db_fetch_array($results)) {
            if ($result['user_id'] == $user->uid) {
                // Don't send the notification to the user that generated this event.
                continue;
            }
            insert_notification(NOTIFICATION_ADD_DOCUMENT_TO_RI_FOLDER, $result['user_id'], $user->uid, $to_folder_id);
        }
    }
    echo json_encode($res);
    exit();
}

function folder_documents()
{
    $folder_id = $_POST['folder_id'];
    $sort_by = $_POST['sort_by'];
    $order = $_POST['order'];

    $l = array();

    if (trim($sort_by) != '') {
        $order_clause = " ORDER BY $sort_by $order ";
    } else {
        $order_clause = '';
    }

    // TODO
    $res = db_query(
        "SELECT a.average_avg_rating rating,
                a.field_autors_value author,
                a.field_doc_id_value document_id,
                a.field_date_value publication_date,
                a.field_recipient_value recipient,
                a.relevancy,
                a.field_subject_value subject,
                n.title,
                a.field_views_count views_count,
                df.save_date save_date,
                a.nid id
    FROM node_view n LEFT JOIN content_type_archive a
    ON a.nid = n.nid
    JOIN documents_folders df on df.document_id=n.nid
    WHERE df.folder_id=%d $order_clause", $folder_id);

    while ($d = db_fetch_array($res)) {
        $d['save_date'] = mysda_format_date($d['save_date']);
        foreach($d as $key => &$field){
            if(!$field) $field = 'N/A';
        }
        $l[] = $d;
    }

    $folder = db_fetch_array(db_query("SELECT f.id, f.name, f.description, f.user_id, f.research_interest_id/*, f.is_content_editable, ri.type*/
    FROM folders f LEFT JOIN research_interests ri ON ri.id = f.research_interest_id WHERE f.id=%d", $folder_id));

    if (empty($folder)) {
        echo "Sorry, this folder doesn't exist.";
        exit;
    }

    $result = db_fetch_array(db_query("SELECT creator_id FROM research_interests WHERE id = %d", $folder[research_interest_id]));
    global $user;
    $owner_mode = ($result['creator_id'] == $user->uid);

    $query="SELECT f.name as name, f.id as id from folders f WHERE f.user_id={$user->uid}";
    $user_folders=array();
    $results=db_query($query);
    while ($result=db_fetch_array($results)){
        $user_folders[]=$result;
    }

    if (is_admin()) {
        // Select all research interest folders.
        $query="SELECT f.name as name, f.id as id from folders f
                JOIN research_interests ri ON ri.id = f.research_interest_id";
                //WHERE ri.type = 0";
        $results=db_query($query);
    } else {
        // Select folders of the research interests that user is member of.
        $query="SELECT f.name as name, f.id as id from folders f
        JOIN research_interests ri ON ri.id = f.research_interest_id
        JOIN research_interests_users riu ON riu.research_interest_id = ri.id
        WHERE riu.user_id = %d";// AND ri.type = 0";
        $results=db_query($query, $user->uid);
    }
    $ri_folders=array();
    while ($result=db_fetch_array($results)){
        $ri_folders[]=$result;
    }

    /*if (is_admin()) {
        // Select all private group folders.
        $query="SELECT f.name as name, f.id as id from folders f
                JOIN research_interests ri ON ri.id = f.research_interest_id
                WHERE ri.type = 1";
        $results=db_query($query);
    } else {
        // Select folders of the private groups that user is member of.
        $query="SELECT f.name as name, f.id as id from folders f
        JOIN research_interests ri ON ri.id = f.research_interest_id
        JOIN research_interests_users riu ON riu.research_interest_id = ri.id
        WHERE riu.user_id = %d AND ri.type = 1";
        $results=db_query($query, $user->uid);
    }
    $private_folders=array();
    while ($result=db_fetch_array($results)){
        $private_folders[]=$result;
    }*/

    echo tpl('my_sda', 'my_sda_folder_documents',
             array(
                  'folder' => $folder,
                  'documents' => $l,
                  'owner_mode' => $owner_mode,
                  'sort_by' => $sort_by,
                  'user_folders' => $user_folders,
                  'ri_folders' => $ri_folders//,
                  //'private_folders' => $private_folders
             ));
    exit();
}

function select_fields_to_view_form_folder_documents(){
    if (!session_id()) {
        session_start();
    }
    if (isset ($_SESSION['folder_view_options'])) {
        $options=$_SESSION['folder_view_options'];
    } else {
        $options=array('title','author','publication_date','save_date');
        $_SESSION['folder_view_options'] = $options;
    }
    $form['fields_to_view'] = array(
    '#type' => 'checkboxes',
    '#title' => '<b>Document fields</b>',
    '#options' => array(
        'title'=> 'Title',
        'rating' => 'Avg. Rating',
        'author'=>'Author',
        'document_id' => 'ID',
        'publication_date' => 'Pub. Date',
        'recipient' => 'Recipients',
        'relevancy' => 'Relevancy',
        'subject' => 'Subject',
        'views_count' => '# of Views',
        'save_date'=>'Date Saved'
        ),
    '#default_value'=>$options,
    '#prefix' => '<div id="select_fields_to_view">',
    '#suffix' => '</div>',
    );

return $form;
}

function save_folder_view_options() {
    $options = $_POST['options'];
    $_SESSION['folder_view_options'] = $options;
}

function edit_folder_description() {
    $folder_id = $_POST['folder_id'];
    $description = $_POST['description'];

    db_query("UPDATE folders SET description = '%s' WHERE id = %d", $description, $folder_id);
}

function get_document_ids_for_folder($folder_id) {
    $docs = array();
    $result = db_query("SELECT DISTINCT document_id FROM documents_folders WHERE folder_id = %d", $folder_id);
    while ($doc = db_fetch_array($result)) {
        $docs[] = $doc['document_id'];
    }

    return join(",", $docs);
}

function get_copy_move_popup_html($popup_type, $source_folder, $user_folders, $ri_folders) {//, $private_folders) {
    $out = '<div id="popup_' . $popup_type . '_document_to_folder" class="hidden">
        <div class="popup_header">'. ucfirst($popup_type) . ' to Folder
        <img alt="Close" src="' . base_path() . 'sites/all/themes/stalin/images/cross_close.png">
        </div>
        <div class="popup_body">
        <div class="popup_body_title">Choose destination folder:<p/></div>
        <div class="popup_body_select" id="folder_select">
        <select name="folder" id="folder_to_' . $popup_type . '_to_select" style="width:240px">';

    // Show personal folders.
    if ((count($user_folders) > 1) || (count($user_folders) == 1 && empty($source_folder['research_interest_id']))) {
        $out .= '<option value="0" disabled="disabled" selected="selected">Personal Folders:</option>';
        foreach ($user_folders as $user_folder){
            if ($user_folder['id'] != $folder['id']) {
                $out .= '<option value="'.$user_folder['id'].'">'.$user_folder['name'].'</option>';
            }
        }
    }
    // Show ri folders.
    if ((count($ri_folders) > 1) || (count($ri_folders) == 1 && $source_folder['type'] != 0)) {
        $out .= '<option value="0" disabled="disabled">Public Folders:</option>';
        foreach ($ri_folders as $ri_folder){
            if ($ri_folder['id'] != $folder['id']) {
                $out .= '<option value="'.$ri_folder['id'].'">'.$ri_folder['name'].'</option>';
            }
        }
    }
    // Show private group folders.
    /*if ((count($private_folders) > 1) || (count($private_folders) == 1 && $source_folder['type'] != 1)) {
        $out .= '<option value="0" disabled="disabled">Private Folders:</option>';
        foreach ($private_folders as $private_folder){
            if ($private_folder['id'] != $folder['id']) {
                $out .= '<option value="'.$private_folder['id'].'">'.$private_folder['name'].'</option>';
            }
        }
    }*/
    $out .= '</select>
        <p/>
        </div>
        <div class="popup_body_buttons">
        <input type="button" value="Cancel" class="popup_button" onclick="closePopup();"/>'
        .((ucfirst($popup_type)=='Move') ?
        '<input type="button" value="' . ucfirst($popup_type) . '" class="popup_button" onclick="' . $popup_type . '_document_to_folder(value_list(\'.folder_documents_list .check_one:checked\'), document.getElementById(\'folder_id\').value, document.getElementById(\'folder_to_' . $popup_type . '_to_select\').value);"/>' :
        '<input type="button" value="' . ucfirst($popup_type) . '" class="popup_button" onclick="' . $popup_type . '_document_to_folder(value_list(\'.folder_documents_list .check_one:checked\'), document.getElementById(\'folder_to_' . $popup_type . '_to_select\').value);"/>')
        .'</div></div></div>';

    return $out;

}
