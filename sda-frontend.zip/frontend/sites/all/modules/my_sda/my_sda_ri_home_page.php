<?php

define('MEMBERS_PER_PAGE', 20);

function edit_research_interest_name() {
    $riId = $_POST['riId'];
    $name = $_POST['name'];

    // Update RI name.
    $query = "UPDATE research_interests SET name = '{$name}' WHERE id = {$riId}";
    db_query($query);

    // Update RI forum name.
    $query = "UPDATE forums SET name = '{$name}' WHERE research_interest_id = {$riId}";
    db_query($query);

    // Update RI folder name.
    $query = "UPDATE folders SET name = '{$name}' WHERE research_interest_id = {$riId}";
    db_query($query);
}

function edit_research_interest_description() {
    $riId = $_POST['riId'];
    $description = $_POST['description'];

    // Update RI description.
    $query = "UPDATE research_interests SET description = '{$description}' WHERE id = {$riId}";
    db_query($query);

    // Update RI forum name.
    //$query = "UPDATE forums SET name = '{$name}' WHERE research_interest_id = {$riId}";
    //db_query($query);

    // Update RI folder name.
    //$query = "UPDATE folders SET name = '{$name}' WHERE research_interest_id = {$riId}";
    //db_query($query);
}

function echo_ri_content() {
    $ri=$_POST['ri'];
    echo create_research_home_content($ri);
}

function is_member($ri) {
    global $user;
    $query="SELECT * FROM research_interests_users
    WHERE research_interest_id={$ri} AND
    user_id={$user->uid}";
    $result=db_query($query);
    if ($result->num_rows) return true;
    else return false;
}

function create_research_home_content($ri) {
    global $user;
    $index = 0;
    $query="SELECT * FROM research_interests WHERE id={$ri}";
    $research=db_fetch_array(db_query($query));

    if (empty($research)) {
        //return "Sorry, this research interest or private group doesn't exist.";
        return "Sorry, this research interest doesn't exist.";
    }
    /*if ($research['type'] == 1) {
        $query="SELECT * FROM research_interests_users WHERE research_interest_id={$ri} AND user_id={$user->uid}";
        $riu=db_fetch_array(db_query($query));
        if (empty($riu)) {
            return "Sorry, the content of this private group is only available to members.";
        }
    }*/

    $out.='
    <input type="hidden" id="ri_id" value="'.$ri.'">
    <div class="cell_title">
            <div id="results_title"><div class="ri_title">
            <span id="ri_title">'.$research['name'].'</span>';
    if (user_access('Edit Name/Description of RI')) {
        $out .= '<textarea style="display: none" id="ri_title_edit" rows="1" cols="50"></textarea>
                <input type="button" value="Edit" id="lnk_edit_title" onclick="edit_research_interest_name(this, true);"/>
                <input type="button" value="Save" id="lnk_save_title" onclick="edit_research_interest_name(this, false);" style="display: none"/>';
    }
    $out.=  '</div>';
    if (is_member($ri))$out.='<div class="member_join">Member</div>';
    else $out.='<div class="member_join"><input type="button" onclick="join_research_interest(\''.$ri.'\',\'all\',\'creation_date\',\'desc\'); return false;" value="Join"></div>';
    $out.='<div class="back_to_ri">
        <a href="#page=' . /*($research['type'] == 0 ?*/ 'ri_list' /*: 'pg_list')*/ . '">&#9668; Back to ' . /*($research['type'] == 0 ?*/ 'Research Interests' /*: 'Private Groups')*/ . '</a></div>';
    $out.='</div></div>';
    $out.='<div class="hidden" id="ri_id">'.$ri.'</div>';
    $out.='<div class="ri_description"><div class="ri_description_title">Description</div>
    <span id="ri_description">' . $research['description'] . '</span>';
    if (user_access('Edit Name/Description of RI')) {
        $out .= '<textarea style="display: none" id="ri_description_edit" rows="2" cols="50"></textarea>
                <input type="button" value="Edit" id="lnk_edit_description" onclick="edit_research_interest_description(this, true);"/>
                <input type="button" value="Save" id="lnk_save_description" onclick="edit_research_interest_description(this, false);" style="display: none"/>';
    }
    $out .= '</div>';
    $blocks = array();
        $blocks[++$index] = create_research_home_content_block('recent_discussion', $index, $ri, $research);
        $blocks[++$index] = create_research_home_content_block('recent_documents', $index, $ri, $research);
        $blocks[++$index] = create_research_home_content_block('recent_annotations', $index, $ri, $research);
        $blocks[++$index] = create_research_home_content_block('tags', $index, $ri, $research);
        $blocks[++$index] = create_research_home_content_block('members', $index, $ri, $research);

    $out.='<div id="my_sda_ri_home_top"><ul class="connectedSortable">'.$blocks[1].'</ul></div>';
        $out .= '<div id="my_sda_ri_home_center"><ul class="connectedSortable">';

        foreach ($blocks as $id => $block)
        {
            if ($id == 4)
            {
              $out .= '</ul></div>';
              $out .= '<div id="my_sda_ri_home_right"><ul class="connectedSortable">';
            }
          if ($id!=1)
            $out .= $block;
        }
        $out.='</ul></div>';
    $out .= "<div class='clear'></div>";
    return $out;
}

function create_research_home_content_block($selector, $index, $ri, $research) {
    global $user;
    global $base_url;
    $out = '<li id="sortable_'.$selector.'" class="sortable-'.$index.'">';
        $out .= '<div id="my_sda_ri_home_'.$selector.'" class="my_sda_ri_home_block">';
            $out .= '<div class="my_sda_ri_home_block_header">';
                switch($selector){
                    case 'recent_discussion':
                        $out .= '<h2>'.t('Recent Discussions').'</h2>';
                    break;
                    case 'recent_documents':
                        $out .= '<h2>'.t('Recently Shared Documents').'</h2>';
                    break;
                    case 'members':
                        $out .= '<h2>'.t('Members').' ('.get_members_count_ri($ri).')';
                        if (is_member($ri)) $out .= '<img style="cursor: pointer; padding-left: 5px; padding-right: 1px; vertical-align: middle;" height="13px" width="13px" src="' . base_path() . 'sites/all/themes/stalin/images/cross_close.png" onclick="leave_research_interest(\''.$ri.'\',\'my\',\'join_date\',\'desc\'); return false;"></img><a style="font-size:10px" href="#" onclick="leave_research_interest(\''.$ri.'\',\'my\',\'join_date\',\'desc\'); return false;">Leave this ' . /*($research['type'] == 0 ?*/ 'Research Interest' /*: 'Private Group')*/ . '</a></h2>';
                    break;
                    case 'recent_annotations':
                        $out .= '<h2>'.t('Recent Annotations').'</h2>';
                    break;
                    case 'tags':
                    $out .= '<h2>'.t('Tags').'</h2>';
                    break;
                }

            $out .= '</div>';
            $out .= '<div class="my_sda_ri_home_block_content">';
            switch($selector) {
                case 'recent_discussion':
                    $discussions = array();
                    $discussions = get_recent_discussions_for_ri($ri);
                    if (!empty($discussions)) {
                        $out .= '<table id="ri_recent_discussion">';
                        $out .= '<tr><th class="post not_sortable">POST</th>';
                        $out .= '<th class="topic not_sortable">TOPIC</th>';
                        $out .= '<th class="latest_reply not_sortable">LATEST REPLY</th></tr>';

                        foreach($discussions as $discussion) {
                            $out .= '<tr><td>
                            <a href="#page=discussions&topic='.$discussion['topic_id'].
                            '&post='.$discussion['id'].'">'.crop($discussion['text'],90).
                            '</a></td>';
                            $out .= '<td><a href="#page=discussions&topic='.$discussion['topic_id'].'">
                            '.crop($discussion['title'],30).'</a></td>';
                            $out .= '<td><div><a href="#"
                            onclick="show_prew_user_info_popup('.$discussion['creator_id'].'); return false;">'
                            .get_apropriate_user_name($discussion['creator_id'])
                            .'</a></div><div>'
                            .mysda_format_date($discussion['latest_reply_date']).'</div></td></tr>';
                        }
                        $out .= '</table>';
                        $forum_id = $discussion['forum_id'];
                    } else {
                        $out .= '<div class="havent">' . /*($research['type'] == 0 ?*/ 'Research Interest' /*: 'Private Group')*/ . ' doesn\'t have any recent discussions.</div>';
                        $forum_id = get_forum_for_ri($ri);
                    }
                    $out .= '<div class="ri_right_link"><a href="#page=discussions&forum='.$forum_id.'">See all Discussions for this ' . /*($research['type'] == 0 ?*/ 'Research Interest' /*: 'Private Group')*/ . '</a></div>';
                    break;

                case 'recent_documents':
                    $documents = get_recent_documents_for_ri($ri);

                    $results = db_fetch_array(db_query("SELECT * FROM research_interests_users WHERE research_interest_id = %d AND user_id = %d", $ri, $user->uid));
                    $is_member = !empty($results);

                    $access_to_add = user_access('Add Documents to RI Folder');
                    if ($is_member && $access_to_add) {

                        $out .= '<div class="share_doc"><input type="button" value="Share Document" onclick="show_popup(\'add_document_to_ri\');"></div>';
                        $query = "SELECT f.name as name, f.id as id FROM folders f WHERE f.user_id={$user->uid}";
                        $user_folders = array();
                        $results = db_query($query);
                        while ($result = db_fetch_array($results)){
                            $user_folders[] = $result;
                        }
                        $out .= '<div id="popup_add_document_to_ri" class="hidden">
                        <div class="popup_header">Share document'
                        .'<img alt="Close" src="'.base_path().'sites/all/themes/stalin/images/cross_close.png">'
                        .'</div>'
                        .'<div class="popup_body">';
                        $out .= '<div class="popup_body_title"><b>Select a document from your personal folders to share with '.get_research_interest_name($ri).'</b></div><p/>';
                        $out .= '<div class="popup_body_title"><b>Choose folder:</b></div>';
                        $out .= '<div class="popup_body_select" id="folder_select"> <select name="folder" id="folder">';
                        $out .= '<option value="0" disabled="disabled" selected="selected">Select</option>';
                        foreach ($user_folders as $user_folder) {
                            $out .= '<option value="'.$user_folder['id'].'">'.$user_folder['name'].'</option>';
                        }
                        $out .= '</select></div>';
                        $out .= '<p/><div class="popup_body_title"><b>Select document:</b></div>';
                        $out .= '<div class="popup_body_select" id="document_select"> <select name="document" id="document">';
                        $out .= '<option value="0" disabled="disabled" selected="selected">Select</option>';
                        $out .= '</select></div><p/>';
                        $out .= '<div class="popup_body_buttons">';
                        $out .= '<input type="button" class="popup_button" value="Share Document" onclick="add_document_to_ri();"/>';
                        $out .= '<input type="button" class="popup_button" value="Cancel" onclick="closePopup();"/>';
                        $out .= '</div></div></div>';
                    }
                    $out .= '<table id="ri_recent_documents">';

                    $access_to_delete = user_access('Delete Documents from RI Folder');
                    foreach($documents as $document) {
                        if (is_admin()) {
                            if ((/*$ri['type'] == 0 &&*/ $access_to_delete)/* ||
                                ($ri['type'] == 1 && $document['is_content_editable'] == 1) ||
                                ($ri['type'] == 1 && $document['is_content_editable'] == 0) && $ri['creator_id'] == $user->uid*/) {
                                    $out .= '<tr id="doc_'.$document['id'].'"><td class="remove"><a href="#" onclick="delete_document_from_ri('.$document['id'].'); return false;"><img alt="Remove" src="'.base_path().'sites/all/themes/stalin/images/cross_close.png"></a></td>';
                            }
                        }
                        $out .= '<td class="title"><a href="javascript:void(0)" onclick="open_document(\''.$base_url.'/sda_viewer?n='.$document['id'].'\')">'.$document['title'].'</a></td>';
                        $out .= '<td class="date">'.mysda_format_date($document['save_date']).'</div></td></tr>';
                    }
                    $out .= '</table>';
                    $result = db_fetch_array(db_query("select id from folders where research_interest_id = %d", $ri));
                    $ri_folder_id = $result['id'];
                    $out .= '<div class="ri_left_link"><a href="#page=folder&id='.$ri_folder_id.'">Go to ' . /*($research['type'] == 0 ?*/ 'Research Interest' /*: 'Private Group')*/ . ' Folder</a></div>';
                    break;

                case 'members':
                    $out .= show_ri_members_table($index, $ri);
                    break;

                case 'recent_annotations':
                    $annotations = get_recent_annotations_for_ri($ri);
                    if (!empty($annotations)) {
                        $out .= '<div class="ri_annotations">';
                        foreach ($annotations as $annotation){
                            $out .= '<div class="ri_annotation">';
                            $out .= '<div class="title"><a href="'.$base_url.'/sda_viewer?n='.$annotation['document_id'].'&t=ann&id='.$annotation['id'].'\'">'.$annotation['title'].'</a></div>';
                            $out .= '<div class="text">'.crop($annotation['text'],100).'</div>';
                            $out .= '<div class="user"><a href="#" onclick="show_prew_user_info_popup('.$annotation['creator_id'].')">'.get_apropriate_user_name($annotation['creator_id']).'</a></div>';
                            $out .= '<div class="date">Last viewed: '.my_formate_date($annotation['creation_date']).'</div>';
                            $out .= '</div>';
                        }
                        $out .= '</div>';
                    } else {
                        $out .= '<div class="havent">' . /*($research['type'] == 0 ?*/ 'Research Interest' /*: 'Private Group')*/ . ' doesn\'t have any recent annotations.</div>';
                    }
                    break;

                case 'tags':
                    $tags = get_recent_tags_for_ri($ri);
                    foreach ($tags as $tag) {
                        $out .= '<div class="rbroundbox">
                                    <div class="rbtop"><div></div></div>
                                        <div class="rbcontent">
                                            &nbsp;' .
                                            //<a href="#page=docs_by_tags&tags='.$tag['name'].'">'.$tag['name'].'</a>
                                            //'<a href="' .$base_url. '/sda_viewer?n=' . $tag['document_id'] .'&t=tag&id='. $tag['id'] . '">' . $tag['name'] . '</a>'
                                            '<a href="' . $base_url . '/node/2#T#' . $tag['name'] . '#' . $tag['lang'] . '">' . $tag['name'] . '</a>'
                                            . '&nbsp;
                                        </div><!-- /rbcontent -->
                                    <div class="rbbot"><div></div></div>
                                </div>&nbsp;&nbsp;';
                    }
                    break;
            }
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</li>';

    return $out;
}

function get_recent_tags_for_ri($ri) {
    global $user;
    /*$query = "
            SELECT DISTINCT t.name, t.document_id, t.id
            FROM tags t
            WHERE (t.is_public = '1' OR  t.user_id='%d')
            AND t.document_id in (select document_id from documents_folders df where df.folder_id in (select id from folders where research_interest_id = %d))
            ORDER BY t.creation_date DESC
            LIMIT 10";*/

    /*$query = "
            SELECT t.name, t.document_id, t.id FROM (
            SELECT name, min(id) minid FROM tags
            WHERE (is_public = '1' OR  user_id='%d')
            AND document_id in (select document_id from documents_folders df where df.folder_id in (select id from folders where research_interest_id = %d))
            GROUP BY name) AS x
            JOIN tags t ON t.name = x.name AND t.id = x.minid
            ORDER BY t.creation_date DESC
            LIMIT 10";*/

    $query = "
            SELECT DISTINCT name, lang
            FROM tags
            WHERE (is_public = '1' OR  user_id='%d')
            AND document_id in (select document_id from documents_folders df where df.folder_id in (select id from folders where research_interest_id = %d))
            ORDER BY creation_date DESC
            LIMIT 10";

    return db_get_list(db_query($query, $user->uid, $ri));
}

function get_research_interest_name($ri) {
    $result = db_fetch_array(db_query("SELECT name FROM research_interests WHERE id = %d", $ri));
    return $result['name'];
}

function get_recent_annotations_for_ri($ri) {
    $annotations = array();

    $query = "SELECT d.title, d.nid as document_id, a.id as annotation_id, a.text, a.creator_id, a.creation_date, a.id FROM node_view d
    JOIN annotations a ON a.document_id = d.nid
    JOIN documents_folders df ON df.document_id=d.nid
    JOIN folders f ON df.folder_id=f.id
    WHERE f.research_interest_id={$ri} and a.is_public = '1'
    ORDER BY a.creation_date
    LIMIT 3";

    $results = db_query($query);
    while ($result = db_fetch_array($results)) {
        $annotations[] = $result;
    }

    return $annotations;
}

function get_recent_discussions_for_ri($ri) {
    $discussions = array();
    $query = "SELECT p.id as id, t.title as title, t.id topic_id, f.id forum_id, p.text as text, p.creation_date as creation_date, p.creator_id as creator_id, t.latest_reply_date FROM forum_topics t
       JOIN forums f ON t.forum_id=f.id
       JOIN forum_posts p ON p.topic_id=t.id
       WHERE f.research_interest_id={$ri}
       ORDER BY p.creation_date DESC
       LIMIT 4";

    $results = db_query($query);
    while ($result = db_fetch_array($results)) {
        $discussions[] = $result;
    }

    return $discussions;
}

function get_forum_for_ri($ri) {
    $result = db_fetch_array(db_query("SELECT id from forums where research_interest_id = %d", $ri));
    return $result['id'];
}

function get_recent_documents_for_ri($ri) {
    $documents = array();
    $query = "SELECT d.title, d.nid as id , df.save_date, f.id folder_id" . /*, f.is_content_editable*/ " FROM node_view d
    JOIN documents_folders df ON df.document_id=d.nid
    JOIN folders f ON df.folder_id=f.id
    WHERE f.research_interest_id={$ri}
    ORDER BY df.save_date DESC
    LIMIT 7";
    $results = db_query($query);
    while ($result = db_fetch_array($results)) {
        $documents[] = $result;
    }

    return $documents;
}

function get_members_ri($ri) {
    $members = array();
    $query = "SELECT DISTINCT ri.user_id as id, u.picture as picture,
    u.mail as mail, pv.value AS first_name, pv1.value AS last_name
    FROM research_interests_users ri
    JOIN users u ON u.uid=ri.user_id
    LEFT OUTER JOIN profile_values pv ON pv.uid = u.uid
        AND pv.fid = '1'
        LEFT OUTER JOIN profile_values pv1 ON pv1.uid = u.uid
        AND pv1.fid = '2'
    WHERE ri.research_interest_id = {$ri}";
    $results = db_query($query);
    while ($result = db_fetch_array($results)) {
        if ($result['first_name']) $result['name'] = $result['first_name'] . ' ' . $result['last_name'];
        else $result['name'] = $result['mail'];
        $members[] = $result;
    }

    return $members;
}

function get_members_count_ri($ri) {
    $result = db_fetch_array(db_query("SELECT count(user_id) number_of_members FROM research_interests_users WHERE research_interest_id = %d", $ri));
    return $result['number_of_members'];
}

function add_document_to_ri() {
    global $user;
    $document_id = $_POST['document_id'];
    $ri = $_POST['ri'];
    $folder = db_fetch_array(db_query("SELECT id FROM folders WHERE research_interest_id={$ri}"));
    $folder_id = $folder['id'];
    $current_date = db_now();

    $query = "DELETE FROM documents_folders WHERE document_id = %d AND folder_id = %d";
    db_query($query, $document_id, $folder_id);

    $query = "INSERT INTO documents_folders (document_id, folder_id, save_date) VALUES ('{$document_id}','{$folder_id}','{$current_date}')";
    db_query($query);

    // Insert notifications.
    $results = db_query("SELECT user_id FROM research_interests_users WHERE research_interest_id = %d", $ri);
    while ($result = db_fetch_array($results)) {
        if ($result['user_id'] == $user->uid) {
            // Don't send the notification to the user that generated this event.
            continue;
        }
        insert_notification(NOTIFICATION_ADD_DOCUMENT_TO_RI_FOLDER, $result['user_id'], $user->uid, $folder_id);
    }

    echo my_formate_date($current_date);
}

function delete_document_from_ri() {
    $document_id = $_POST['document_id'];
    $ri = $_POST['ri'];
    $query = "DELETE FROM documents_folders
    WHERE document_id={$document_id} AND folder_id IN (SELECT id FROM folders WHERE research_interest_id = {$ri})";
    db_query($query);

    echo $query;
}

function invite_member_to_ri() {
    global $user;

    $user_id = $_POST['user_id'];
    $ri_id = $_POST['ri'];

    insert_notification(NOTIFICATION_RI_INVITATION, $user_id, $user->uid, $ri_id);
}

function accept_invitation() {
    $notification_id = $_POST['notification_id'];

    $notification = db_fetch_array(db_query("SELECT * FROM notifications WHERE id = %d", $notification_id));

    // Update notification.
    db_query("UPDATE notifications SET subtype = %d WHERE id = %d", NOTIFICATION_SUBTYPE_RI_INVITATION_ACCEPTED, $notification_id);

    // Send backward notification.
    insert_notification_with_subtype(NOTIFICATION_RI_INVITATION_REPLIED, $notification['from_user_id'], $notification['to_user_id'], $notification['object_id'], NOTIFICATION_SUBTYPE_RI_INVITATION_ACCEPTED);

    // Join RI.
    join_research_interest_inner($notification['object_id']);
}

function decline_invitation() {
    $notification_id = $_POST['notification_id'];

    $notification = db_fetch_array(db_query("SELECT * FROM notifications WHERE id = %d", $notification_id));

    // Update notification.
    db_query("UPDATE notifications SET subtype = %d WHERE id = %d", NOTIFICATION_SUBTYPE_RI_INVITATION_DECLINED, $notification_id);

    // Send backward notification.
    insert_notification_with_subtype(NOTIFICATION_RI_INVITATION_REPLIED, $notification['from_user_id'], $notification['to_user_id'], $notification['object_id'], NOTIFICATION_SUBTYPE_RI_INVITATION_DECLINED);
}

function show_members_pager() {
    $index=$_POST['index'];
    if ($index == null) $index = 0;
    $ri=$_POST['ri'];
    echo create_research_home_content_block('members', $index, $ri, null);
}

function show_ri_members_table($index, $ri) {
    global $base_url;
    global $user;

    $out = '';
    $offset=$_POST['offset'];
    if ($offset == null) $offset = 0;
    $members_array = get_members_ri($ri);
    $members_to_show = (int)((count($members_array) - 1) / MEMBERS_PER_PAGE) + 1;
    $out .= '<table id="ri_members">';
    $tmp_array = array_chunk($members_array, MEMBERS_PER_PAGE, TRUE);
    $members = $tmp_array[$offset];//(array_chunk($members_array, MEMBERS_PER_PAGE))[$offset];
    foreach ($members as $member){
        $out .= '<tr><td class="avatar">';
        if(!empty($member['picture'])) {
            $out .= '<img src="'.$base_url.'/'.$member['picture'].'"/></td>';
        }
        else {
            $out .= "<img alt=\"User image\" src=\"$base_url/sites/default/files/pictures/no_avatar.png\"></td>";
        }
        $out .= '<td class="info">
                    <div class="user"><a href="#" onclick="show_prew_user_info_popup('.$member['id'].'); return false;">'.$member['name'].'</a></div>
                    <div class="institution">'.$member['institution'].'</div>';
        /*if ($research['creator_id'] == $member['id'] && $research['type'] == 1) {
            $out .= '<div class="admin">Owner</div>';
        } else*/ if (is_admin_user_id($member['id'])) {
                    $out .= '<div class="admin">Admin</div>';
                 }
        $out .= '</td></tr>';
    }
    if (user_access('Invite Members to Research Interest')) {
        $out .= '<tr><td><a href="#" onclick="show_popup(\'invite_member\'); enable_autocomplete(); return false;">Invite member</a></td></tr>';

        $query = "SELECT u.uid, u.mail, pv1.value first_name, pv2.value last_name FROM users u
                        LEFT JOIN profile_values pv1 ON pv1.uid = u.uid AND pv1.fid = 1
                        LEFT JOIN profile_values pv2 ON pv2.uid = u.uid AND pv2.fid = 2
                        WHERE u.uid > 0";

        $users = array();
        $results = db_query($query);
        while ($result = db_fetch_array($results)) {
            $users[] = $result;
        }

        $out .= '<div id="popup_invite_member" class="hidden">
                            <div class="popup_header">Invite member'
            .'<img alt="Close" src="'.base_path().'sites/all/themes/stalin/images/cross_close.png">'
            .'</div>'
            .'<div class="popup_body">';
        $out .= '<div class="popup_body_title"><b>Select user to invite to '.get_research_interest_name($ri).'</b></div><p/>';
        $out .= '<div class="popup_body_title"><b>Choose User:</b></div>';
        $out .= '<div class="popup_body_select" id="user_select"> <select name="user" id="user">';
        $out .= '<option value="0" disabled="disabled" selected="selected">Select</option>';
        foreach ($users as $u) {
            if (empty($u['first_name']) && empty($ur['last_name'])) {
                $name = $u['mail'];
            } else {
                $name = $u['first_name'] . ' ' . $u['last_name'];
            }
            $out .= '<option value="'.$u['uid'].'">'.$name.'</option>';
        }
        $out .= '</select></div>';

        $out .= '<div class="popup_body_buttons">';
        $out .= '<input type="button" class="popup_button" value="Invite Member" onclick="if (document.getElementById(\'user\').value != 0) invite_member_to_ri();"/>';
        $out .= '<input type="button" class="popup_button" value="Cancel" onclick="closePopup();"/>';
        $out .= '</div></div></div>';
    }
    $out .= '</table>';
    $out .= create_ri_members_pager($members_to_show, $offset, count($members_array), $ri, $index);
    return $out;
}

function create_ri_members_pager($cur_count, $offset, $total_count, $ri, $index) {
    $out = '';

    if ($cur_count > 1) {
        $out .= '<div style="display:inline; padding-top:2px;" id="pager">';
        $out .= '<span class="current_page" style="width:auto; padding-right:15px; margin-top: 5px;">Results ' . ($offset * MEMBERS_PER_PAGE + 1) . '-' . ((($offset + 1) * MEMBERS_PER_PAGE < $total_count) ? ($offset + 1) * MEMBERS_PER_PAGE : $total_count) . ' of <b>' . $total_count . '</b></span>';
        $out .= '<a href="' . ($offset - 1) .'" onclick="' . ($offset > 0 ? 'show_members_pager(this, '.$ri.', '.$index.');' : '') . 'return false;" style="padding: 0"><span class="first_page_' . ($offset > 0 ? 'active' : 'inactive') . '"></span></a>';

        if ($offset > 2) {
            $out .= '<a href="0" onclick="show_members_pager(this, '.$ri.', '.$index.');return false;"><span class="other_page">1</span></a>';
        }

        if ($offset > 3) {
            $out .= ' ... ';
        }

        for ($i = ($offset - 2); $i < ($offset + 3); $i++) {
            if ($i >= 0 && $i < $cur_count) {
                $out .= '<a href="' . $i . '" onclick="' . ($i != $offset ? 'show_members_pager(this, '.$ri.', '.$index.');' : '') . 'return false;">';
                $out .= '<span class="' . ($i == $offset ? 'current_page' : 'other_page') . '">';
                $out .= ($i + 1);
                $out .= '</span>';
                $out .= ' </a>';
            }
        }

        if ($offset < ($cur_count - 4)) {
            $out .= ' ... ';
        }

        if ($offset < ($cur_count - 3)) {
            $out .= '<a href="' . ($cur_count - 1) . '" onclick="show_members_pager(this, '.$ri.', '.$index.');return false;"><span class="other_page">' . ($cur_count) . '</span></a>';

        }
        $out .= '<a href="' . ($offset + 1) . '" onclick="' . ($offset < $cur_count - 1 ? 'show_members_pager(this, '.$ri.', '.$index.');' : '') . 'return false;"><span class="last_page_' . ($offset < $cur_count - 1 ? 'active' : 'inactive') . '"></span></a>';
        $out .= '</div>';
        return $out;
    }
    return $out;
}

