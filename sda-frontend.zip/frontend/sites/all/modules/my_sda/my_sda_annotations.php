<?php

function get_user_annotations($user_id,$sort_by='creation_date',$order='DESC') {
    if (empty($sort_by)) $sort_by='creation_date';
    if (empty($order)) $order='DESC';
    $annotations=array();
    $query="SELECT annotations.*, node.title as document_title FROM annotations
    JOIN node_view node ON node.nid=annotations.document_id
    WHERE creator_id='{$user_id}' ";
    if ($sort_by!='document_title')$query.="ORDER BY annotations.{$sort_by} {$order}";
    else $query.="ORDER BY {$sort_by} {$order}";
    $results=db_query($query);
    while ($result=db_fetch_array($results)){
        $annotations[]=$result;
    }
    return $annotations;
}

function echo_my_annotations() {
    global $user;
    global $base_url;

    $sort_by = $_POST['sort_by'];
    $order = $_POST['order'];
    $annotations = get_user_annotations($user->uid,$sort_by,$order);
    $out = prepare_hidden_ann_form();
    $out .= '<div class="cell_title">
            <div id="results_title">My Annotations</div>
           </div>';
    $out .= '<div class="results_filter">
                <a class="button_outer_left">
                    <span class="button_outer_right">
                    <span class="button_outer_center">
                    <span class="button_inner">
                        <input class="check_all" type="checkbox" name="empty">
                        <img class="arrow_down" alt="" src="'.$base_url.'/sites/all/themes/stalin/images/arrow_down.png" onclick="show_select_check_all()">
                    </span>
                        <span class="va_middle"></span>
                    </span>
                    </span>
                </a>
                <div style="position:relative;float:left">
                <div id="select_check_all" class="hidden">
                    <div class="select_item select_all">Select All</div>
                    <div class="select_item clear_all">Clear All</div>
                </div>
                </div>
                <a class="button_outer_left" onclick="delete_checked_annotations();return false;" href="#">
                    <span class="button_outer_right"><span class="button_outer_center">
                    <span class="button_inner button_text">Delete</span>
                    <span class="va_middle"></span>
                    </span></span>
                </a>
                <a class="button_outer_left" onclick="show_export_form_popup(\'folder\', \'export_annotation_form\'); return false;" href="#">
                    <span class="button_outer_right"><span class="button_outer_center">
                    <span class="button_inner button_text">Export</span>
                    <span class="va_middle"></span>
                    </span></span>
                </a>
            </div>';
    $out .= '<table cellpadding="0" cellspacing="0" border="0" class="my_sda_result">
                <thead>
                <tr class="header">
                <th class="checkbox_cell"><div class="resize"><div class="va_middle"></div></div></th>
                    <th class="not_sortable"><div class="resize">ANNOTATION<a href="text"></a><div class="va_middle"></div></div></th>
                    <th class="type_annotations document_title"><div class="resize">DOCUMENT<a href="document_title"></a><div class="va_middle"></div></div></th>
                    <th class="type_annotations is_public"><div class="resize">SHARED<a href="is_public"></a><div class="va_middle"></div></div></th>
                    <th class="type_annotations creation_date"><div class="resize">DATE CREATED<a href="creation_date"></a><div class="va_middle"></div></div></th>
                </tr></thead><tbody>';
    foreach ($annotations as $annotation){
        $out .= '<tr><td>';
        if (!$annotation['is_public']) {
            $out .= '<input type="checkbox" class="check_one" value="'.$annotation['id'].'" name="row_check">';
        } else $out .= '<input type="checkbox" class="check_one" value="'.$annotation['id'].'" name="row_check">';
        $out .= '<a class="button_outer_left" style="float: right;" href="'.$base_url.'/sda_viewer?n='.$annotation['document_id'].'&t=ann&id='.$annotation['id'].'">
        <span class="button_outer_right"><span class="button_outer_center">
        <span class="button_inner">Edit</span>
        <span class="va_middle"></span>
        </span>
        </a></td>';
        $out .= '<td><a href="'.$base_url.'/sda_viewer?n='.$annotation['document_id'].'&t=ann&id='.$annotation['id'].'">'.$annotation['text'].'</a></td>';
        $out .= '<td><a href="'.$base_url.'/sda_viewer?n='.$annotation['document_id'].'">'.$annotation['document_title'].'</a></td>';
        if ($annotation['is_public']) $out.='<td>Public</td>';
        else $out .= '<td>Personal</td>';
        $out .= '<td>'.mysda_format_date($annotation['creation_date']).'</td></tr>';
    }
    $out .= '</tbody></table>';

    echo $out;
}

function remove_checked_annotations() {
    $post_annotations = $_POST['check_arr'];
    if (count($post_annotations) > 1) {
        $annotations = implode(', ',$post_annotations);
    }
    else $annotations = $post_annotations[0];
    $query = "DELETE FROM annotations WHERE id IN ({$annotations})";
    $result = db_query($query);

    echo $result;
}