$(document).ready(function() {

    toggle_preview();

    $.fn.my_sda_docs_callback = function() {
        var object = $(this);
        object.removeClass('hidden');
        $('#search_results').addClass('hidden');
        //zotero update
        //update_zotero();
        return object;
    };

    $.fn.my_sda_snippets_callback = function() {
        var object = $(this);
        object.find('.two_buttons').removeClass('hidden');
        object.find('.show_select_folders_to_move').click(function() {
            $(this).parent().next().toggleClass('hidden')
        });

        return object;
    };

    //$('#my_sda_home_recent_views').my_sda_recent_viewed_snippets_callback();

    $.fn.my_recent_activity_callback = function() {
        var object = $(this);
        processDivHeight(object.find('#recent_activity_body'));
        return object;
    };

    $(window).resize(function() {
        if ($('#recent_activity_body').length)
            processDivHeight($('#recent_activity_body'))
    });

    make_sortable();
    make_clickable_home_blocks();

    recalcHeight();

    poll_hash();
    setInterval(poll_hash, 100);
});

function show_my_sda_home_page() {
    var url = 'my_sda_home_content';
    $.get(url, function(data) {
        $('#my_sda_docs').html(data).my_sda_docs_callback();
        make_sortable();
        make_clickable_home_blocks();
    });
}

function recalcHeight() {
    $('#my_sda_home_center').height('auto');
    $('#my_sda_home_right').height('auto');

    var my_sda_home_center_height = $('#my_sda_home_center').height();
    var my_sda_home_right_height = $('#my_sda_home_right').height();
    if (my_sda_home_center_height < my_sda_home_right_height)
        $('#my_sda_home_center').height(my_sda_home_right_height);
    else
        $('#my_sda_home_right').height(my_sda_home_center_height);
}

function setCookie(c_name, value) {
    var exdays = 365;
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + exdays);
    var c_value = escape(value) + ((exdays == null) ? "" : "; expires=" + exdate.toUTCString());
    document.cookie = c_name + "=" + c_value;
}

function show_my_saved_searches(sort_by, order) {
    $.post("show_my_saved_searches", {sort_by:sort_by,order:order}, function(data) {
        //$('#search_results').html(data);
        //$('#sidebar-right').hide();
        $('#my_sda_docs').html(data);
        make_resizable(".my_sda_result th div.resize");
        console.log($('.my_sda_result th.' + sort_by));
        $('.my_sda_result th.' + sort_by).addClass('sorted');
        if (order == 'desc') $('.my_sda_result th.' + sort_by).addClass('reversed');
        //add_scroll()
    });
    return false;
}

function view_profile(id, back_link) {
    $.post("render_profile_page", {id: id, back_link: back_link}, function(data) {
        $('#my_sda_docs').html(data);
    });
}

function show_my_tags() {
    $.get("my_tags", function(data) {
        $('#my_sda_docs').html(data);
    });
}

function show_docs_for_tagstr(tag_str, sort_by, order) {
    $.get("docs_by_tag?" + tag_str + '&sort_by=' + sort_by + '&order=' + order, function(data) {
        $('#my_sda_docs').html(data);
        $(".table_header th").each(function() {
            var curr_width = $(this).innerWidth();
            var curr_td = $($(this).parents("div.table_header").next().find("tr:first td").get($(this).index()));
            curr_td.width(curr_width - 12);
            console.log(curr_width);
        });
        make_resizable(".my_sda_result th div.resize", null, 'table.search_result:last tr:first td', resizable_texts);

        $('.my_sda_result th.' + sort_by).addClass('sorted');
        if (order == 'desc') $('.my_sda_result th.' + sort_by).addClass('reversed');

        apply_view_options_tags_documents();
    });
}

function toggle_tag(id) {
    var tag = $("#tag" + id);
    var tag_tree = $("#tag" + id + " *");
    var ref = $("#ref" + id);

    if (tag.css('visibility') == 'hidden') {
        tag.css('visibility', 'visible');
        tag.css('position', 'relative');
        ref.html('&#9660;');
    } else {
        tag_tree.each(function() {
            if (this.style.visibility == 'visible') {
                this.style.visibility = '';
                this.style.position = '';
            }
        });
        tag.css('visibility', 'hidden');
        tag.css('position', 'absolute');
        ref.html('&#9658;');
    }
}

function toggle_preview() {
    $('#sidebar-right').toggleClass('hidden');
}

function show_my_sda_home_discussions(obj) {
    var selector = $(obj).attr('href');
    var url = 'show_my_sda_home_discussions';
    if (selector == 'my_latest_posts') {
        $('#a_my_latest_posts').hide();
        $('#a_newest_discussions').show();
        $('#span_my_latest_posts').show();
        $('#span_newest_discussions').hide();
    } else {
        $('#a_my_latest_posts').show();
        $('#a_newest_discussions').hide();
        $('#span_my_latest_posts').hide();
        $('#span_newest_discussions').show();
    }
    $.post(url, {selector:selector}, function(data) {
        $('#home_discussions_list').html(data)
    });
    return false;
}

function delete_notification(id) {
    var url = 'delete_my_sda_notification';
    $.post(url, {id:id}, function() {
        show_notifications();
    });
}

function open_document(node_path) {
    //window.open(node_path);
    window.location = node_path;
    return false;
}

function processDivHeight(obj) {
    var win_height = ($(window).height());
    $(obj).height((win_height - 246) + "px");
}

function show_folders(type, sort_by, order) {
    sort_by = sort_by || '';
    order = order || '';

    $.post('folders', {
        type: type,
        sort_by: sort_by,
        order: order
    }, function (data) {
        $('#my_sda_docs').html(data);

        make_resizable('.my_sda_result div.resize');

        draw_sort_direction('.my_sda_result th.sort_by_' + sort_by, order);
    });
}

function show_folder_documents(folder_id, sort_by, order) {
    sort_by = sort_by || '';
    order = order || '';

    $.post('folder_documents', {
        folder_id: folder_id,
        sort_by: sort_by,
        order: order
    }, function (data) {
        $('#my_sda_docs').html(data);

        make_resizable('.my_sda_result div.resize');

        draw_sort_direction('.my_sda_result th.sort_by_' + sort_by, order);

        apply_view_options_folder_documents()
    });
}

function draw_sort_direction(selector, direction) {
    if (direction == 'asc' || direction == 'desc') {
        var obj = $(selector);
        obj.addClass('sorted');
        if (direction == 'desc') {
            obj.addClass('reversed')
        }
    }
}

function make_sortable() {
    /*  Sortable  */
    $('#my_sda_home_center ul:first, #my_sda_home_right ul:first').sortable({
        placeholder: "ui-state-highlight",
        connectWith: ".connectedSortable",
        handle: "div.my_sda_home_block_header",
        stop: function(event, ui) {
            var my_sda_home_center = [];
            var my_sda_home_right = [];
            var i = 0;
            var j = 0;
            $('#my_sda_home_center ul:first').children().each(function() {
                my_sda_home_center[i++] = $(this).attr('class').substring(9);
            });
            $('#my_sda_home_right ul:first').children().each(function() {
                my_sda_home_right[j++] = $(this).attr('class').substring(9);
            });
            var value = {};
            value.my_sda_home_center = my_sda_home_center;
            value.my_sda_home_right = my_sda_home_right;
            setCookie("sortable", JSON.stringify(value));
            recalcHeight();
            //alert(id_array);
            //alert(class_array);

            /*var order = $('#sortable').sortable('serialize');
             $.cookie('sortable', order);*/
        }
    });
}

function make_clickable_home_blocks() {
    $('.my_sda_block_toggle_buttons img').click(function() {
        var self = $(this);
        // TODO: better name
        var block_header_next = self.parents('.my_sda_home_block_header').next();
        if (self.attr('class') == 'minus') {
            block_header_next.slideUp(200)
        }else {
            block_header_next.slideDown(200)
        }
    });

    $('#my_sda_home_recent_searches').my_recent_activity_callback();
}

function process_folder_operation_result(res) {
    if (result_successful(res)) {
        closePopup();
        show_folders(
            $('#folder_type').val(),
            $('#sort_by').val(),
            $('#order').val());
    }
}

function process_folder_document_operation_result(res) {
    if (result_successful(res)) {
        closePopup();
        show_folder_documents(
            $('#folder_id').val(),
            $('#sort_by').val(),
            $('#order').val());
    }
}

function show_create_edit_folder_popup(create_edit, id) {
    show_popup('my_sda_folder_create');

    var is_create = (create_edit == 'create');

    $('#popup .title_text').html(is_create ? 'Create New Folder' : 'Edit Folder');

    var submitBtn = $('#popup #create_apply .button_text');

    submitBtn.html(is_create ? 'Create' : 'Apply');
    submitBtn.parents('a.button_outer_left').click(function () {
//        alert($(this).html());
        var data = {
            folder_name: $('#popup [name=folder_name]').val(),
            folder_desc: $('#popup [name=folder_desc]').val()
        };

        if (!is_create) {// edit
            data.id = id;
        }

        var url = is_create ? 'create_folder' : 'edit_folder';

        $.post(url, data, function (res) {
            process_folder_operation_result(res);
        }, 'json');

        return false;
    });

    if (!is_create) {// edit
        var folder = $('#folder_' + id);
        $('#popup [name=folder_name]').val($.trim(folder.find('.name').text()));
        $('#popup [name=folder_desc]').val($.trim(folder.find('.description').text()));
    }

    return false;
}

function show_remove_folder_popup() {
    var ids = value_list('.folders_list .check_one:checked');
    var folder_names = get_folder_names('.folders_list .check_one:checked');
    if (ids.length) {
        show_popup('my_sda_folder_remove');
        $('#popup .title_text').html(ids.length == 1 ? 'Remove Folder' : 'Remove Folders');
        $('#popup #this_folder').html(ids.length == 1 ? 'this folder' : 'these folders');
        $('#popup #folder_name').html(folder_names.join(', '));
        $('#popup #remove_btn').click(function () {
            $.post('remove_folder', {
                ids: ids.join(',')
            }, function (res) {
                process_folder_operation_result(res);
            }, 'json');

            return false;
        });
    } else {
        alert('Please select a folder first to remove!');
    }
}

function show_remove_folder_document_popup() {
    var ids = value_list('.folder_documents_list .check_one:checked');

    if (ids.length) {
        show_popup('my_sda_folder_document_remove');
        $('#popup #remove_btn').click(function () {
            $.post('remove_folder_document', {
                folder_id:  $('#folder_id').val(),
                ids: ids.join(',')
            }, function (res) {
                process_folder_document_operation_result(res);
            }, 'json');

            return false;
        });
    } else {
        alert('Please select a document first to remove!');
    }
}

function copy_document_to_folder(ids, folder_id) {
    if (ids.length) {
        $.post('copy_document_to_folder', {
            folder_id:  folder_id,
            ids: ids
        }, function (res) {
            process_folder_document_operation_result(res);
        });
    } else {
        alert('Please select a document first to copy!');
    }
}

function move_document_to_folder(ids, from_folder_id, to_folder_id) {
    if (ids.length) {
        $.post('move_document_to_folder', {
            from_folder_id: from_folder_id,
            to_folder_id: to_folder_id,
            ids: ids
        }, function (res) {
            process_folder_document_operation_result(res);
        });
    } else {
        alert('Please select a document first to move!');
    }
}

// TODO: move to lib and use everywhere
function result_successful(res) {
    var errors = res['errors'];
    if (errors) {
        alert(errors);

        return false;
    }

    return true;
}

function value_list(selector) {
    var list = [];
    $(selector).each(function () {
        list.push($(this).val());
    });
    return list;
}

function get_folder_names(selector) {
    var list = [];
    $(selector).each(function () {
        var folder_id = ($(this).val());
        list.push($('#folder_' + folder_id + ' .name').html());
    });
    return list;
}

function show_notifications() {
    var url = 'my_sda_notifications';
    $.get(url, function(data) {
        $('#my_sda_docs').html(data).my_sda_docs_callback();
    });
}

function edit_folder_description(thisLnk, start_edit) {
    $(thisLnk).hide();

    var span = $('#folder_desc');
    var ta = $('#folder_desc_edit');

    if (start_edit) {
        $('#lnk_save_desc').show();
        span.hide();
        ta.show();
        ta.val($.trim(span.html()));
    } else {
        $('#lnk_edit_desc').show();
        span.show();
        ta.hide();
        span.html(ta.val());
    }
    $.post('edit_folder_description', {folder_id: $('#folder_id').val(), description: ta.val()})
}

function show_select_view_options_folder_documents(obj) {
    $('#view_options').toggleClass('hidden');
    $('#sort_by').addClass('hidden');

    $('#background_for_pulldowns')
        .height($(document).height())
        .removeClass('hidden')
        .click(function() {
            close_pulldowns()
        });

    return false;
}

function apply_view_options_folder_documents() {
    $('#view_options').addClass('hidden');
    var container = $('#my_sda_docs');

    var all_options = [];

    container.find('#view_options').addClass('hidden').find('#select_fields_to_view input').each(function(index, element) {
        var td_class = $(element).attr('value');
        if ($(element).is(':checked')) {
            container.find('td.' + td_class + ',th.' + td_class).removeClass('hidden');
            all_options.push(td_class);
        } else {
            container.find('td.' + td_class + ',th.' + td_class).addClass('hidden');
        }
    });

    $.post('save_folder_view_options', {options: all_options});

    // TODO VVV- why return false if not used?
    /*if (!$(".search_result").hasClass("hidden") &&
        !$(".search_result th div.resize").hasClass("ui-resizable")) {
        return false;
    }*/
}

function show_select_sort_by_folder_documents(obj) {
    $(obj).siblings('#sort_by').toggleClass('hidden');
    $('#view_options').addClass('hidden');
    $('#background_for_pulldowns')
        .height($(document).height())
        .removeClass('hidden')
        .click(function() {
            close_pulldowns()
        });
    return false;
}

function apply_view_options_tags_documents() {
    close_pulldowns();

    var container, list_or_snippets;

    if ($('#search_results').length) {
        container = $('#search_results');
    }
    if ($('#my_sda_docs').length) {
        container = $('#my_sda_docs');
    }

    if (container.find('#edit-list-or-snippets-list').is(':checked'))
        list_or_snippets = 'list';
    else
        list_or_snippets = 'snippets';

    switch (list_or_snippets) {
        case "list":
            $('#sidebar-right').show();
            container.find('table').removeClass('hidden');
            container.find('.table_header').removeClass('hidden');
            container.find('div.snippet:not(.etalon)').addClass('hidden');
            $('#search_results_snippets').addClass('hidden');
            $('#select_fields_to_view').show();
            container.find('.apply').show();
            break;
        case "snippets":
            $('#sidebar-right').hide();
            container.find('table').addClass('hidden');
            container.find('.table_header').addClass('hidden');
            container.find('div.snippet:not(.etalon)').removeClass('hidden');
            $('#search_results_snippets').removeClass('hidden');
            container.find('.apply').hide();
            $('#select_fields_to_view').hide();
            break;
    }

    var all_options = [];

    container.find('#view_options').addClass('hidden').find('#select_fields_to_view input').each(function(index, element) {
        var td_class = $(element).attr('value');
        if ($(element).is(':checked')) {
            container.find('td.' + td_class + ',th.' + td_class).removeClass('hidden');
            all_options.push(td_class);
        }
        else {
//            console.log(td_class);
            container.find('td.' + td_class + ',th.' + td_class).addClass('hidden');
        }
    });
    var url = 'save_user_view_options_tags_documents';
    //if (container.find('#edit-list-or-snippets-list').length)
    $.post(url, {'options':all_options, 'view_type':list_or_snippets});
    // setTimeout(refine_history_size,100);
    if (!$(".search_result").hasClass("hidden") && !$(".search_result th div.resize").hasClass("ui-resizable"))

    //make_resizable(".search_result th div.resize");
    make_search_resizable();

    return false;
    refine_history_size();
}

function hide_select_sort_by_folder_documents() {
    $('#sort_by').addClass('hidden');
    var sort_by = $('#sort_by select').attr('value');
    show_folder_documents($('#folder_id').val(), sort_by, 'asc');
}

function update_zotero() {
    var ev = document.createEvent('HTMLEvents');
    ev.initEvent('ZoteroItemUpdated', true, true);
    document.dispatchEvent(ev);
}

function show_saved_search(search_id) {
    window.location = this_base_url + "/node/2#S#" + search_id;
}

var recentHash = null;

function poll_hash() {
    if (window.location.hash == recentHash) {
        return; // Nothing's changed since last polled.
    }

    $('#my_sda_docs').show();
    $('#search_results').hide();

    previousHash = recentHash;
    recentHash = window.location.hash;

    var url = window.location.hash;
    var url_obj = $.url(url);
    var segment = url_obj.fparam('page');

//    console.info('segment=', segment);
    if (segment == undefined) {
        show_my_sda_home_page();
        return;
    }

    switch (segment) {
        case 'annotations':
            show_my_sda_annotations('', '');
            break;
        case 'tags':
            show_my_tags();
            break;
        case 's_searches':
            var id = url_obj.fparam('id');
            if (id == undefined) {
                show_my_saved_searches();
            } else {
                show_saved_search(id);
            }
            break;
        case 'discussions':
            var forum_id = url_obj.fparam('forum');
            if (forum_id != undefined) {
                var act = url_obj.fparam('act');
                if (act != undefined && act == 'start_topic') {
                    var doc_id = url_obj.fparam('doc_id');
                    show_start_topic(forum_id, doc_id);
                    break;
                }
                var sort_by = url_obj.fparam('sort_by');
                var order = url_obj.fparam('order');
                var page = url_obj.fparam('p');
                if (sort_by == undefined) sort_by = '';
                if (order == undefined) order = '';
                if (page == undefined) page = 1;
                open_forum(forum_id, sort_by, order, page);
                break;
            } else {
                var act = url_obj.fparam('act');
                if (act != undefined && act == 'start_topic') {
                    var doc_id = url_obj.fparam('doc_id');
                    show_start_topic(0, doc_id);
                    break;
                }
            }
            var topic_id = url_obj.fparam('topic');
            if (topic_id == undefined) {
                show_all_discussions();
            } else {
                var post_id = url_obj.fparam('post');
                if (post_id == undefined) {
                    open_topic(topic_id);
                } else {
                    open_topic(topic_id, post_id);
                }
            }
            break;
        case 'folders':
            var folder = url_obj.fparam('f');
            show_folders(folder);
            break;
        case 'notifications':
            show_notifications();
            break;
        case 'profile':
            var id = url_obj.fparam('id');
            if (id == undefined) {
                view_profile(0, previousHash);
            } else {
                view_profile(id, previousHash);
            }
            break;
        case 'ri_list':
            show_my_research_list('all', 'creation_date', 'desc');
            break;
        /*case 'pg_list':
            show_my_research_list('pg', 'join_date', 'desc');
            break;*/
        case 'ri':
            var ri_id = url_obj.fparam('id');
            open_research_interest(ri_id);
            break;
        case 'folder':
            var folder_id = url_obj.fparam('id');
            show_folder_documents(folder_id);
            break;
        case 'search_discussions':
            var query = url_obj.fparam('query');
            var search_type = url_obj.fparam('search_type');
            var page = url_obj.fparam('p');
            if (query == undefined) query = '';
            if (search_type == undefined) search_type = 'any';
            if (page == undefined) page = 1;
            show_discussion_search_result(query, search_type, page);
            break;
        case 'docs_by_tags':
            var tags = url_obj.fparam('tags');
            var sort_by = url_obj.fparam('sort_by');
            var order = url_obj.fparam('order');

            show_docs_for_tags(tags, sort_by, order);
            break;
    }

    if (segment != 'folder') {
        $('.toggle a').removeClass('pushed');
    }

    if (segment != 'folders' && segment != 'folder') {
        $('.toggle a[href^="#page=' + segment + '"]').addClass('pushed');
    } else {
        $('.toggle a[href^="#page=' + segment + '&f=' + folder + '"]').addClass('pushed');
    }
}

function show_docs_for_tags(tags, sort_by, order) {
    if (tags == undefined) {
        return;
    }
    if (sort_by == undefined) sort_by = 'title';
    if (order == undefined) order = 'asc';
    tags = tags.split(',');
    var tags_str = '';
    for (var i = 0; i < tags.length; i++) {
        tags_str = tags_str + 'tags[]=' + tags[i] + '&';
    }
    tags_str = tags_str.substring(0, tags_str.length - 1);

    show_docs_for_tagstr(tags_str, sort_by, order);
}

function show_create_forum_popup() {
    show_popup('create_forum');
    $('#popup #create_button').click(function () {
        $.post('create_forum', {
            forum_name: $('#forum_name').val(),
            forum_description: $('#forum_description').val()
        }, function(data) {
            closePopup();
            window.location = this_base_url + '/node/13#page=discussions&forum=' + data;
        });
        return false;
    });
}

function delete_forum(forum_id) {
    $.post('delete_forum', {
        forum_id: forum_id
    }, function() {
        $('#forum_' + forum_id).hide();
    });
}

function invite_member_to_ri() {
    var user_id = $('#user').val();
    var ri = $('#ri_id').val();
    if (user_id) {
        $.post('invite_member_to_ri', {user_id:user_id, ri:ri}, function() {});
        closePopup();
    }
}

function accept_invitation(notification_id) {
    $.post('accept_invitation', {notification_id: notification_id});
    $("#result_text_" + notification_id).html("You have accepted this invitation.")
}

function decline_invitation(notification_id) {
    $.post('decline_invitation', {notification_id: notification_id});
    $("#result_text_" + notification_id).html("You have declined this invitation.")
}

function enable_autocomplete() {
    $('#user').hyjack_select();
}

function show_members_pager(obj, ri, index) {
    var offset = $(obj).attr('href');
    var url = this_base_url + '/node/show_members_pager';
    $.post(url, {offset:offset, ri:ri, index:index}, function(data) {
        $('#my_sda_ri_home_members').html(data).search_results_callback();
    });
}
