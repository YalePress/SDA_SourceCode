<div style="padding-left: 10px;">
    <br><b>Register an account:</b><br><br>
    <br><span style="color: red"><?= $error ?>  </span>
    <form action="code_registration" method="get">
        Activation Code:<br>
        <input type="text" name="code" value="<?= $code ?>"><br><br>
        <input type="submit" name="new" value="Register">
    </form>

    <br><br>
    <b>Account renewal:</b><br><br><span style="color: red"><?= $error2 ?>  </span>
    <form action="code_registration" method="get">
        Username:<br>
        <input type="text" name="username" value="<?= $user_name ?>"><br><br>
        Activation Code:<br>
        <input type="text" name="code" value="<?= $code ?>"><br><br>
        <input type="submit" name="renew" value="Update account">
    </form>

</div >
 
