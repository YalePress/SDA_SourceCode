<div style="padding-left: 10px;">
<b style="font-size: 1.3em;">Institutional Account Profile</b>
<br>
<form action="institutional_account" method="get">
<br><br>
<input type="hidden" name="id" value="<?= $siteAuthForm["id"] ?>">
Account Name:<br>
<input type="text" name="account_name" value="<?= $siteAuthForm["account_name"] ?>"><br><br>
Activation Date: <span style="color: red"><?= $error_activation_date?></span><br>
<input type="text" name="activation_date" value="<?= $siteAuthForm["activation_date"] ?>">  <br><br>
Expiration Date: <span style="color: red"><?= $error_expiration_date?></span><br>
<input type="text" name="expiration_date" value="<?= $siteAuthForm["expiration_date"] ?>">  <br><br>
Manager Name:<br>
<input type="text" name="account_mng_name" value="<?= $siteAuthForm["account_mng_name"] ?>"><br><br>
Manager Email: <span style="color: red"><?= $error_email?></span><br>
<input type="text" name="account_mng_email" value="<?= $siteAuthForm["account_mng_email"] ?>"> <br> <br>
<!-- shib_ip:<br>
<input type="text" name="shib_ip" value="'.$siteAuthForm["shib_ip"].'"> <br>  -->
IP Range (from to):<br>
<div class="ip-box">
<? foreach ($siteAuthForm["ip"] as $i=>$iprow) { ?>
    <input type="text" name="ip_from_<?=$i?>" value="<?= $iprow["ip_from"] ?>">
    <input type="text" name="ip_to_<?=$i?>" value="<?= $iprow["ip_to"] ?>"><br>
<?};?>
</div>
<input type="button" value="Add IP Range" onclick="add_row();" ><br>

<br>Active:<br>
<input type="checkbox" name="status" <?= ($siteAuthForm["status"]==1?'checked':'') ?> > <br><br>

<input type="submit" name="act" value="<?= ($siteAuthForm["id"]>0?'Update':'Add') ?>" >
</form>
</div>

<script type="text/javascript">
function add_row() {
    var id  = $('div.ip-box input:last').attr('name').substr(6);
    id = parseInt(id) +1;
    raw = '<input type="text" name="ip_from_'+id+'">  <input type="text" name="ip_to_'+id+'"><br>';
    $('div.ip-box').append(raw);
}
</script>

 
