<div style="padding-left: 10px;">

        <table cellpadding="0" cellspacing="0" border="0" class="my_sda_result search_result">
            <thead>
                    <tr class="header">
                        <th class="checkbox_cell not_sortable" style="width:20px !important"><div class="resize"><div class="va_middle"></div></div></th>
                        <th class="not_sortable"><div class="resize">Id<div class="va_middle"></div></div></th>
                        <th class="not_sortable"><div class="resize">Code<div class="va_middle"></div></div></th>
                        <th class="not_sortable"><div class="resize">Duration<div class="va_middle"></div></div></th>
                        <th class="not_sortable"><div class="resize">Is Used<div class="va_middle"></div></div></th>
                     </tr>
            </thead>
        <? foreach ($list as $row) { ?>
            <tr>
                <td><input type="checkbox" value="<?= $row['id'] ?>" class="check_one" name="remove_code" id="ch_<?= $row['id'] ?>"/>
                <td><?= $row['id'] ?> </td>
                <td><?= $row['code'] ?> </td>
                <td><?= $row['expiration_days'] ?> </td>
                <td><?= $row['is_used'] ?> </td>
            </tr>

        <? }; ?>
        </table>

    <br>
        <input type="button" value="Remove" onclick="remove_codes();">
    <br>
    <br>
    Enter codes:<br>
    usage: code duration<br>
    <form action="add_reg_codes" method="post">
        <textarea id="codes" name="codes" rows="3" cols="50"></textarea><br><br>
        <input type="submit" value="Submit">
    </form>
</div >
 
