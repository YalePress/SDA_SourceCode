jQuery(document).ready(function() {

    apply_view_options_users();

    jQuery('.content_table').delegate('th:not(.checkbox_cell, .not_sortable)', 'click', function() {
        var order;

        var this_th = jQuery(this);

        if (!this_th.hasClass('sorted')) {
            order = 'asc'
        } else {
            if (this_th.hasClass('reversed'))
                order = 'asc';
            else order = 'desc';
        }

        var sort_by = this_th.find('a').attr('href') || get_from_class(this_th, 'sort_by');
        var type = this_th.find('a').attr('class') || get_from_class(this_th, 'type');

        sort_table_results2(sort_by, order, type);
    });

    jQuery('.content_table').delegate('.check_all', 'change', function() {
        if (jQuery(this).is(':checked')) {
            jQuery('.check_one').attr('checked', 'checked');

        }
        else {
            jQuery('.check_one').removeAttr('checked');
        }
    });

});

function sort_table_results2(sort_by, order, type) {
    if (type == 'users') {
        search_institutional_accounts(sort_by, order);
    }
}

function search_institutional_accounts(sort_by, order) {
    if (sort_by == undefined) {
        sort_by = 'account_name';
    }
    if (order == undefined) {
        order = 'asc';
    }
    $.post(
            'search_institutional_accounts2',
            {
                account_name: $('#account_name').val(),
                activation_date: $('#activation_date').val(),
                expiration_date: $('#expiration_date').val(),
                account_mng_name: $('#account_mng_name').val(),
                account_mng_email: $('#account_mng_email').val(),
                status: $('#status').val(),
                sort_by: sort_by,
                order: order
            },
            function(data) {
                $('#search_users_result').html(data);
                jQuery('#search_users_result th.' + sort_by).addClass('sorted');
                if (order == 'desc') jQuery('#search_users_result th.' + sort_by).addClass('reversed');
                make_resizable('#search_users_result div.resize');
                apply_view_options_users();
            }
    );
}

function show_select_view_options_users(obj) {
    jQuery('#view_options').toggleClass('hidden');
    jQuery('#sort_by').addClass('hidden');

    // Save checked view options.
    var checked_options = [];
    var container = jQuery('#search_users_result');
    container.find('#view_options').find('#select_fields_to_view input').each(function(index, element) {
        if (jQuery(element).is(':checked')) {
            checked_options.push(jQuery(element).attr('value'));
        }
    });

    jQuery('#background_for_pulldowns')
        .height($(document).height())
        .removeClass('hidden')
        .click(function() {
            close_pulldowns()
            // Restore checked view options.
            container.find('#view_options').find('#select_fields_to_view input').each(function(index, element) {
                if (jQuery.inArray(jQuery(element).attr('value'), checked_options) != -1) {
                    jQuery(element).attr('checked', true);
                } else {
                    jQuery(element).attr('checked', false);
                }
            });
        });

    return false;
}

function apply_view_options_users() {
    jQuery('#view_options').addClass('hidden');
    var container = jQuery('#search_users_result');

    var all_options = [];

    container.find('#view_options').addClass('hidden').find('#select_fields_to_view input').each(function(index, element) {
        var td_class = jQuery(element).attr('value');
        if (jQuery(element).is(':checked')) {
            container.find('td.' + td_class + ',th.' + td_class).removeClass('hidden');
            all_options.push(td_class);
        } else {
            container.find('td.' + td_class + ',th.' + td_class).addClass('hidden');
        }
    });

    jQuery.post('save_inst_view_options', {options: all_options});

    if (!jQuery(".search_result").hasClass("hidden") &&
        !jQuery(".search_result th div.resize").hasClass("ui-resizable")) {
        return false;
    }
}

function show_select_sort_by_users2(obj) {
    jQuery(obj).siblings('#sort_by').toggleClass('hidden');
    jQuery('#view_options').addClass('hidden');
    jQuery('#background_for_pulldowns')
        .height($(document).height())
        .removeClass('hidden')
        .click(function() {
            close_pulldowns()
        });
    return false;
}

function hide_select_sort_by_users2() {
    jQuery('#sort_by').addClass('hidden');
    var sort_by = jQuery('#sort_by select').attr('value');
    search_institutional_accounts(sort_by, 'asc');
}

function close_pulldowns() {
    jQuery('#sort_by').addClass('hidden');
    jQuery('#view_options').addClass('hidden');
    jQuery('#select_check_all').addClass('hidden');
    jQuery('#background_for_pulldowns').addClass('hidden');
}

function delete_accounts() {
     if (jQuery('table.my_sda_result tbody input:checked').length )
        show_popup('delete_inst_account');
     else alert('Please select one or more accounts.')
}
function block_accounts() {
     if (jQuery('table.my_sda_result tbody input:checked').length )
        show_popup('block_inst_account');
     else alert('Please select one or more accounts.')
}
function unblock_accounts() {
     if (jQuery('table.my_sda_result tbody input:checked').length )
        show_popup('unblock_inst_account');
     else alert('Please select one or more accounts.')
}

function show_select_check_all() {
    var div = jQuery('#select_check_all');
    div.toggleClass('hidden');

    div.find('div.select_item').click(function() {
        if (jQuery(this).is('.select_all')) {
            jQuery("table.my_sda_result input[type='checkbox']").attr('checked', true);
            jQuery(".check_all").attr('checked', true)
        } else if (jQuery(this).is('.clear_all')) {
            jQuery("table.my_sda_result input[type='checkbox']").attr('checked', false);
            jQuery(".check_all").attr('checked', false)
        }
        div.addClass('hidden');
    })
}

function value_list(selector) {
    var list = [];
    $(selector).each(function () {
        list.push($(this).val());
    });
    return list;
}

function send_bulk_notice() {
    var ids = value_list('.check_one:checked');
    if (ids.length == 0) {
        closePopup();
        return;
    }
    $.post('send_bulk_notice_site', {
                ids: ids.join(','),
                notification_message: $('#notification_message').val()
            },
            function() {
                closePopup();
            }
    );
}

function load_message(id) {
    if (id == 0) {
        $('#notification_message').val('');
    } else {
        $('#notification_message').val('Loading...');
        $.post('get_notification_message', {
            id: id
        },
        function(data) {
            $('#notification_message').val(data);
        })
    }
}

function get_selected_site_users() {
    var field_number = 1;
    var users = '';
    var process_row = true;
    $('.search_result td').each(function() {
        if (field_number % 7 != 1) {
            if (process_row && (field_number % 7 == 2 || field_number % 7 == 6 )) {
                users += $(this).text() + "   ";
            }
        } else {
            if (field_number != 1 && process_row) users += '<br/>';
            process_row = true;
            var checkbox = $(this).find('.check_one');
            if (!checkbox.attr('checked')) {
                process_row = false;
            }
        }
        field_number++;
    });

    return users;
}

