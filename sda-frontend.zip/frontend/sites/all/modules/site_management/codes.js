function remove_codes() {
    var ids = value_list('.check_one:checked');
    if (ids.length == 0) {
        return;
    }
    $.post('remove_codes', {
                ids: ids.join(',')
            },
            function() {
                window.location = window.location;
            }
    );
}

function value_list(selector) {
    var list = [];
    $(selector).each(function () {
        list.push($(this).val());
    });
    return list;
}
