<div class="cell_title">Preview</div>
<div class="right_content" id="popup_archives_preview">
    <div id="trumbs" class="doc_prev"></div>
    <div id="preview_doc_information">
        <div class="doc_prev_control">
            <div class="facke_file">
                <a href="#" id="preview_open_doc_link" class="submit_outer_left"><span class="submit_outer_right">
                    <span class="submit_outer_center_open"><span class="submit_inner_open">Open</span>
                        <span class="va_middle"></span></span></span></a>

                <a onclick="save_type1('this');show_popup('save_checked_to_my_library');" class="hidden save_doc"
                   class="submit_outer_left"><span class="submit_outer_right"><span class="submit_outer_center">
                    <span class="submit_inner">Save</span><span class="va_middle"></span></span></span></a>
            </div>

            <a href="#" onclick="closePopup();return false;" class="hidden close_popup submit_outer_left">
                <span class="submit_outer_right"><span class="submit_outer_center"><span
                        class="submit_inner">Close</span><span
                        class="va_middle"></span></span></span></a>

            <div class="clear"></div>
        </div>

        <div id="doc_title" class="right_doc_title">Document Title</div>
        <div id="node_id" class="hidden"></div>
        <div id="author_name_clickable" class="right_doc_names">
            <div><a href="#"></a></div>
        </div>

        <table cellpadding="0" cellspacing="0" width="100%" class="doc_stat">
            <tbody class="non_border">
            <tr>
                <td width="50%" class="right_doc_label"><?= t('Date:') ?><BR>

                    <div id="publication_date_clickable" width="50%" class="right_doc_text">
                        <div><a></a></div>
                    </div>
                </td>
            </tr>
            <tr>
                <td class="right_doc_label"><?= t('Recipient:') ?><BR>

                    <div id="recipient_clickable" class="right_doc_text">
                        <div><a></a></div>
                    </div>
                </td>
            </tr>
            <tr>
                <td class="right_doc_label"><?= t('Repository:') ?><BR>

                    <div id="repository_clickable" class="right_doc_text">
                        <div><a></a></div>
                    </div>
                </td>
            </tr>
            <tr>
                <td class="right_doc_label"><?= t('ID #:') ?><BR>

                    <div id="doc_id" class="right_doc_text">
                        <div><a></a></div>
                    </div>
                </td>
            </tr>
            <tr>
                <td class="right_doc_label">
                    <div id="volume" class="right_doc_label"><?= t('AOC Volume:') ?><br>
                        <div id="doc_aoc_volume"></div>
                    </div>
                </td>
            </tr>
            <tr>
                <td class="right_doc_label"><?= t('Subject:') ?><BR>

                    <div id="subject_clickable" class="right_doc_text">
                        <div><a></a></div>
                    </div>
                </td>
            </tr>
            </tbody>
        </table>

        <div id="description" class="right_doc_label"><?= t('Description:') ?><br>

            <div class="doc_desc"></div>
        </div>
        <br>

        <div id="tsl_pages" class="right_doc_label"><?= t('Translation pages:') ?><br>

            <div class="doc_desc"></div>
        </div>
        <br>

        <div id="tsc_pages" class="right_doc_label"><?= t('Transcription pages:') ?><br>

            <div class="doc_desc"></div>
        </div>
        <br>

        <div id="images_count" class="right_doc_label"><?= t('Image count:') ?><br>

            <div class="doc_desc"></div>
        </div>
        <br>

        <div id="raiting" class="right_doc_label"><?= t('Avg.User Rating:') ?><br>

            <div id="doc_star_raiting"></div>
        </div>
        <br>

        <div id="tags" class="right_doc_label"><?= t('User Tags:') ?><br>

            <div id="doc_tags"></div>
        </div>

    </div>
    <br>
    <button class="save_doc hidden"
            onclick="save_type1('this');show_popup('save_checked_to_my_library')">Save to My library
    </button>
</div>
 
