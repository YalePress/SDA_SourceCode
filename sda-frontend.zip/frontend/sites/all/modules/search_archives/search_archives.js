var search = 'simple';
var save_type;
// TODO: rfct next 2 functions in 1
function get_search_mode() {
    if ($('#edit-all-or-any-words-all').is(':checked')) {
        return 'all';
    } else if ($('#edit-all-or-any-words-ext').is(':checked')) {
        return 'ext';
    } else {
        return 'any';
    }
}
function get_search_mode_filter() {
    if ($('#edit-filter-all-or-any-words-all').is(':checked')) {
        return 'all';
    } else if ($('#edit-filter-all-or-any-words-ext').is(':checked')) {
        return 'ext';
    } else {
        return 'any';
    }
}
$(document).ready(function() {
    show_advanced_search(null);

    $('#sidebar-right').removeClass('hidden');
    $('#sidebar-right').hide();
    $('#edit-keyword').attr('value', '');
    refresh_submit_button();
    ////////////////////////////
    // all code for new filters form
    $('.ranged select').attr('value', 'all');

    $('#filter-keywords').submit(function() {
        var search_keyword = $('#edit-filter-keyword').attr('value');
        if (search_keyword) {
            var search_in = $('#edit-filter-search-in').attr('value');

            var all_or_any = get_search_mode_filter();

            $('#edit-filter-keyword').attr('value', '');
            var filter_html = '<div class="unapplied_filter" name="' + search_in + '/' + all_or_any + '/' + search_keyword + '">';
            filter_html = filter_html + ucwords(search_in) + ': ' + search_keyword + '<span onclick="remove_filter(this)" class="remove_filter"></span></div>';
            $('.refine_filters[name="keywords"]').append(filter_html).removeClass('hidden')
        }
        refresh_submit_button();
        return false;
    });

    $('#refine_search').click(function() {
        if ($(this).find('button').hasClass('unactive')) {
            return false;
        } else show_advanced_search($('div.filter a:last'));
        return false;
    });
    $.fn.opuses_list_callback = function() {
        $('div.opus .plus_ico').click(function() {
            if ($(this).hasClass('active')) {
                $(this).removeClass('active');
                $(this).parent().parent().find('.delos_list').slideUp(200);
            } else {
                //console.log($(this));
                $(this).parent().parent().find('.delos_list').slideUp(200);
                $(this).parent().parent().find('.plus_ico').removeClass('active');
                $(this).addClass('active').parent().next().slideDown(200);
            }
        })
    };

    $.fn.filters_form_callback = function() {
        $('#filter-date').submit(function() {
            var year_from = $('#edit-filter-year-from').attr('value');
            var month_from = $('#edit-filter-month-from').attr('value');
            var text_month_from = $('#edit-filter-month-from option[value=' + month_from + ']').text();
            var day_from = $('#edit-filter-day-from').attr('value');
            var filter_html = '<div class="unapplied_filter" name="' + year_from + '/' + month_from + '/' + day_from;
            var year_to = $('#edit-filter-year-to').attr('value');
            var month_to = $('#edit-filter-month-to').attr('value');
            var text_month_to = $('#edit-filter-month-to option[value=' + month_to + ']').text();
            var day_to = $('#edit-filter-day-to').attr('value');
            if (year_from != 'all') year_from = parseInt(year_from);
            if (year_to != 'all') year_to = parseInt(year_to);
            if (month_from != 'all') month_from = parseInt(month_from);
            if (month_to != 'all') month_to = parseInt(month_to);
            if (day_from != 'all') day_from = parseInt(day_from);
            if (day_to != 'all') day_to = parseInt(day_to);
            filter_html = filter_html + '_' + year_to + '/' + month_to + '/' + day_to;
            if (year_from == 'all' && month_from == 'all' && day_from == 'all' && year_to == 'all' && month_to == 'all' && day_to) {
                return false;
            }
            filter_html = filter_html + '">';
            if (year_from != 'all') {
                filter_html = filter_html + year_from
            }
            if (month_from != 'all') {
                filter_html = filter_html + ' ' + text_month_from
            }
            if (day_from != 'all') {
                filter_html = filter_html + ' ' + day_from
            }
            if (!$('#edit-filter-year-to').is(':hidden')) {
                filter_html = filter_html + '-';
                if (year_to != 'all') {
                    if (year_from != 'all') {
                        if (year_from <= year_to) {
                            filter_html = filter_html + year_to
                        } else {
                            alert('Date "From" must be less than "To"');
                            return false
                        }
                    }
                    else {
                        alert('Select both years in range');
                        return false
                    }
                } else {
                    if (year_from != 'all') {
                        alert('Select both years in range');
                    }
                }
                if (month_to != 'all') {
                    if (month_from != 'all') {
                        if (!(year_from == year_to && month_from > month_to)) {
                            filter_html = filter_html + ' ' + text_month_to
                        } else {
                            alert('Date "From" must be less than "To"');
                            return false
                        }
                    } else {
                        alert('Select both month in range');
                        return false
                    }
                }
                else {
                    if (month_from != 'all') {
                        alert('Select both month in range');
                        return false
                    }
                }
                if (day_to != 'all') {
                    if (month_from != 'all') {
                        if (!(month_from == month_to && day_from > day_to)) {
                            filter_html = filter_html + ' ' + day_to
                        } else {
                            alert('Year "From" must be less than "To"');
                            return false
                        }
                    } else {
                        alert('Select both days in range');
                        return false
                    }

                } else {
                    if (day_from != 'all') {
                        alert('Select both days in range');
                        return false
                    }
                }
            }
            filter_html = filter_html + '<span onclick="remove_filter(this)" class="remove_filter"></span></div>';
            $('.refine_filters[name="date"]').append(filter_html).removeClass('hidden');
            refresh_submit_button();
            return false;
        });
        return $(this);
    };
    $('#advanced_search_body').filters_form_callback();
    ///////////////////////


    $('#advanced_search_form .search_see_all_apply_div a').click(function() {
        $(this).parent().parent().addClass('hidden');
        return false;
    });


    if ($('#block-search_archives-0,#block-browse_archives-0').length) {
        //$('body').css('overflow','hidden')
        $('ul.tabs').hide();
    }

    $(window).resize(function() {
        refine_history_size()
    });

    //обработка сабмита поиска
    $('#simple-search-form').submit(function() {
        if ($(this).find('#edit-search-submit').hasClass('unactive'))
            return false;
        //$('#refine_your_results a').removeClass('active')
        //$('#refine_your_results').next().hide()
        if ($('.filter a:first').hasClass('active')) search = 'simple';
        else search = 'advanced';
        var data_obj = {};
        $.extend(data_obj, {search:search});

        var url = this_base_url + '/node/search_archives';

        var search_in, search_keyword, all_or_any;

        if (search == "advanced") {
            search_in = $('#edit-search-in').attr('value');

            $.extend(data_obj,
                {search_in:search_in,
                    keyword:search_keyword,
                    all_or_any:all_or_any});

            search_keyword = $('#edit-keyword').attr('value');
            search_keyword = search_keyword.replace(/'/g,'"');
            if (search_keyword) {
                search_in = $('#edit-search-in').attr('value');
                all_or_any = get_search_mode();

                //console.log(search_keyword);
                $('#edit-keyword').attr('value', '');
                var filter_html = '<div class="unapplied_filter" name=\'' + search_in + '/' + all_or_any + '/' + search_keyword + '\'>';
                filter_html = filter_html + ucwords(search_in) + ': ' + search_keyword + '<span onclick="remove_filter(this)" class="remove_filter"></span></div>';
                $('.refine_filters[name="keywords"]').append(filter_html).removeClass('hidden')

            }

            $('#current_search .refine_filters').each(function() {
                var array_name = $.trim($(this).attr('name'));
                eval(array_name + '=[];');
                eval(array_name + '_text=[];');
                $(this).find('.unapplied_filter').each(function() {
                    var filter = $(this);
                    var filter_name = $.trim(filter.attr('name'));
                    var filter_text = $.trim(filter.text());
                    eval(array_name + '.push(\'' + filter_name + '\')');
                    eval(array_name + '_text.push(\'' + filter_text + '\')')
                });
                eval('$.extend(data_obj,{' + array_name + ':' + array_name + '})');
                eval('$.extend(data_obj,{' + array_name + '_text:' + array_name + '_text})')
            });
            $('.search_header').hide();
            $('#search_in').hide();
            $('#simple_search_keyword').hide();
            $('#all_or_any_words').hide();
        }
        else if (search == "simple") {
            search_in = $('#edit-search-in').attr('value');
            search_keyword = $('#edit-keyword').attr('value');
            all_or_any = get_search_mode();
            $.extend(data_obj,
                {search_in:search_in,
                    keyword:search_keyword,
                    all_or_any:all_or_any});
        }
        ////////////sending search data
        $.post(url, data_obj, function(data) {
            $('#search_results').html(data.results).
                search_results_callback().
                search_results_snippets_callback();
            //.reset_refine_tree()
            //.refine_history_callback();
            apply_view_options();
            $('div.date_filters').html(data.form).find('form.jNice').jNice().filters_form_callback();
            $('#reset_search a').addClass('to_most_viewed');
            //$('#edit-refine-search').addClass('active').removeClass('unactive');
            if ($('table.search_result tbody td.doc_id').length) {
                $('#save_search_link').removeClass('hidden');
                $('#edit-refine-search').removeClass('unactive');
                $('#edit-search-submit').addClass('unactive');
                $('#search_in,#simple_search_keyword,#all_or_any_words').addClass('hidden');
                //filter_html='<div class="unapplied_filter" name="'+search_in+'/'+all_or_any+'/'+search_keyword+'">';
                var search_in = $('#edit-search-in').attr('value');
                var search_keyword = $('#edit-keyword').attr('value');
                var filter_html = '<div class="refine_filters_header">Keywords:</div><div class="unapplied_filter">' + ucwords(search_in) + ': ' + search_keyword + '</div>';

                if (search == "simple"){
                   $('.refine_filters[name="keywords2"]').html(filter_html).removeClass('hidden');
                }
                if (search == "advanced"){
                    $('.refine_filters[name="keywords"]').removeClass('hidden');
                }

            }
            if (data.error) {
                alert(data.error);
            }
        }, 'json');
        //}
        //else
        //alert('Enter search keyword');
        return false;
    });
    if ($('#simple-search-form').length) {
        var locate = location.hash;
        var loc = locate.split('#');
        var search_ss = loc[2];
        if (loc[1] == 'S') {
            //alert(loc[2]);
            $('#a_saved_search').addClass('active');
            //$('#saved_searches').show();
            show_one_saved_search(loc[2]);
        } else if (loc[1] == 'R') {
            var search_id = loc[2];
            show_one_past_search(search_id);
        } else if (loc[1] == 'G') {
            var word = loc[2];
            if ((loc[2]) != '') {
                $('#edit-keyword').attr("value", word);
                $('#edit-search-submit').click();
            }
        } else if (loc[1] == 'T') {
            var tag = loc[2];
            var lang = loc[3];
            if (tag != '' && lang != '') {
                location.hash='';
                add_tag_filter('', lang, tag);
                submit_search();
            }
        } else if (loc[1] == 'SBJ') {
            var type = loc[2];
            var subject = loc[3];
            if (type != '' && subject != '') {
                location.hash='';
                add_subject_filter('', type, subject);
                submit_search();
            }
        } else {
            var search_term = loc[1];
            if (search_term) {
                $('#edit-keyword').attr('value', search_term).parents('#simple-search-form').submit();
            } else {
                var selector = 'most_viewed';
                var url = this_base_url + '/node/browse_archives';
                var value = null;
                $.post(url, {value:value,selector:selector, 'from_search':true}, function(data) {
                    $('#search_results').html(data)
                        .search_results_callback()
                        .search_results_snippets_callback();
                    apply_view_options();
                });
            }
        }
    }

    $(".slide_toggle.subjects").find("input").each(function() {
        $(this).removeAttr('checked');
    });
    $(".slide_toggle.tags").find("input").each(function() {
        $(this).removeAttr('checked');
    });

    $.fn.iventories_list_callback = function() {
        var inv_container = $(this);
        var fond_container = inv_container.prev();
        var filters_container = fond_container.prev();
        var fond_id = inv_container.find('.fond_id').html();
        inv_container.find('input[type="checkbox"]').each(function() {
            if (filters_container.find('div.refine_filters.fond[name="fond_' + fond_id + '"] div.unapplied_filter[name="' + $(this).attr('value') + '"]').length) {
                $(this).removeAttr('checked').parent().parent().hide();
            }
        });
        inv_container.find('.popup_submit_button').click(function() {
            if (!filters_container.find('div.refine_filters.fond[name="fond_' + fond_id + '"]').length) {
                var div_html = '<div class="refine_filters fond" name="fond_' + fond_id + '"><div><span onclick="remove_fond_filter(this)" class="remove_filter"></span>Fond#' + fond_id + '</div></div>';
                filters_container.append(div_html);
            }
            do{
                var target_cont = filters_container.find('div.refine_filters.fond[name="fond_' + fond_id + '"]')
            } while (!target_cont.length);
            inv_container.find('input[value!="all"]:checked').each(function() {
                target_cont.append('<div class="unapplied_filter"  name="' + $(this).attr('value') + '">Not <input class="not_chb" type="checkbox" name="' + $(this).attr('value') + '"><span onclick="remove_inv_filter(this)" class="remove_filter"></span>' + $(this).parent().text() + '</div>');
                $(this).parent().parent().hide()
            });
            fond_container.addClass('hidden').prev().prev().removeClass('active');
            fond_container.find('input[type="checkbox"]').removeAttr('checked');
            if (!inv_container.find('div.form-item:not(:hidden) input[type="checkbox"]').length) {
                fond_container.find('input[type="checkbox"][value="' + fond_id + '"]').parent().parent().hide()
            }
            inv_container.addClass('hidden').html('');
            return false;
        });
        inv_container.find('.popup_close_button').hide();

        $('.popup_header img').click(function() {
            $(this).parent().next().find('input').removeAttr('checked').parents('.search_see_all_list').addClass('hidden').prev().find('.popup_header img').click().parent().next().find('input[type="checkbox"]').removeAttr('checked')
        });
        return inv_container;
    };

    $.fn.refine_history_callback = function() {
        refine_history_size();
        $('#search_results_header .scroll_left_button').click(function() {
            scroll_refine_history(-1)
        });
        $('#search_results_header .scroll_right_button').click(function() {
            scroll_refine_history(1)
        });
        scroll_refine_history(0);
        function scroll_refine_history(shift) {
            var current = parseInt($('#search_results_header .scroll_position').html());
            if (!current) current = 0;
            //console.log(current)
            if (typeof(shift) == 'number') {
                var new_pos = current + shift;
                //console.log(new_pos)
                //console.log($('#search_results_header .history_item').length)
                if (new_pos >= 0 && new_pos < $('#search_results_header .history_item').length) {
                    //console.log('in range')
                    if (new_pos == 0) {
                        $('#search_results_header .scroll_left_button').addClass('hidden')
                    } else {
                        $('#search_results_header .scroll_left_button').removeClass('hidden')
                    }
                    //console.log(new_pos)
                    //console.log($('#refine_history_scroller_wrapper'))
                    //$('#refine_history_scroller_wrapper').scrollTo('#search_results_header .history_item.index_'+new_pos))
                    //$('#refine_history_scroller_wrapper').scrollTo(100)
                    //console.log($('#search_results_header .history_item.index_'+new_pos))
                    var wrapper = $('#refine_history_scroller_wrapper');
                    var last_item = $('#search_results_header .history_item:last')[0];
                    var new_item = $('#search_results_header .history_item.index_' + new_pos)[0];
                    var new_x = new_item.offsetLeft - new_item.offsetWidth;
                    //console.log(last_item)
                    //console.log(last_item.offsetLeft-new_x+300)
                    if ((last_item.offsetLeft - new_x + 150) > wrapper.width()) {
                        $('#search_results_header .scroll_right_button').removeClass('hidden')
                    } else {
                        $('#search_results_header .scroll_right_button').addClass('hidden')
                    }
                    //console.log($('#search_results_header .history_item.index_'+new_pos))
                    //console.log(last_item.offsetLeft-new_x)
                    wrapper[0].scrollLeft = new_x;
                    $('#search_results_header .scroll_position').html(new_pos)
                }
            }
            refine_history_size()
        }
    };

    $.fn.refine_tree_callback = function() {
        var object = $(this);
        object.find('div.select_inventory').prev().find('.popup_submit_button').hide().parent().height('35px');
        object.find('input[type=checkbox]').removeAttr('checked');
        object.find('#refine-fonds input[type=checkbox]').change(function() {
            if ($(this).is(':checked')) {
                var url = this_base_url + '/load_inventories_list';
                $.post(url, {
                        fond_id:$(this).attr('value')
                    },
                    function(data) {
                        var parent = object.find('div.select_inventory').prev();
                        $(this).removeAttr('checked');
                        object.find('div.select_inventory')
                            .html(data)
                            .css('top', parseInt(parent.css('top')) + 15 + 'px')
                            .css('left', parseInt(parent.css('left')) + 15 + 'px')
                            .removeClass('hidden')
                            .iventories_list_callback()

                    });
            } else {

            }
        });
        if (parseInt($('#result_items_count').html()) > 1) {
            $('#refine_your_results').removeClass('unactive');
        }

        $('.search_see_all_list').addClass('hidden').prev().prev('a').removeClass('active');
        object.find('.search_see_all_list:not(:has(.not_empty_flag))').prev().prev('a').hide();
        var colums = object.find('.year_column').hide().parent().find('.not_empty_flag').prev().show();
        colums.parents('.search_see_all_list').css('width', (colums.length * 160) + 'px').css('min-width', (colums.length * 160) + 'px');
        object.find('form').submit(function() {
            $(this).parent().next().find('.popup_submit_button').click();
            return false;
        });

        object.find('a').click(function() {
            var offset_top = $(this)[0].offsetTop;
            //console.log(offset_top);
            var offset_div = $('.left_content')[0].scrollTop;
            //console.log(offset_div);
            $(this).toggleClass('active').siblings('a').removeClass('active');
            var popup_window = $(this).next().next();
            popup_window.toggleClass('hidden').siblings('.search_see_all_list').addClass('hidden');
            var new_top = offset_top - offset_div + 150;
            var new_bottom = new_top + popup_window.height();
            var win_height = ($(window).height());
            //console.log(new_top+' '+popup_window.height()+' '+new_bottom+' '+win_height)
            if (new_bottom > (win_height - 20))
                new_top = win_height - popup_window.height() - 20;
            popup_window.css('top', new_top + 'px');

            return false;
        });
        object.find('.popup_close_button').hide();

        object.find('.check_all.form-item input').change(function() {
            if ($(this).is(':checked')) {
                $(this).parent().parent().parent().find('.form-item:not(:hidden) input').attr('checked', 'checked')
            }
            else {
                $(this).parent().parent().parent().find('input').removeAttr('checked')
            }
        });

        object.find('#refine-keyword').parent().parent().width('300px').css('min-width', '300px');

        object.find('.popup_submit_button').click(function() {
            var is_filters = ($(this).parents('#filters_form').length);
            var container = $(this).parent().parent();
            if (container.prev().attr('name') == 'keywords') {
                value = container.find('input').attr('value');
                if (value) {
                    var filter_html = '';
                    filter_html = '<div  class="unapplied_filter" name="' + value + '">';
                    if (is_filters)
                        filter_html = filter_html + 'Not<input class="not_chb" type="checkbox" name="' + $(this).attr('value') + '">';
                    filter_html = filter_html + '<span onclick="remove_filter(this)" class="remove_filter"></span>' + value + '</div>';
                    container.prev().append(filter_html);
                    container.find('input').attr('value', '')
                }
            } else {

                container.find('.form-item:not(:hidden) input[value!="all"]:checked').each(function() {
                    var filter_html = '';
                    filter_html = '<div class="unapplied_filter"  name="' + $(this).attr('value') + '">';
                    if (is_filters)
                        filter_html = filter_html + 'Not<input class="not_chb" type="checkbox" name="' + $(this).attr('value') + '">';
                    filter_html = filter_html + '<span onclick="remove_filter(this)" class="remove_filter"></span>' + $(this).parent().text() + '</div>';
                    container.prev().append(filter_html);
                    $(this).parent().parent().hide()
                })
            }
            container.find('input[value="all"]').removeAttr('checked');
            container.addClass('hidden').prev().prev().removeClass('active');
            return false;
        });

        $('.popup_header img').click(function() {
            $(this).parent().next().find('input').removeAttr('checked').parents('.search_see_all_list').addClass('hidden')
        });

        return object;
    };

    $('#filters_form').refine_tree_callback();

    $.fn.reset_refine_tree = function() {
        var object = $(this);
        var url = this_base_url + '/node/new_refine_tree';
        $.post(url, function(data) {
            $('#refine_your_results').next().html(data).refine_tree_callback()
        });
        return object;
    };

    $('.search_see_all_link').click(function() {
        $(this).siblings('.search_see_all_list').toggleClass('hidden')
    });

    $('#edit-keyword').keyup(function(eventObject) {
        $('#save_search_link').addClass('hidden');
        $('#refine_your_results').addClass('unactive').removeClass('hidden').next().hide();
        refresh_submit_button();
    });

    window.setInterval(refresh_submit_button, 100);

    $.fn.search_results_callback = function() {
        processTableSearchHeight();
        var object = $(this);
        //create_snippets();
        hide_little_preview();

        if (object.length) {
            //console.log(object);
            //console.log($('input:radio[name="list_or_snippets"]'));
            $('input:radio[name="list_or_snippets"]').change(function() {
                apply_view_options();
            });

            object.find('th:not(.checkbox_cell)').click(function() {
                var order;
                if (!$(this).hasClass('sorted')) {
                    order = 'asc';
                }
                else {
                    if ($(this).hasClass('reversed'))
                        order = 'asc';
                    else order = 'desc';
                }
                var sort_by = $(this).find('a').attr('href');
                sort_results(sort_by, order)
            });

            object.find('tbody tr:odd td').removeClass('odd').addClass('odd');

            object.find('tbody tr td:not(.checkbox_cell)').click(function() {
                clear_preview();
                var node_id = $(this).siblings('td.node_id').html();
                show_little_preview(node_id);
            });
            show_little_preview(object.find('tbody tr:first td.node_id').html());

            $('.check_all').change(function() {
                if ($(this).is(":checked")) {
                    $("table.search_result input[type='checkbox']").attr('checked', true);
                    $("div.save_checkbox input").attr('checked', true)
                }
                else {
                    $("table.search_result input[type='checkbox']").attr('checked', false);
                    $("div.save_checkbox input").attr('checked', false)
                }
                return false;
            });
            //commented out: didnt work in ie
            //var ev = document.createEvent('HTMLEvents');
            //ev.initEvent('ZoteroItemUpdated', true, true);
            //document.dispatchEvent(ev);
            return object;
        }
    };

    $.fn.search_results_snippets_callback = function() {
        var object = $(this);
        object.find('a.show_pop_up_preview').click(function() {
            var node_id = $(this).parents('div.snippet').find('div.node_id').html();
            var url = this_base_url + '/node/create_more_info_popup';
            $.post(url, {node_id:node_id}, function(data) {
                $('#popup_more_info').html(data);
                show_popup('more_info');
            });
        });

        object.find('button.show_select_folders_to_move').click(function() {
            $(this).siblings('div.select_folder_to_move').toggleClass('hidden')
        });

        /*object.find('div.select_folder_to_move select').click(function() {
         $(this).parent().toggleClass('hidden');
         var folder_id = $(this).attr('value');
         var node_id = $(this).parents('div.snippet').find('div.node_id').html();
         var url = this_base_url + '/node/move_document_to_folder';
         $.post(url, {
         folder_id:folder_id,
         node_id:node_id
         }, function(data) {
         //alert(data);
         show_my_docs($('#my_library a:first'), selector);
         });
         });*/

        if ($('#sda_tree').length) {
            object.find('a.delete_from_folder').removeClass('hidden').click(function() {
                var url = this_base_url + '/node/delete_document_from_folder';
                var folder_id = $(this).parents('div.snippet').find('div.doc_folder_id').html();
                var node_id = $(this).parents('div.snippet').find('div.node_id').html();
                $.post(url, {
                    folder_id:folder_id,
                    node_id:node_id
                }, function(data) {
                    //alert(data);
                    $('a.pushed').click();
                });
                return false;
            });
        }
        return object;
    };

    $.fn.little_preview_callback = function() {
        var object = $(this);
        $('.prev_btn').find('a.show_pop_up_preview').click(function() {
            //show_popup('archives_preview');
            //console.log($('#preview_doc_information'));
            //console.log($('#preview_doc_information').find('div#node_id').html());
            var node_id = $('#preview_doc_information').find('div#node_id').html();
            // show_little_preview(node_id)
            //   show_popup('archives_preview');
            var url = this_base_url + '/node/create_more_info_popup';
            $.post(url, {node_id:node_id}, function(data) {
                //alert(data);
                $('#popup_more_info').html(data);
                show_popup('more_info');
            });
        });
        return object;
    };

    //make_resizable(".search_result th div.resize");
    make_search_resizable();

    $('#menu_collections').addClass('active').parent().next().slideDown(200);

    return false;
});

function clear_preview() {
    $('#archives_preview').hide();
    $('#doc_title').html('');
    $('#author_name').html('');
    $('#trumbs').html('');
    $('#doc_id a').html('');
    $('#author_name_clickable a').html('');
    $('#recipient_clickable a').html('');
    $('#publication_date_clickable a').html('');
    $('#subject_clickable a').html('');
    $('#tags_clickable div').html('');
    $('#description div').html('');
}

function show_simple_search(obj) {
    $('#results_title').html('Results');
    $(obj).addClass('active').siblings('a').removeClass('active');
    $('#search_in,#simple_search_keyword,#all_or_any_words').removeClass('hidden');
    $('#advanced_search_header,#advanced_search_body').addClass('hidden');
    $('.search_header').html('Current Search:');
    $('#edit-search-submit').removeClass('unactive');
    $('.refine_filters').addClass('hidden').find('.unapplied_filter').remove();
    $('#edit-refine-search').addClass('unactive').parent().removeClass('hidden');
    search = 'simple';
    refresh_submit_button();
}

function show_advanced_search(obj) {
    $('#results_title').html('Results');
    $(obj).addClass('active').siblings('a').removeClass('active');
    $('#advanced_search_header,#advanced_search_body').removeClass('hidden');
    //$('.search_header').html('Current Search:')
    $('#edit-search-submit').addClass('unactive');
    $('#edit-refine-search').addClass('unactive').parent().addClass('hidden');
    $('.refine_filters[name="keywords2"]').addClass('hidden');

    //$('#search_in,#simple_search_keyword,#all_or_any_words').addClass('hidden')
    var search_keyword = $('#edit-keyword').attr('value');
    if (search != 'advanced' && search_keyword) {
        var search_in = $('#edit-search-in').attr('value');

        var all_or_any = get_search_mode();

        var filter_html = '<div class="unapplied_filter" name="' + search_in + '/' + all_or_any + '/' + search_keyword + '">';
        filter_html = filter_html + ucwords(search_in) + ': ' + search_keyword + '<span onclick="remove_filter(this)" class="remove_filter"></span></div>';
        $('.refine_filters[name="keywords"]').append(filter_html).removeClass('hidden');
    }
    refresh_submit_button();
    $('#edit-keyword').attr('value', '');
    search = 'advanced';
    $('div.filter a:first').removeAttr("onclick");
}

function select_search_page_number(obj) {
    var url = location.href;
    var search_page_number = $(obj).attr('href');
    $.post(url, {search_page_number:search_page_number}, function(data) {
        $('#search_results').html(data).parents('div.block').show();
        return false;
    });
    return false;
}

function show_select_sort_by(obj) {
    $(obj).siblings('#sort_by').toggleClass('hidden');
    //$(obj).toggleClass('active').siblings('a').removeClass('active')
    $('#view_options').addClass('hidden');
    ////////
    $('#background_for_pulldowns').height($(document).height())
        .removeClass('hidden').click(function() {
            close_pulldowns()
        });
    //////////
    return false;
}

function show_select_view_options(obj) {
    //$(obj).toggleClass('active').siblings('a').removeClass('active')
    $('#view_options').toggleClass('hidden');
    $('#sort_by').addClass('hidden');
    $('#background_for_pulldowns').height($(document).height())
        .removeClass('hidden').click(function() {
            close_pulldowns()
        });
    return false;
}

function hide_select_sort_by() {
    $('#sort_by').addClass('hidden');
    var sort_by = $('#sort_by select').attr('value');
    sort_results(sort_by, 'asc')
}

function sort_results(sort_by, order) {
    if ($("#sda_tags").length) {
        var tagstr = $('#str_tags').text();
        show_docs_for_tagstr(tagstr, sort_by, order);
        return false;
    }
    var url = this_base_url + '/node/sort_results';
    $.post(url, {sort_by:sort_by,order:order}, function(data) {
        $('#search_result_table_wrapper').html(data).search_results_callback()
            .search_results_snippets_callback();
        hide_little_preview();
        apply_view_options();
        $('#search_result_table_wrapper th.' + sort_by).addClass('sorted')
            .siblings('th').removeClass('sorted').removeClass('reversed');
        if (order == 'desc') $('#search_result_table_wrapper th.' + sort_by).addClass('reversed')
    });
    return false;
}

function all_to_my_library() {
    if ($('#search_results').find('#all_to_my_library').is(':checked')) {
        $('#search_results').find('input').attr("checked", "checked");
    } else {
        $('#search_results').find('input').removeAttr('checked');
    }
}

function open_document(node_path) {
  var is_login_user = window.is_login_user || '';
  if (!is_login_user) {
    $('div#back_gray').removeClass('hidden');
    var popup = $('div#login_popup');
    /*var popup = $('div#popup_login_page');*/
    popup.css({top:document.body.clientHeight/2});
    var form_auth = $("form#user-login-form");
    var node_path_short = node_path.substring(node_path.indexOf('sda_viewer'));
    form_auth.attr("action", window.this_base_url+"/log-in?destination="+node_path_short);
    popup.removeClass('hidden');
    return false;
  } else {
    //window.open(node_path);
    window.location = node_path;
    return false;
  }
}

function show_little_preview(node_id) {
    if (node_id == null) {
        return;
    }

    var tr = $('#search_results').find('td:contains("' + node_id + '")').parent();// TODO: this could be not reliable
    tr.addClass('previewed').siblings().removeClass('previewed');
    var little_preview = $('#popup_archives_preview');
    little_preview.find('#doc_title').html(tr.find('td.doc_title').attr('title'));
    little_preview.find('#author_name_clickable').html(tr.find('td.doc_author').attr('title'));
    little_preview.find('#trumbs').html('<img src="' + tr.find('td.doc_image').html() + '" alt="Document image">');
    little_preview.find('#preview_open_doc_link').attr('onclick', 'open_document("' + tr.find('td.doc_url').html() + '"); return false;');
    if (tr.find('td.folder_icon img').length) {
        little_preview.find('#preview_open_doc_link').addClass('unactive').attr('href', '#');
    } else {
        little_preview.find('#preview_open_doc_link').attr('href', '#').removeClass('unactive');
    }
    little_preview.find('#doc_id a').html(tr.find('td.doc_id').html());
    little_preview.find('#node_id').html(tr.find('td.node_id').html());
    //little_preview.find('#recipient_clickable a').html(tr.find('td.doc_recipient').html()).attr('href',this_url+'/node/3#people#'+tr.find('td.doc_recipient').html());
    little_preview.find('#recipient_clickable a').html(tr.find('td.doc_recipient').attr('title'));
    little_preview.find('#repository_clickable a').html(tr.find('td.doc_repos_value').html());
    //little_preview.find('#publication_date_clickable a').html(tr.find('td.doc_publication_date').html()).attr('href',this_url+'/node/3#date#'+tr.find('td.doc_publication_date').html());
    little_preview.find('#publication_date_clickable a').html(tr.find('td.doc_publication_date').html());
    little_preview.find('#subject_clickable a').html(tr.find('td.doc_subject').attr('title'));
    little_preview.find('#tags_clickable div').html(tr.find('td.doc_tags').html());
    little_preview.find('div.button_cell').html(tr.find('td.button_cell').html());
    little_preview.find('button.show_pop_up_preview').attr('value', tr.find('td.node_id').html());

    little_preview.find('#tsl_pages div').html(tr.find('td.doc_tsl_pages').html());
    little_preview.find('#tsc_pages div').html(tr.find('td.doc_tsc_pages').html());
    little_preview.find('#images_count div').html(tr.find('td.doc_images_count').html());
    if (tr.find('td.doc_aoc_volume').html() == "") {
        little_preview.find('#volume').parent().hide();
    } else {
        little_preview.find('#volume').parent().show();
        little_preview.find('#doc_aoc_volume').html(tr.find('td.doc_aoc_volume').html());
    }

    var raiting = tr.find('td.doc_rating').html();

    // TODO--VVV: in 1 ajax request?
    $.post(this_base_url + '/node/create_raiting_stars', {raiting:raiting}, function(data) {
        little_preview.find('#doc_star_raiting').html(data);
    });

    var detail = $('#detail_' + node_id);
    little_preview.find('#doc_tags').html(detail.find('.doc_tags .value').html());
/*    $.post(this_base_url + '/node/create_tags', {node_id:node_id}, function(data) {
        little_preview.find('#doc_tags').html(text_or_NA(data));
    });*/

    $.post(this_base_url + '/node/load_doc_description', {node_id:node_id}, function(data) {
        little_preview.find('#description div').html(text_or_NA(data));
    });

    little_preview.removeClass('hidden').little_preview_callback();
}

function text_or_NA(txt) {
    return $.trim(txt) || 'N/A';
}

function hide_little_preview() {
    //clear_preview();
    $('#popup_archives_preview').addClass('hidden')
}

function apply_view_options() {
    close_pulldowns();

    var container, list_or_snippets;

    if ($('#search_results').length) {
        container = $('#search_results');
    }
    if ($('#my_sda_docs').length) {
        container = $('#my_sda_docs');
    }

    if ($('#view_options_button_list').hasClass('active')) {
        list_or_snippets = 'list';
    } else if ($('#view_options_button_thumbnails').hasClass('active')) {
        list_or_snippets = 'snippets';
    } else {
        list_or_snippets = 'details';
    }

    /*if (container.find('#edit-list-or-snippets-list').is(':checked'))
        list_or_snippets = 'list';
    else if(container.find('#edit-list-or-snippets-snippets').is(':checked'))
        list_or_snippets = 'snippets';
	else
		list_or_snippets = "details";*/

    switch (list_or_snippets) {
        case "list":
            $('#sidebar-right').show();
            container.find('table').removeClass('hidden');
            container.find('.table_header').removeClass('hidden');
            container.find('div.snippet:not(.etalon)').addClass('hidden');
            $('#search_results_snippets').addClass('hidden');
			$('#search_results_details').addClass('hidden');
            $('#select_fields_to_view').show();
            container.find('.apply').show();
            break;
        case "snippets":
            $('#sidebar-right').hide();
            container.find('table').addClass('hidden');
            container.find('.table_header').addClass('hidden');
            container.find('div.snippet:not(.etalon)').removeClass('hidden');
			$('#search_results_details').addClass('hidden');
            $('#search_results_snippets').removeClass('hidden');
            container.find('.apply').hide();
            $('#select_fields_to_view').hide();
            break;
		case "details":
			$('#sidebar-right').hide();
			container.find('table').addClass('hidden');
            container.find('#detail_table').removeClass('hidden');
			container.find('.table_header').addClass('hidden');
			container.find('div.detail:not(.etalon)').removeClass('hidden');
			$('#search_results_snippets').addClass('hidden');
			$('#search_results_details').removeClass('hidden');
			container.find('.apply').hide();
			$('#select_fields_to_view').hide();
			break;
    }

    var all_options = [];

    container.find('#view_options').addClass('hidden').find('#select_fields_to_view input').each(function(index, element) {
        var td_class = $(element).attr('value');
        if ($(element).is(':checked')) {
            container.find('td.' + td_class + ',th.' + td_class).removeClass('hidden');
            all_options.push(td_class);
        }
        else {
//            console.log(td_class);
            container.find('td.' + td_class + ',th.' + td_class).addClass('hidden');
        }
    });
    var url = this_base_url + '/node/save_user_view_options';
    if (container.find('#edit-list-or-snippets-list').length)
        $.post(url, {'options[]':all_options,'view_type':list_or_snippets});
    // setTimeout(refine_history_size,100);
    if (!$(".search_result").hasClass("hidden") && !$(".search_result th div.resize").hasClass("ui-resizable"))

    //make_resizable(".search_result th div.resize");
        make_search_resizable();

    return false;
    refine_history_size();
}

function save_current_search_results() {
    var url = this_base_url + '/node/save_current_search_results';
    if ($('.filter a:first').hasClass('active')) search = 'simple';
    else search = 'advanced';
    var data_obj = {};
    $.extend(data_obj, {search:search});

    if (search == "advanced") {
        $('#current_search .refine_filters').each(function() {
            var array_name = $(this).attr('name');
            eval(array_name + '=new Array();');
            eval(array_name + '_text=new Array();');
            $(this).find('.unapplied_filter').each(function() {
                var filter_name = $(this).attr('name');
                var filter_text = $(this).text();
                eval(array_name + '.push("' + filter_name + '")');
                filter_text = filter_text.replace(/(\r\n|\n|\r)/gm,"");
                eval(array_name + '_text.push("' + filter_text + '")');
            });
            eval('$.extend(data_obj,{' + array_name + ':' + array_name + '})');
            eval('$.extend(data_obj,{' + array_name + '_text:' + array_name + '_text})');
        });
    } else if (search == "simple") {
        var search_in = $('#edit-search-in').attr('value');
        var search_keyword = $('#edit-keyword').attr('value');
        var all_or_any = get_search_mode();
        $.extend(data_obj,
            {search_in:search_in,
                keyword:search_keyword,
                all_or_any:all_or_any});
    }
    $.post(url, data_obj, function(data) {
        alert(data);
        //$('#edit-keyword').attr('value','');
        //$('#saved_searches').html(data);
    });
}

function save_type1(this_) {
    if (typeof(this_) == 'number') {
        $('#popup_save_checked_to_my_library .node_id_to_save').html(this_);
        show_popup('save_checked_to_my_library');
    } else if (this_ == 'checked') {
        save_type = this_;
        var checked_document_ids = get_checked_documents_ids();
        if (checked_document_ids.length == 0) {
            alert('Please select one or more documents.');
            return;
        } else {
            show_popup('save_checked_to_my_library');
        }
    }
}

function show_one_past_search(search_id) {
    p('show_one_past_search', search_id);
    show_one_search(search_id, '/node/create_recent_search_result');
}

function show_one_saved_search(search_id) {
    p('show_one_saved_search', search_id);
    show_one_search(search_id, '/node/create_saved_search_result');
}

function show_one_search(search_id, url) {
    url = this_base_url + url;
    $.getJSON(url, {search_id:search_id}, function (obj) {
        p('search_result:',obj);

        $('#search_results').html(obj.search_results).
            search_results_callback().
            search_results_snippets_callback();

        apply_view_options();

        if ($('table.search_result tbody td.doc_id').length) {
            $('#save_search_link').removeClass('hidden');
            $('#edit-refine-search').removeClass('unactive');
        }

        if (obj.search_type == 'simple') {// do we have this now?
            show_simple_search($('div.filter a:first'));
            $('#edit-keyword').attr('value', obj.search_string);
            $('#all_or_any_words input').removeAttr('checked').prev().removeClass('jNiceChecked');
            $('input#edit-all-or-any-words-' + obj.all_or_any).attr('checked', 'checked').prev().addClass('jNiceChecked');
            ////////
            $('#edit-search-in').attr('value', obj.search_in);
            $('#edit-search-in').next().find('.jNiceSelectText').html(obj.search_in_text);
            $('#edit-search-in').next().find('a:contains("' + obj.search_in_text + '")').addClass('selected').siblings('a').removeClass('selected');
            /////////
        } else {
            show_advanced_search($('div.filter a:last'));
            $('#current_search').html(obj.filters);
            refresh_submit_button();
        }

        $('#reset_search a').addClass('to_most_viewed');
    });
    return false;
}

function show_pager(obj) {
    var offset = $(obj).attr('href');
    var url = this_base_url + '/node/show_pager';
    $.post(url, {offset:offset}, function(data) {
        $('#search_result_table_wrapper').html(data).search_results_callback()
            .search_results_snippets_callback();
        hide_little_preview();
        apply_view_options();
    });
}

function show_select_check_all() {
    var div = $('#select_check_all');
    div.toggleClass('hidden');

    div.find('div.select_item').click(function() {
        if ($(this).is('.select_all')) {
            $("table.search_result input[type='checkbox']").attr('checked', true);
            $("div.save_checkbox input").attr('checked', true)
        } else if ($(this).is('.clear_all')) {
            $("table.search_result input[type='checkbox']").attr('checked', false);
            $("div.save_checkbox input").attr('checked', false)
        }
        div.addClass('hidden');
    })
}

function refine_by_index(index) {
    var url = this_base_url + '/node/refine_results_backward';
    $.getJSON(url, {index:index}, function(obj) {
        //alert(obj.refine_tree)
        $('#refine_your_results').next().html(obj.refine_tree).refine_tree_callback();
        //alert(obj.search_result_list)
        $('#search_result_table_wrapper').html(obj.search_result_list).search_results_callback()
            .search_results_snippets_callback();
        hide_little_preview();
        apply_view_options();
        //alert(obj.refine_history)
        $('#refine_history').html(obj.refine_history)
            .parents('#refine_history_scroller_wrapper').refine_history_callback();
        $('#result_items_count').html(obj.new_count);
    });
}

function close_pulldowns() {
    $('#sort_by').addClass('hidden');
    $('#view_options').addClass('hidden');
    $('#select_check_all').addClass('hidden');
    $('#background_for_pulldowns').addClass('hidden');
    //$('.sort_lists a').removeClass('active')
}

function show_refine_form(obj) {
    if (!$(obj).parent().hasClass('unactive')) {
        //$('.left_column .filter a:last').addClass('active').siblings('a').removeClass('active')
        //search='advanced';
        show_advanced_search($('.left_column .filter a:last'));
        if ($(obj).hasClass('active'))
            $('#refine_results_form').slideUp(200);
        else
            $('#refine_results_form').slideDown(200);
        $(obj).toggleClass('active');
    }
    else return false;
}

function remove_filter(obj) {
    var filter_name = $(obj).parent().attr('name');
    var container = $(obj).parent().parent();
    var filter_type = container.attr('name');
    $(obj).parent().remove();
    if (!container.find('.unapplied_filter').length) {
        container.addClass('hidden')
    }
    var f_class;
    switch (filter_type) {
        case 'subjects':
            f_class = 'subject';
            break;
        case 'tags':
            f_class = 'tag';
            break;
        case 'people':
            f_class = 'person';
            break;
        case 'collections':
            f_class = 'volume';
            break;
    }
    if (f_class) {
        $('#search_results div.' + f_class + '[name="' + filter_name + '"]').show();
        if (f_class == 'volume')
            $('#search_results div[name="' + filter_name + '"]').show()
    }
    if (filter_type == 'collections') {
        $('#collections_tree div[name="' + filter_name + '"]').show();
        if (filter_name == 'AOC/all' || filter_name == 'RGASPI') {
            $('#collections_tree div[name="' + filter_name + '"]').next().show()
        }
        if (filter_name.substr(0, 6) == 'RGASPI') {
            $('div.opuses_wrapper').show()
        }
    }
    refresh_submit_button();
    $('#edit-search-submit').click();
}

function refine_forward() {
    var data_obj = {};
    var filter_exist = false;

    $('#refine_results_form .refine_filters').each(function() {
        var array_name = $(this).attr('name');
        eval(array_name + '=new Array();');
        eval('not_' + array_name + '=new Array();');
        $(this).find('.unapplied_filter').each(function() {
            var filter_name = $(this).attr('name');
            eval(array_name + '.push("' + filter_name + '")');
            filter_exist = true;
            if ($(this).find('input.not_chb:checked').length) {
                eval('not_' + array_name + '.push("' + filter_name + '")')
            }
        });
        eval('$.extend(data_obj,{' + array_name + ':' + array_name + '})');
        eval('$.extend(data_obj,{not_' + array_name + ':not_' + array_name + '})')
    });
    if (filter_exist) {
        var url = this_base_url + '/node/refine_results_forward';
        $.getJSON(url,
            data_obj, function(obj) {
                $('#refine_your_results').next().html(obj.refine_tree).refine_tree_callback();
                $('#search_result_table_wrapper').html(obj.search_result_list).search_results_callback()
                    .search_results_snippets_callback();
                hide_little_preview();
                apply_view_options();
                $('#refine_history').html(obj.refine_history)
                    .parents('#refine_history_scroller_wrapper').refine_history_callback();
                $('#result_items_count').html(obj.new_count)
            });
    }
}

function apply_filters() {
    $('#simple-search-form').submit();
    return false;
}

function show_select_folders_to_move(obj) {
    $(obj).siblings('div.select_folder_to_move').toggleClass('hidden')
}

function delete_from_folder(obj) {
    $(obj).removeClass('hidden').click(function() {
        var url = this_base_url + '/node/delete_document_from_folder';
        var folder_id = $(this).parents('div.snippet').find('div.doc_folder_id').html();
        var node_id = $(this).parents('div.snippet').find('div.node_id').html();
        $.post(url, {
            folder_id:folder_id,
            node_id:node_id
        }, function(data) {
            //alert(data);
            $('a.pushed').click();
        });
        return false;
    });
}
function reset_search(showMostViewed) {
    showMostViewed = typeof showMostViewed !== 'undefined' ? showMostViewed : true;

    $('#reset_search a').removeClass('to_most_viewed');
    $('#edit-refine-search').addClass('unactive');
    $('#search_in,#simple_search_keyword,#all_or_any_words').removeClass('hidden');
    $('#search_in').show();
    $('#simple_search_keyword').show();
    $('#all_or_any_words').show();
    $('.refine_filters[name="keywords2"]').addClass('hidden');
    if (showMostViewed != false) {
        $('#search_results .search_result_wrap').html('');
        $('#search_results .filter_ations').html('');
        $('#search_results .sort_lists, #refine_history').html('');
        $('#result_items_count').html('0');
        $('#save_search_link').remove();
        $('#refine_results_form').hide();
        $('#pager').remove();
    }

    $('#edit-keyword').attr('value', '');
    //$('.refine_filters .unapplied_filter').remove()
    //$('.refine_filters').addClass('hidden')
    $('#refine_your_results').addClass('unactive').find('a').removeClass('active').next().hide().html('');

    //$('#filters_form').find('input[type="checkbox"]').each(function(){
    //  $(this).parent().parent().show();
    //$(this).removeAttr("checked");


    // $('#refine_your_results').addClass('unactive');
    //$('#refine_your_results').find('a').removeClass('active');

    $.post('reset_search', {}, function(data) {
        $('div.date_filters').html(data.form).find('form.jNice').jNice().filters_form_callback()
    }, 'json');
    $('#current_search .remove_filter').click();

    if (showMostViewed) {
        var selector = 'most_viewed';
        var url = this_base_url + '/node/browse_archives';
        var value = null;
        $.post(url, {value:value,selector:selector, 'from_search': true}, function(data) {
            $('#search_results').html(data)
                .search_results_callback()
                .search_results_snippets_callback();

            $('#view_options_button_list').addClass('active')
            $('#view_options_button_thumbnails').removeClass('active')
            $('#view_options_button_details').removeClass('active')

            apply_view_options();
        });
    }
    //  })
}

function refine_history_size() {
    var width = ($('#search_results').width()) - 100;
    if (!$('.scroll_left_button').hasClass('hidden')) {
        width = width - 30;
    }
    $('#refine_history_scroller_wrapper').width(width + 'px');
}

function delete_filter_from_breadcrumbs(f_type, f_value) {
    var f_container = $('#filters_form .refine_filters[name="' + f_type + '"]');
    if (f_type != 'keywords') {
        f_container.next().find('input[value="' + f_value + '"]').removeAttr('checked').parent().parent().show()
    }
    f_container.find('.unapplied_filter[name="' + f_value + '"]').remove();
    $('#simple-search-form').submit()
}

function open_selected() {
    var checked = get_checked_documents_ids();
    if(checked.length>2){
    //if (checked.length > 1) { //for beta
        show_popup("too_mach_selected")
    } else {
        var url = this_base_url + '/sda_viewer?n=';
        for (var i = 0; i < checked.length; i++) {
            if (i) url = url + '/';
            url = url + checked[i]
        }
        open_document(url)
    }
}

function show_recent_searches() {
    $.get(this_base_url + "/node/echo_recent_searches", function(data) {
        $('#search_results').html(data);
        $('#sidebar-right').hide();
        add_scroll()
    })
}

function show_saved_searches() {
    $.get(this_base_url + "/node/echo_saved_searches", function(data) {
        $('#search_results').html(data);
        $('#sidebar-right').hide();
        add_scroll()
    });
    return false;
}

function ucwords(string) {
    return string.charAt(0).toUpperCase() + string.substr(1).toLowerCase();
}

function refresh_submit_button() {
    var unactive = true;
    if ($('.filter a:first').hasClass('active')) {
        // simple search
        $('.search_header').show();
        $('#search_in').show();
        $('#simple_search_keyword').show();
        $('#all_or_any_words').show();
        if ($.trim($('#edit-keyword').attr('value')) != '') {
            unactive = false;
        }
    } else {
        // advanced search
        if ($('#current_search .unapplied_filter').length) {
            unactive = false;
            $('.search_header').hide();
            $('#search_in').hide();
            $('#simple_search_keyword').hide();
            $('#all_or_any_words').hide();
        }
        if ($.trim($('#edit-keyword').attr('value')) != '') {
            unactive = false;
        }
    }
    if (unactive) {
        $('#edit-search-submit').addClass('unactive')
    } else {
        $('#edit-search-submit').removeClass('unactive')
    }
}

function show_people(lang) {
    //alert(lang);
    $.post("echo_al", {lang:lang}, function(data) {
        //alert(data);
        $('#search_results').html(data);
        show_names("all", lang);
        $('#sidebar-right').hide();
    });
}

function show_names(L, lang) {
    $.post("echo_names", {L:L,lang:lang}, function(data) {
        //$('.person_list').html(data);

        $('.person_list').html(data).find('div.person').each(function() {
            if ($('div.refine_filters[name="people"] div.unapplied_filter[name="' + $(this).attr('name') + '"]').length) {
                $(this).hide();
            }
        });
        $('.alphabet').find('a').each(function() {
            $(this).removeClass('active');
        });
        $('.alphabet').find('#' + L).addClass('active');

        add_scroll()
    });
}

function show_subjects_list(link, type, letter) {
    if ($(link).hasClass('empty') || $(link).hasClass('active')) return false;
    $.get(this_base_url + "/show_subjects_list", {type:type,letter:letter}, function(data) {
        $('#search_results').html(data).find('div.subject').each(function() {
            if ($('div.refine_filters[name="subjects"] div.unapplied_filter[name="' + $(this).attr('name') + '"]').length) {
                $(this).hide();
            }
        });
        $('#sidebar-right').hide();
        add_scroll();
    })
}

function add_subject_filter(link, type, subject) {
    var filter_html = '<div class="unapplied_filter" name="' + type + '/' + subject + '">';
    filter_html = filter_html + type + ': ' + subject + '<span onclick="remove_filter(this)" class="remove_filter"></span></div>';
    $(link).parent().hide();
    $('.refine_filters[name="subjects"]').append(filter_html).removeClass('hidden');
    refresh_submit_button();
}

function add_person_filter(link, person_id, person_name) {
    var filter_html = '<div class="unapplied_filter" name="' + person_id + '">';
    filter_html = filter_html + person_name + '<span onclick="remove_filter(this)" class="remove_filter"></span></div>';
    $(link).parent().hide();
    $('.refine_filters[name="people"]').append(filter_html).removeClass('hidden');
    refresh_submit_button();
}

function add_tag_filter(link, lang, tag) {
    var filter_html = '<div class="unapplied_filter" name="' + lang + '/' + tag + '">';
    filter_html = filter_html + tag + '<span onclick="remove_filter(this)" class="remove_filter"></span></div>';
    $(link).parent().hide();
    $('.refine_filters[name="tags"]').append(filter_html).removeClass('hidden');
    refresh_submit_button();
}
function add_fond_filter(link, type, fond) {
    $('div.refine_filters[name="collections"] div.unapplied_filter[name^="' + type + '/' + fond + '"] span.remove_filter').click()
    var filter_html = '<div class="unapplied_filter" name="' + type + '/' + fond + '">';
    filter_html = filter_html + type + ': Fond ' + fond + '<span onclick="remove_filter(this)" class="remove_filter"></span></div>';
    $(link).parent().hide();//.next().hide();
    $('.refine_filters[name="collections"]').append(filter_html).removeClass('hidden');

    refresh_submit_button();
}

function add_opus_filter(link, type, fond, opus) {
    $('div.refine_filters[name="collections"] div.unapplied_filter[name^="' + type + '/' + fond + '/' + opus + '"] span.remove_filter').click()
    var filter_html = '<div class="unapplied_filter" name="' + type + '/' + fond + '/' + opus + '">';
    filter_html = filter_html + type + ': Fond ' + fond + ': Opis ' + opus + '<span onclick="remove_filter(this)" class="remove_filter"></span></div>';
    $(link).parent().hide().next().hide();
    $('.refine_filters[name="collections"]').append(filter_html).removeClass('hidden');
    refresh_submit_button();
}

function add_delo_filter(link, type, fond, opus, delo) {
    var filter_html = '<div class="unapplied_filter" name="' + type + '/' + fond + '/' + opus + '/' + delo + '">';
    filter_html = filter_html + type + ': Fond ' + fond + ': Opis ' + opus + ': Delo ' + delo + '<span onclick="remove_filter(this)" class="remove_filter"></span></div>';
    $(link).parent().hide();
    $('.refine_filters[name="collections"]').append(filter_html).removeClass('hidden');
    refresh_submit_button();
}

function add_aoc_filter(link, f_name, f_text) {
    var filter_html = '<div class="unapplied_filter" name="' + f_name + '">';
    filter_html = filter_html + f_text + '<span onclick="remove_filter(this)" class="remove_filter"></span></div>';
    $(link).parent().hide();
    if (f_name == 'AOC/all') {
        //$(link).parent().next().hide();
        $('div.refine_filters[name="collections"] div.unapplied_filter[name^="AOC"] span.remove_filter').click()
    } else if (f_name == 'AOC/vol') {
        $('div.refine_filters[name="collections"] div.unapplied_filter[name^="AOC/vol"] span.remove_filter').click()
    }
    $('.refine_filters[name="collections"]').append(filter_html).removeClass('hidden');
    refresh_submit_button();
}

function add_collection_filter(link, f_name, f_text) {
    var filter_html = '<div class="unapplied_filter" name="' + f_name + '">';
    filter_html = filter_html + f_text + '<span onclick="remove_filter(this)" class="remove_filter"></span></div>';
    $(link).parent().hide();
    $(link).parent().next().hide();
    $('div.refine_filters[name="collections"] div.unapplied_filter[name^="' + f_name + '"] span.remove_filter').click();
    $('.refine_filters[name="collections"]').append(filter_html).removeClass('hidden');
    refresh_submit_button();
}

function show_tags_list(link, lang, letter) {
    if ($(link).hasClass('empty') || $(link).hasClass('active')) return false;
    $.get(this_base_url + "/show_tags_list", {lang:lang,letter:letter}, function(data) {
        $('#search_results').html(data).find('div.tag').each(function() {
            if ($('div.refine_filters[name="tags"] div.unapplied_filter[name="' + $(this).attr('name') + '"]').length) {
                $(this).hide()
            }
        });
        $('#sidebar-right').hide();
        add_scroll();
    })
}

function show_fond(fond_id) {
    $.get(this_base_url + "/show_fond", {fond_id:fond_id}, function(data) {
        $('#search_results').html(data).opuses_list_callback();
        /*.find('div.tag').each(function(){
         if($('div.refine_filters[name="tags"] div.unapplied_filter[name="'+$(this).attr('name')+'"]').length){
         $(this).hide()
         }
         })*/
        $('#sidebar-right').hide();
        add_scroll();
    })
}

function show_aoc_volumes() {
    $.get(this_base_url + "/show_aoc_volumes", function(data) {
        $('#search_results').html(data).opuses_list_callback();
        /*.find('div.tag').each(function(){
         if($('div.refine_filters[name="tags"] div.unapplied_filter[name="'+$(this).attr('name')+'"]').length){
         $(this).hide()
         }
         })*/
        $('#sidebar-right').hide();
        add_scroll();
    })
}

function add_scroll() {
    var win_height = ($(window).height());
    var temp = 224;
    var container;
    if ($('.alphabet').length) {
        container = $('.alphabet').next();
    } else {
        container = $('.cell_title').next();
        temp = temp - 25;
    }
    container.addClass('scrollable').height((win_height - temp) + "px");
}

function toggle_date_range() {
    $('.ranged,.toggle_data_range,.filter_date_header').toggleClass('hidden');
    if ($('.filter_date_header').hasClass('hidden')) {
        $('.ranged select').attr('value', 'all');
        $('.ranged .jNiceSelectText').html('Any');
        $('.ranged a:contains("Any")').addClass('selected').siblings('a').removeClass('selected');
    }
}

function make_search_resizable() {
    make_resizable(".search_result th div.resize", null, 'table.search_result:last tr:first td', resizable_texts);
}

function resizable_texts() {
    $('table.search_result:last tr td[title]').each(function() {
        var obj = $(this);
        var rows = obj.height() / parseInt(obj.css('line-height'));
        rows = Math.floor(rows);
        if (rows > 3) rows = 3;
        var symbol_width = 7;
        var cols = obj.width() / symbol_width;
        cols = Math.floor(cols);
        obj.html(obj.attr('title').substr(0, (rows * cols - 5)));
        if (obj.html().length < obj.attr('title').length) {
            obj.append('...');
        }
    })
}

function submit_search() {
    $('#simple-search-form').submit();
}

function change_view_options(span) {
    if ($(span).hasClass('active')) return;

    $(span).addClass('active');
    if ($(span).attr('id') != 'view_options_button_list') {
        $('#view_options_button_list').removeClass('active');
        $('#view_options_link').hide();
        $('#view_options_link_disabled').show();
    } else {
        $('#view_options_link').show();
        $('#view_options_link_disabled').hide();
    }
    if ($(span).attr('id') != 'view_options_button_thumbnails') $('#view_options_button_thumbnails').removeClass('active');
    if ($(span).attr('id') != 'view_options_button_details') $('#view_options_button_details').removeClass('active');

    apply_view_options();
}

function sort_results_select() {
    var sort_by = $('#select_sort_by').attr('value');
    var direction = 'asc';
    if (sort_by == 'doc_views_count' || sort_by == 'doc_rating' || sort_by == 'doc_relevancy') {
        direction = 'desc';
    }
    sort_results(sort_by, direction);
}